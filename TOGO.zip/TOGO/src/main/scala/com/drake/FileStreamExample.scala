package com.drake

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.concurrent.TimeUnit

import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.functions.{lit, current_timestamp}

/**
  * Created FileStream
  */
object FileStreamExample {

  def main(args: Array[String]): Unit = {

    val sparkSession = SparkSession.builder
      .master("local")
      .appName("example")
      .getOrCreate()

    val schema = StructType(
      Array(StructField("transactionId", StringType),
            StructField("customerId", StringType),
            StructField("itemId", StringType),
            StructField("amountPaid", StringType)))

    //create stream from folder
    val fileStreamDf1 = sparkSession.read//Stream
      .option("header", "true")
      .schema(schema)
      .csv("input")

    //println("count:" + fileStreamDf1.rdd.count())
    //fileStreamDf1.inputFiles.map(x => println("out:"+x))

    val cnt = fileStreamDf1.rdd.count()
    val fnames = fileStreamDf1.inputFiles.map(_.split("/").last).mkString("|")
    val now = Calendar.getInstance().getTime()
    val nowFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val nowStr = nowFormat.format(now)

    //println("file:///Users/nnagaraju/IDEAWorkspace/drake/input/sales01.csv".split("/").last)

    import sparkSession.implicits._
    val statusDf = Seq(
      (fnames,"2018-12-22","00",cnt,"sales")
    ).toDF("file_name","file_dt","file_hr","count","src_system")
        .withColumn("start_time", lit(current_timestamp()))
      .withColumn("end_time", lit(""))
        .select("file_name","file_dt","file_hr","count","start_time","end_time","src_system")

    statusDf.show(false)

    statusDf
      .write
      .format("csv")
      .partitionBy("src_system")
      .mode(SaveMode.Append)
      .save("output/status")


    //println("stats:" + fnames+","+cnt+","+nowStr)




//    val query = fileStreamDf.writeStream
//      .format("console")
//      .outputMode(OutputMode.Append()).start()
//
//      query.awaitTermination()

  }

}
