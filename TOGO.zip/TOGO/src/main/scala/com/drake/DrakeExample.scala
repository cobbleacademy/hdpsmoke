package com.drake

import org.apache.spark.sql.SparkSession

object DrakeExample {

  def main(args: Array[String]): Unit = {

    val sparkSession = SparkSession.builder.
      master("local")
      .appName("example")
      .getOrCreate()


    val df = sparkSession.read.csv("src/main/resources/sales.csv")
    df.createTempView("sales")

    val tdf = sparkSession.read.json("src/main/resources/workflow.json")

    import org.apache.spark.sql.functions.input_file_name

    val rdd = tdf.select(input_file_name).rdd
    rdd.foreach(println)

    //interacting with catalogue

    sparkSession.sql("use default")

    val catalog = sparkSession.catalog

    //print the databases

    catalog.listDatabases().select("name").show()

    // print all the tables

    catalog.listTables().select("name").show()

    // is cached
    println(catalog.isCached("sales"))
    df.cache()
    println(catalog.isCached("sales"))

    // drop the table
    catalog.dropTempView("sales")
    catalog.listTables().select("name").show()

    // list functions
    catalog.listFunctions().select("name","description","className","isTemporary").show(100)
  }

}
