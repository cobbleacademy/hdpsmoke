package com.drake.function

import java.util.UUID

import com.drake.BaseTrait
import org.apache.spark.sql.functions.udf

/**
  * A common functions needed for processing data
  */
object Func extends BaseTrait {

  /**
    * Generates glbal UUID
    */
  val uuid = udf(() => UUID.randomUUID().toString)

}
