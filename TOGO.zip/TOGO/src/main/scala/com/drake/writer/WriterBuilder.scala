package com.drake.writer

import java.util.UUID

import com.drake.model.Model.Step
import com.drake.schema.SchemaBuilderHelper
import com.drake.status.{StatusBuilder, StatusBuilderHelper}
import com.drake.{BaseTrait, PropsUtil, SessionDataHelper, SparkHelper}
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import org.apache.spark.sql.functions.{current_timestamp, lit, udf}
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, SaveMode, functions}

import scala.collection.mutable

/**
  * A Builder class for Writer for output content
  */
object WriterBuilder {

  /**
    * Builds specific Writer
    */
  class BaseWriter(handlername: String) extends WriterBuilder {

    name = handlername

    val generateUUID = udf(() => UUID.randomUUID().toString)

    /**
      * Writes DataFrame content to Sink
      *
      * @param step
      * @return
      */
    override def writeSink(step: Step, outputFrame: DataFrame): Unit = {
      logger.debug("BaseReader:readSource")

      //
      //val sinkOpts = step.options.getOrElse(Seq(Attribute("","")))
      //val sinkOptsMap = Map(sinkOpts map {a => a.key -> a.value}: _*)
      //val sinkAttrs = step.attributes.getOrElse(Seq(Attribute("","")))
      //val sinkAttrsMap = Map(sinkAttrs map {a => a.key -> a.value}: _*)
      val sinkOpts = step.options.getOrElse(Map())
      val sinkAttrs = step.attributes.getOrElse(Map())
      val sparkSession = SparkHelper.getSparkSession()


      //
      if ("stream".equals(PropsUtil.getWorkflow().mode)) {

        //
        if (sinkAttrs.get("partitionBy").isDefined) {

          val partCols = sinkAttrs.getOrElse("partitionBy", "").split(",")
          //
          val outQuery = outputFrame
            .withColumn("uuid", generateUUID())
            .writeStream
            .format(step.format.get)
            .options(sinkOpts)
            .partitionBy(partCols: _*)
            .trigger(Trigger.ProcessingTime(sinkAttrs.getOrElse("trigger", "")))
            .start()

          //
          //outQuery.awaitTermination()

        } else {

          //
          val outQuery = outputFrame
            .withColumn("uuid", generateUUID())
            .writeStream
            .format(step.format.get)
            .options(sinkOpts)
            .trigger(Trigger.ProcessingTime(sinkAttrs.getOrElse("trigger", "")))
            .start()

          //
          //outQuery.awaitTermination()

        }
      } else {

        //
        if ("hive".equals(step.format.getOrElse(""))) {
          //
          outputFrame.createOrReplaceTempView(sinkAttrs.getOrElse("currentTempView", ""))
          sparkSession.sql(sinkAttrs.getOrElse("sql", ""))

        } else {

          //
          if (sinkAttrs.get("partitionBy").isDefined) {
            //
            val partCols = sinkAttrs.getOrElse("partitionBy", "").split(",")
            //
            val outQuery = outputFrame
              //.withColumn("uuid", generateUUID())
              .write //Stream
              .format(step.format.get)
              .options(sinkOpts)
              .partitionBy(partCols: _*)
              .mode(SaveMode.Append)
              .save(sinkOpts.getOrElse("path", ""))
            //.trigger(Trigger.ProcessingTime(sinkAttrs.getOrElse("trigger",""))
            //.start()

            //
            //outQuery.awaitTermination()

          } else if ("hbase".equals(step.format.getOrElse(""))) {

            //
            val outQuery = outputFrame
              .write
              .format("org.apache.spark.sql.execution.datasources.hbase")
              .option(HBaseTableCatalog.tableCatalog, SchemaBuilderHelper.createCatalog(sinkAttrs))
              .option(HBaseTableCatalog.newTable, "5")
              .save()

            //
            //outQuery.awaitTermination()

          } else {
            //
            val outQuery = outputFrame
              //.withColumn("uuid", generateUUID())
              .write //Stream
              .format(step.format.get)
              .options(sinkOpts)
              .mode(SaveMode.Append)
              .save()
              //.save(sinkOpts.getOrElse("path", ""))
            //.trigger(Trigger.ProcessingTime(sinkAttrs.getOrElse("trigger",""))
            //.start()

            //
            //outQuery.awaitTermination()

          }

          //Refresh Hive Meta Info
          if ("true".equals(sinkAttrs.getOrElse("hiveMetaRepair", "false"))) {
            outputFrame.sparkSession.sql("msck repair table " + sinkAttrs.getOrElse("db", "") + "." + sinkAttrs.getOrElse("table", ""))
            //output.sparkSession.sql("select * from " + sinkAttrs.getOrElse("db", "") + "." + sinkAttrs.getOrElse("table", "")).show(false)
          }

        }

        // Run post process scripts
        if ("true".equals(sinkAttrs.getOrElse("logStatus", "false"))) StatusBuilderHelper.endLogStatus(step, sinkAttrs.getOrElse("logStatusFrom", ""))

      }

    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): WriterBuilder = {
    getWriterBuilder(s)
  }

  // an alternative factory method (use one or the other)
  def getWriterBuilder(s: String): WriterBuilder = {
    new BaseWriter(s)
  }

}

/**
  * A Builder interface for all the Sink Writer
  */
trait WriterBuilder extends BaseTrait {

  var name: String = _


  /**
    * Writes DataFrame content to Sink
    *
    * @param step
    * @return
    */
  def writeSink(step: Step, output: DataFrame): Unit

}
