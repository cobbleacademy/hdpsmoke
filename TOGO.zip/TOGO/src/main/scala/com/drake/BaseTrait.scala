package com.drake

import org.apache.log4j.Logger

trait BaseTrait extends Serializable {
  @transient lazy val logger=Logger.getLogger(getClass.getName)
}
