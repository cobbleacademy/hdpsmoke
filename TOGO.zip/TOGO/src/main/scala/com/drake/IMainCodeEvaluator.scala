package com.drake

import javax.script.{Compilable, CompiledScript}
import org.apache.spark.sql.types.StructType

import scala.tools.nsc.Settings
import scala.tools.nsc.interpreter.{IMain, JPrintWriter}

/**
  * An Evaluator for dynamic scala code in the form of string (or file)
  */
object IMainCodeEvaluator {
  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): IMainCodeEvaluator = {
    new IMainBaseCodeEvaluator(s)
  }

  // an alternative factory method (use one or the other)
  def getCodeEvaluator(s: String): IMainCodeEvaluator = {
    new IMainBaseCodeEvaluator(s)
  }

  /**
    * Builds specific Code Evaluator
    */
  class IMainBaseCodeEvaluator(handlername: String) extends IMainCodeEvaluator {

    name = handlername

    // Create IMain instance when created
    val settings = new Settings()
    settings.usejavacp.value = true
    val writer = new JPrintWriter(Console.out, true)
    val engine = new IMain(settings)
    val compiler = engine.asInstanceOf[Compilable]

    var inputVal : Int = _
    var compiledObj : CompiledScript = _

    // compile given script
    def compileScript(givenCode : String) {
      compiledObj = compiler.compile(givenCode)
    }

    // evaluate
    def evalCompiled(): Unit = {
      compiledObj.eval()
    }

    //compiledObj
    def getCompiledObj(): CompiledScript = {
      compiledObj
    }

    // evaluate
    def evalCompiledSchema(): Unit = {
      println(compiledObj.eval())
    }

    // set input value
    def setInput(givenInput:Int) {
      inputVal = givenInput
    }

    // bind input variable
    def bindInput() {
      engine.bind("inputVal", "Int", inputVal)
    }

    /**
      * Schecma from given code
      * @param step
      * @return
      */
    override def evaluateSchema(code: String): StructType = {
      logger.debug("BaseCodeEvaluator:evaluateSchema")
      compileScript(name)
      evalCompiled()
      val evSchema = compiledObj.eval()
      println("************dynamic schema****************")
      println(evSchema)
      evSchema.asInstanceOf[StructType]
    }


  }

}


/**
  * A Evaluator interface for dynamic scala code
  */
trait IMainCodeEvaluator extends BaseTrait {

  var name: String = _


  /**
    * Schecma from given code
    * @param step
    * @return
    */
  def evaluateSchema(code: String): StructType

}

