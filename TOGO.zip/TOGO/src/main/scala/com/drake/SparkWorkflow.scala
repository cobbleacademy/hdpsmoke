package com.drake

import org.apache.spark.sql.SparkSession
import org.json4s._
import org.json4s.jackson.JsonMethods._

import scala.io.Source
import com.drake.model.Model.{Attribute, Step, Workflow}
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.types.{StringType, StructField, StructType}


object SparkWorkflow {

  def main(args: Array[String]): Unit = {

    implicit val formats = DefaultFormats

    val bufferedFile = Source.fromFile("src/main/resources/workflow.json")
    println("printing json contents")
    val json = parse(bufferedFile.getLines.mkString)
    println(json)
    val workflow = json.extract[Workflow]
    println(workflow)
    bufferedFile.close()


    val sparkSession = SparkSession.builder.
      master("local")
      .appName(workflow.process)
      .getOrCreate()


    val schema = StructType(
      Array(StructField("transactionId", StringType),
        StructField("customerId", StringType),
        StructField("itemId", StringType),
        StructField("amountPaid", StringType)))

    val step = workflow.steps(0)
    //val stepOpts = step.options.getOrElse(Seq(Attribute("","")))
    //val stepOptsMap = Map(stepOpts map {a => a.key -> a.value}: _*)
    //val stepAttrs = step.attributes.getOrElse(Seq(Attribute("","")))
    //val stepAttrsMap = Map(stepAttrs map {a => a.key -> a.value}: _*)
    val stepOpts = step.options.getOrElse(Map())
    val stepAttrs = step.attributes.getOrElse(Map())

    //create stream from folder
    val fileStreamDf = sparkSession.readStream
        .options(stepOpts)
      .schema(schema)
      .csv(stepAttrs.getOrElse("path", ""))

    val trans = workflow.steps(1)
    //val transOpts = trans.options.getOrElse(Seq(Attribute("","")))
    //val transOptsMap = Map(transOpts map {a => a.key -> a.value}: _*)
    //val transAttrs = trans.attributes.getOrElse(Seq(Attribute("","")))
    //val transAttrsMap = Map(transAttrs map {a => a.key -> a.value}: _*)
    val transOpts = trans.options.getOrElse(Map())
    val transAttrs = trans.attributes.getOrElse(Map())

    val multiplyDf = fileStreamDf.withColumn("amountPaid", fileStreamDf("amountPaid") * 2)
//    val transQuery = multiplyDf
//      .writeStream
//      .format(trans.format)
//      .options(transOptsMap)
//      .trigger(Trigger.ProcessingTime(trans.trigger.get))
//      .start()
//
//    transQuery.awaitTermination()


    val sink = workflow.steps(2)
    //val sinkOpts = sink.options.getOrElse(Seq(Attribute("","")))
    //val sinkOptsMap = Map(sinkOpts map {a => a.key -> a.value}: _*)
    //val sinkAttrs = sink.attributes.getOrElse(Seq(Attribute("","")))
    //val sinkAttrsMap = Map(sinkAttrs map {a => a.key -> a.value}: _*)
    val sinkOpts = step.options.getOrElse(Map())
    val sinkAttrs = step.attributes.getOrElse(Map())

    val outQuery = multiplyDf
      .writeStream
      .format(sink.format.get)
      .options(sinkOpts)
      .trigger(Trigger.ProcessingTime(sinkAttrs.getOrElse("trigger","")))
      .start()

    outQuery.awaitTermination()

  }

}
