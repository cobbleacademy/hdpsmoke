package com.drake.editor

import com.drake.SparkHelper
import com.drake.function.Func.uuid
import com.drake.model.Model.{SplitDataFrame, Splitter, Step}
import com.drake.reader.StaticSourceReader
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable

/**
  * An Invalid Config Builder to capture data quality errors
  */
class InvalidConfigBuilder(handlername: String) extends DefaultEditorBuilder(handlername) {

  name = handlername

  /**
    * Returns the transformed input DataFrame
    *
    * @param step
    * @return
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {

    //
    //
    //
    val sess = SparkHelper.getSparkSession()
    val stepAttrs = step.attributes.getOrElse(Map())
    val inclAttrs = step.include.getOrElse(Map())
    val convAttrs = step.conversions.getOrElse(Array[Map[String, String]]())
    val splitter = step.splitter.getOrElse(Splitter("", Seq[Map[String, String]]()))

    // load invalid config for given src_system and table
    StaticSourceReader.initializeStaticSources(stepAttrs)
    val configArr = StaticSourceReader.getInvCfgData()

    // RUN ALL INVALID FUNCTIONS IN SEQUENCE

    //
    def rowDataTypeChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("data_type_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        val dataTypeName = chkCol.getAs[String]("data_type")
        try {
          //row.getAs(colName).getClass
          dataTypeName match {
            case "Int" => if (row.getAs(colName).toString.equals(row.getAs[Int](colName).toString.toInt)) row.getAs[Double](colName).getClass
            case "Long" => if (row.getAs(colName).toString.equals(row.getAs[Long](colName).toString.toLong)) row.getAs[Double](colName).getClass //if (!row.getAs(colName).isInstanceOf[Long]) row.getAs(colName).getClass //println("Verifying Long :" + row.getAs(colName).getClass+ " " + row.getAs(colName).isInstanceOf[Long] + " "+colName)
            case "String" => if (row.getAs(colName).toString.equals(row.getAs[String](colName).toString)) row.getAs[Double](colName).getClass
            case "Float" => if (row.getAs(colName).toString.equals(row.getAs[Float](colName).toString.toFloat)) row.getAs[Double](colName).getClass
            case "Double" => if (row.getAs(colName).toString.equals(row.getAs[Double](colName).toString.toDouble)) row.getAs[Double](colName).getClass
            case _ => ""
          }
        } catch {
          case x: Throwable => if (colList.length > 0) colList += "~" + colName else colList += colName
        }
      })
      colList
    })
    //
    def rowNullChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("null_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == null) {if (colList.length > 0) colList += "~" + colName else colList += colName}
      })
      colList
    })
    //
    def rowEmptyChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("empty_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == "") {if (colList.length > 0) colList += "~" + colName else colList += colName}
      })
      colList
    })



    //
    val totalRecCount = input.count
    var mutColChkMap = mutable.Map[String, mutable.Map[String, Long]]()
    val colDupChkStat = "sum_dup_chk_cnt"
    configArr.foreach( chkCol => {
      val colName = chkCol.getAs[String]("col_name")
      val cnt = input.groupBy(colName).count.filter("count = 1").count
      var innrMap = mutColChkMap.getOrElse(colDupChkStat, mutable.Map[String, Long]())
      innrMap += colName -> (totalRecCount - cnt)
      mutColChkMap += colDupChkStat -> innrMap
    })

    //
    val chkStatDF = input
      .withColumn("datatypechkstat", rowDataTypeChk(struct(input.columns.map(col): _*)))
      .withColumn("nullchkstat", rowNullChk(struct(input.columns.map(col): _*)))
      .withColumn("emptychkstat", rowEmptyChk(struct(input.columns.map(col): _*)))


    // RUN SUMMATATIONs on ABOVE FUNCTIONS


    //
    List("sum_range_chk_cnt","sum_const_chk_cnt")
      .foreach(sumCol => {
      configArr.foreach( chkCol => {
        val colName = chkCol.getAs[String]("col_name").toString
        var innrMap = mutColChkMap.getOrElse(sumCol, mutable.Map[String, Long]())
        innrMap += colName -> 0
        mutColChkMap += sumCol -> innrMap
      })
    })
    //
    val sumColMap = Map(
      "sum_dtype_chk_cnt" -> "datatypechkstat",
      "sum_null_chk_cnt" -> "nullchkstat",
      "sum_empty_chk_cnt" -> "emptychkstat"
      )
    sumColMap.foreach(sumCol => {
      configArr.foreach( chkCol => {
        val colName = chkCol.getAs[String]("col_name").toString
        val cnt = chkStatDF.filter(col(sumCol._2).contains(colName)).count
        var innrMap = mutColChkMap.getOrElse(sumCol._1, mutable.Map[String, Long]())
        innrMap += colName -> cnt
        mutColChkMap += sumCol._1 -> innrMap
      })
    })


    //
    StaticSourceReader.broadcastSumChkColReference(mutColChkMap.map(f => f._1 -> f._2.toMap).toMap)
    var immutColChkMap = StaticSourceReader.getSumChkColData()

    //
    val sumChkStatRawDF = StaticSourceReader.getSampleSumChkColDataFrame(stepAttrs)
    val sumChkStatInitDF = immutColChkMap.keys.foldLeft(sumChkStatRawDF)((sumChkStatRawDF, colNm) => sumChkStatRawDF.withColumn(colNm , lit("0") ) )
    //
    //
    def rowReplaceChkVal = udf((colNm: String, colGrp: String) => {
      val ret: Long = immutColChkMap.getOrElse(colGrp, mutable.Map[String, Long]()).getOrElse(colNm, 0)
      ret
    })

    //
    val sumChkStatDF = immutColChkMap.keys.foldLeft(sumChkStatInitDF)((sumChkStatInitDF, colNm) => sumChkStatInitDF.withColumn(colNm, rowReplaceChkVal(col("col_name"), lit(colNm)) ) )


    // additional columns event/process timestamps
    val sumChkHistMap = Map(
      "src_system" -> "$args#0",
      "event_dt" -> "$args#1",
      "event_hr" -> "$args#2",
      "process_epoch" -> "$sys#processEpochSec",
      "process_dt" -> "$sys#processDt",
      "process_hr" -> "$sys#processHr"
    )
    // Final sumchkstat with additional columns
    val sumChkStatFnlDF = includeAttributeTransform(sumChkStatDF, sumChkHistMap)
    sumChkStatFnlDF.createOrReplaceTempView("sumChkStatFnlDF")
    val iostatqry =
      """
        |insert into table invalid_col_stats partition(src_system,event_dt)
        |select table_name,col_name,sum_dtype_chk_cnt,sum_null_chk_cnt,
        |sum_empty_chk_cnt,sum_dup_chk_cnt,sum_range_chk_cnt,sum_const_chk_cnt,
        |event_hr,process_epoch,process_dt,process_hr,src_system,event_dt
        | from sumChkStatFnlDF
      """.stripMargin
    sess.sql(iostatqry)

    //sumChkStatFnlDF.show(false)
    //sess.sql("select * from invalid_col_stats").show(false)

    //
    def concatColChkPrefix = udf((pfx: String, colVal: String) => {
      if (!colVal.isEmpty) pfx + colVal else ""
    })


    // create stat column to capture combined invalid reason
    val preStatChkStatDF = chkStatDF
      .withColumn("uuid", uuid())
      .withColumn("stat", concat_ws(" ",concatColChkPrefix(lit("DataTypeCheck:"),col("datatypechkstat")), concatColChkPrefix(lit("NullCheck:"),col("nullchkstat")), concatColChkPrefix(lit("EmptyCheck:"),col("emptychkstat"))))
    val statChkStatDF = preStatChkStatDF.withColumn("stat", trim(col("stat")))
    val statOnlyDF = includeAttributeTransform(statChkStatDF, inclAttrs)

    //
    var mutSplitDfSeq: Seq[SplitDataFrame] = Seq[SplitDataFrame]()
    //
    if (!splitter.tempView.isEmpty) {
      // register tempView as
      statOnlyDF.createOrReplaceTempView(splitter.tempView)
      splitter.splits.foreach(f => {
        val currDf: DataFrame = categoryTransform(statOnlyDF, f)
        val currSplitDf = SplitDataFrame(f.getOrElse("label", ""), currDf)
        mutSplitDfSeq = mutSplitDfSeq :+ currSplitDf
      })
    }



    //
    // process before moving to next step
    //
//    var convDfVar: DataFrame = statOnlyDF
//    //
//    if (!convAttrs.isEmpty) convDfVar = recursiveCategoryTransform(1, statOnlyDF, convAttrs)
//    //
//    val convDf = convDfVar
//
//
//    //
//    convDf

    //
    mutSplitDfSeq
  }
}
