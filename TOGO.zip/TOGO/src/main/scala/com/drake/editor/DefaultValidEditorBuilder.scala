package com.drake.editor

import com.drake.model.Model.{SplitDataFrame, Step}
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.sql.functions.{col, lit, struct, udf}

/**
  * A Default Editor Builder for CSV File
  */
class DefaultValidEditorBuilder(handlername: String) extends EditorBuilder {

  name = handlername

  /**
    * Returns the transformed input DataFrame
    *
    * @param step
    * @return
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {
    //
    def rowHasNull = udf((row: Row) => row.anyNull)

    //
    val statusDf = input
      .withColumn("fwstatus", rowHasNull(struct(input.columns.map(col): _*)))

    val validDf = statusDf.filter(statusDf("fwstatus") === lit("false")).drop("fwstatus")

    //validDf

    //
    Seq(SplitDataFrame(step.label.getOrElse(""), validDf))
  }
}
