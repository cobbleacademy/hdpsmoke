package com.drake.status

import java.text.SimpleDateFormat
import java.util.Calendar

import com.drake.{SessionDataHelper, SparkHelper}
import com.drake.model.Model.Step
import org.apache.spark.sql.functions.{current_timestamp, lit}

import scala.collection.mutable

/**
  * A Helper to record status either begin or end of the workflow
  */
object StatusBuilderHelper {


  /**
    * Store the status of read file
    *
    * @param step
    */
  def logStatus(step: Step, stepMap: mutable.Map[String, String], end: Boolean): Unit = {
    //
    val sparkSession = SparkHelper.getSparkSession()
    val statusComment = step.attributes.getOrElse(Map()).getOrElse("statusComment", "")
    var endTime: String = ""
    if (end) endTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SXXX").format(Calendar.getInstance().getTime())

    //
    import sparkSession.implicits._
    //
    val statusDf = Seq(
      (stepMap.get("fileName"), stepMap.get("fileDt"), stepMap.get("fileHr"), stepMap.get("count")
        , stepMap.get("startTime"), endTime, statusComment, stepMap.get("srcSystem")
      )
    ).toDF("file_name", "file_dt", "file_hr", "record_count", "start_time", "end_time", "comment", "src_system")

    //
    StatusBuilder(step.name).statusSink(step, statusDf)

  }


  /**
    * Store the status of read file
    *
    * @param step
    */
  def beginLogStatus(step: Step): Unit = {
    //
    val sessDataMap = SessionDataHelper.getSessionData()
    logStatus(step, sessDataMap.getOrElse(step.name, mutable.Map[String, String]()), false)
  }


  /**
    * Store the status of read file
    *
    * @param step
    * @param statusFrom step name to retrieve session data
    */
  def endLogStatus(step: Step, statusFrom: String): Unit = {
    //
    val sessDataMap = SessionDataHelper.getSessionData()
    logStatus(step, sessDataMap.getOrElse(statusFrom, mutable.Map[String, String]()), true)
  }


}
