package com.drake

import scala.reflect.runtime.universe.{Quasiquote, runtimeMirror}
import scala.tools.reflect.ToolBox

object TBoxApp {
  def main1(args: Array[String]): Unit = {
    val mirror = runtimeMirror(getClass.getClassLoader)
    val tb = ToolBox(mirror).mkToolBox()

    val data = Array(1, 2, 3)

    println("Data before function applied on it")
    println(data.mkString(","))


    println("Please enter the map function you want:")
    println("def function(x: Int): Int = x + 2")
    //val function = scala.io.StdIn.readLine()
    val function = "def function(x: Int): Int = x + 2"
    val functionWrapper = "object FunctionWrapper { " + function + "}"
    val functionSymbol = tb.define(tb.parse(functionWrapper).asInstanceOf[tb.u.ImplDef])

    // Map each element using user specified function
    val dataAfterFunctionApplied = data.map(x => tb.eval(q"$functionSymbol.function($x)"))

    println("Data after function applied on it")
    println(dataAfterFunctionApplied.mkString(","))
  }
  def main(args: Array[String]): Unit = {
    val mirror = runtimeMirror(getClass.getClassLoader)
    val tb = ToolBox(mirror).mkToolBox()

    println("Please enter the map function you want:")
    val schemaCode =
      s"""
         |import org.apache.spark.sql.types.{StringType, StructField, StructType}
         |
         |def getSchema(): StructType = {
         |  val schema = StructType(
         |    Array(StructField("transactionId", StringType),
         |      StructField("customerId", StringType),
         |      StructField("itemId", StringType),
         |      StructField("amountPaid", StringType)))
         |schema
         |}
         |
         |""".stripMargin
    println(schemaCode)
    //val function = scala.io.StdIn.readLine()
    val function = "def function(x: Int): Int = x + 2"
    val functionWrapper = "object FunctionWrapper { " + schemaCode + "}"
    val functionSymbol = tb.define(tb.parse(functionWrapper).asInstanceOf[tb.u.ImplDef])

    // Map each element using user specified function
    val dataAfterFunctionApplied = tb.eval(q"$functionSymbol.getSchemaCodeEvaluator()")

    println("Data after function applied on it")
    println(dataAfterFunctionApplied)
  }
}