import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HelloComponent } from './hello.component';
import { WorkflowListComponent } from './core/workflow-list.component';
import { WorkflowComponent } from './core/workflow.component';
import { ReaderComponent } from './core/reader.component';
import { EditorComponent } from './core/editor.component';
import { WriterComponent } from './core/writer.component';
import { FlowViewComponent } from './core/flowview.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'workflow',
    pathMatch: 'full'
  },
  {
    path: 'hello',
    component: HelloComponent
  },
  {
    path: 'workflowlist',
    component: WorkflowListComponent
  },
  {
    path: 'workflow/:name/:mode',
    component: WorkflowComponent
  },
  {
    path: 'workflow',
    component: WorkflowComponent
  },
  {
    path: 'reader',
    component: ReaderComponent
  },
  {
    path: 'editor',
    component: EditorComponent
  },
  {
    path: 'writer',
    component: WriterComponent
  },
  {
    path: 'flowview',
    component: FlowViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {
}