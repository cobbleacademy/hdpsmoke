import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';


// worklist modules
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
// worklist modules

import { AppRoutingModule } from './app-routing.module';
//import { HttpModule, JsonpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { NgxJsonViewerModule } from 'ngx-json-viewer';
import { AceEditorModule } from 'ng2-ace-editor';


import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { BaseStepComponent } from './core/basestep.component';
import { WorkflowListComponent } from './core/workflow-list.component';
import { HeaderComponent } from './core/header.component';
import { WorkflowComponent } from './core/workflow.component';
import { ReaderComponent } from './core/reader.component';
import { EditorComponent } from './core/editor.component';
import { WriterComponent } from './core/writer.component';
import { FlowViewComponent } from './core/flowview.component';

import { StepSelectionService } from './core/data/stepselection.service';
import { WorkflowDataService } from './core/data/workflowdata.service';
import { WorkflowCacheService } from './core/data/workflowcache.service';



@NgModule({
  imports:      [ 
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatStepperModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    // worklist module
    MatProgressSpinnerModule,
    MatTableModule,
    MatPaginatorModule,
    // worklist modules
    //HttpModule,
    HttpClientModule,
    NgxJsonViewerModule,
    AceEditorModule,
    //JsonpModule 
    ],
  declarations: [ AppComponent, HelloComponent, BaseStepComponent, WorkflowListComponent, HeaderComponent, WorkflowComponent, ReaderComponent, EditorComponent, WriterComponent, FlowViewComponent, ],
  providers: [ StepSelectionService, WorkflowDataService, WorkflowCacheService ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
