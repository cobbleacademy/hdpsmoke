export interface WorkflowDef{
    name: string;
    file: string;
    mode: string;
}