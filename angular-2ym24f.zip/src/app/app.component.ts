import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { LayoutDirective, FlexDirective } from '@angular/flex-layout';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
//import { Http, Response } from "@angular/http";
import { HttpClient, HttpResponseBase,  HttpResponse} from "@angular/common/http";


import {StepSelection} from './core/model/models';
import {StepSelectionService} from './core/data/stepselection.service';
import {DataSource} from '@angular/cdk/table';
import {Observable} from 'rxjs/Observable';
import { Yaml, jsyaml } from 'js-yaml';


@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit {

  name = 'Angular';
  selectedLayout = 1
  data: object [];
  listFiles = [];

  constructor(public selectionService: StepSelectionService) {
    var blocks: object [];
    //blocks = Yaml.safeLoad(http.readFile('src/app/assets/report.yml', 'utf8'));  
    //console.log(blocks)

    this.selectionService.getJsonData()
      .then( response => {
        //console.log('ALL Data: ');
        //console.log(response);
        this.data = response;//.body;
      })
      .catch( error => {
        console.log('Error Getting Data: ', error);
      });
    
    this.selectionService.getFiles()
      .subscribe(resp => {
        //console.log('on subscribe: ');
        resp.body
        });
      // .then( (response: Response) => {
      //   console.log('ALL FILES: ', response);
      //   this.data = response._body;
      // })
      // .catch( error => {
      //   console.log('Error Getting Data: ', error);
      // });


    // this.selectionService.createArticle()
    // .subscribe(
    //   article => {
    //     //console.log("post data...");
    //     //console.log(article);
    //   },
    //   err => {
    //     //console.log('Error Posting Data: ');
    //     //console.log(err);
    //   });

  }

  ngOnInit() {
    //console.log('ALL NEW Data: ', this.data);
  }

}