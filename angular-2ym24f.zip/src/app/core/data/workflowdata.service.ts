import { Injectable } from '@angular/core';
import { KeyVal, KeyValGroup, Splitter, Step, Basic, Workflow } from '../model/models';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpResponse } from "@angular/common/http";

@Injectable()
export class WorkflowDataService {

  KEYVAL_DATA = {key:"",value:"",remove:true}; //new KeyVal("","",true);
  SPLIT_DATA = {tempView: "", splits: []};
  STEP_DATA = {
    fields: [],
    options: [],
    attributes: [],
    conversions: [],
    include: [],
    post: [],
    splitter: {}
  };
  WFLOW_DATA = { 
    fields: [],
    attributes: [],
    steps: [],
  };
  // STEP_DATA = {
  //   name: "",
  //   model: "",
  //   from: "",
  //   format: "",
  //   command: "",
  //   label: "",
  //   tabs: [],
  //   options: {},
  //   attributes: {},
  //   conversions: [],
  //   include: {},
  //   post: {},
  //   splitter: {}
  // };
  // WFLOW_DATA = { 
  //   process: "",
  //   mode: "", 
  //   qualityConfig: "",
  //   qualityStatus: "",
  //   triggerProc: "",
  //   triggerScript: "",
  //   triggerScriptPath: "",
  //   steps: [],
  //   attributes: {}
  // };
  BASIC_DATA = { 
    fields: [],
    attributes: [],
    steps: [],
  };

  constructor(private http: HttpClient) {
  }

  getData(): Observable<Workflow> {
    return of<Workflow>(this.WFLOW_DATA);
  }

  getWorkflow(): Workflow {
    return this.WFLOW_DATA;
  }

  getClonedStep(): Step {
    return (JSON.parse(JSON.stringify(this.STEP_DATA)));
  }
  getSampleStep(): Step {
    return this.STEP_DATA;
  }
  getSampleKeyVal(): KeyVal {
    return (JSON.parse(JSON.stringify(this.KEYVAL_DATA)));
  }

  showWorkflowStatus() {
    console.log('workflow raw status: ', this.WFLOW_DATA.process)
  }

  removeStep(step: Step) {
    if (this.WFLOW_DATA.steps.length > 0) {
      this.WFLOW_DATA.steps.forEach( (item, index) => {
        if((<Step>item).name == step.name) this.WFLOW_DATA.steps.splice(index,1);
      });
    }
  }

  stringify() {
    let jsonStr = JSON.stringify(this.WFLOW_DATA);
    //console.log("JSON String: ", jsonStr);
    return jsonStr;
  }

  addStep(step: Step) {
    this.removeStep(step)
    this.WFLOW_DATA.steps.push(step)
  }

  dataLength() {
    return 1;
  }
}