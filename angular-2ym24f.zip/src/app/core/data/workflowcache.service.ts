import { Injectable } from '@angular/core';
import { KeyVal, KeyValGroup, Step, Basic, Workflow, JsonWorkflow } from '../model/models';
import { WorkflowDef } from '../../workflowdef';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpResponse } from "@angular/common/http";
import { StepSelectionService } from './stepselection.service';
import { WorkflowDataService } from './workflowdata.service';
import YAML = require('yamljs');
//import { Yaml, jsyaml, yaml } from 'js-yaml';
import jsyaml = require('js-yaml');

@Injectable()
export class WorkflowCacheService {

  //
  selectedWorkflow: Workflow;
  selectedStepReader: Step;
  selectedStepEditor: Step;
  selectedStepWriter: Step;


  //
  workflowColumns = [ 'name', 'file', 'mode', 'operations'];
  //
  wflworkflowList: WorkflowDef[] = [
    { name:'FileFlow', file:'./resources/workflow_hdfs.yml', mode: 'batch'},
    { name:'KafkaFlow', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow02', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow02', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow03', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow03', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow04', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow04', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow05', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow05', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow06', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow06', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow07', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow07', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow08', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow08', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow09', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow09', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow10', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow10', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow11', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow11', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow12', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow12', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow13', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow13', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow14', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow14', file:'./resources/workflow_kafka.yml', mode: 'stream'},
  ];

  seedBasicData = [
    new KeyVal('process', 'FileFlow', false ),
    new KeyVal('mode', 'batch', false ),
    new KeyVal('qualityConfig', 'invalid_col_config', false ),
    new KeyVal('qualityStatus', 'invalid_col_stats', false ),
    new KeyVal('triggerProc', 'proc', false ),
    new KeyVal('triggerScript', 'trigger_run.sh', false ),
    new KeyVal('triggerScriptPath', './scripts', false),
  ];

  seedReaderData = [
    new KeyVal('name', 'readKafka', false),
    new KeyVal('model', 'source', false),
    new KeyVal('format', 'kafka', false),
    new KeyVal('label', 'kafkaStream', false),
  ];

  seedEditorData = [
    new KeyVal('name', 'transKafka', false),
    new KeyVal('model', 'transformation', false),
    new KeyVal('from', 'kafkaStream', false),
    new KeyVal('label', 'transStream', false),
  ];

  seedWriterData = [
    new KeyVal('name', 'sinkKafka', false),
    new KeyVal('model', 'sink', false),
    new KeyVal('format', 'kafka', false),
    new KeyVal('from', 'transStream', false),
  ];

  constructor(private workflowDataService: WorkflowDataService, private stepSelectionService: StepSelectionService) { }

  findKeyVal(kvArr: KeyVal[], key: string) {
    let idx = kvArr.findIndex(i => i.key === key);
    let keyVal = (<KeyVal>(kvArr[idx])).value;
    return keyVal;
  }

  filterStepModel(model) {
    return this.selectedWorkflow.steps.filter((s: Step, i: number, a: Step[]) => {
      // let idx = s.fields.findIndex(i => i.key === "model");
      // let stepModel = (<KeyVal>(s.fields[idx])).value;
      // return stepModel == model;
      return model == this.findKeyVal(s.fields, 'model');
    }
    );
  }
  filterStepName(name) {
    return this.selectedWorkflow.steps.filter((s: Step, i: number, a: Step[]) => {
      // let idx = s.fields.findIndex(i => i.key === "name");
      // let stepName = (<KeyVal>(s.fields[idx])).value;
      // return stepName == name;
      return name == this.findKeyVal(s.fields, 'name');
    }
    );
  }

  stepSources(): Step[] { return this.filterStepModel('source'); }
  stepTransformations() { return this.filterStepModel('transformation'); }
  stepSinks() { return this.filterStepModel('sink'); }

  clonedSeedData(seedData: {}) {
    return (JSON.parse(JSON.stringify(seedData)));
  }


  createStep(modelType) {
    //
    let name = modelType + 'New';
    let sampleStep = this.workflowDataService.getClonedStep();
    //
    if (modelType == 'reader') {
      sampleStep.fields = this.clonedSeedData(this.seedReaderData);
    } else if (modelType == 'editor') {
      sampleStep.fields = this.clonedSeedData(this.seedEditorData);
    } else if (modelType == 'writer') {
      sampleStep.fields = this.clonedSeedData(this.seedWriterData);
    }
    let nIdx = sampleStep.fields.findIndex(i => i.key === "name");
    (<KeyVal>sampleStep.fields[nIdx]).value = name;
    //
    this.selectedWorkflow.steps.push(sampleStep);
    //
    this.selectStep(name);
  }

  selectStep(name) {
    let selSteps: Step[] = this.filterStepName(name);
    if (selSteps) {
      let model = this.findKeyVal(selSteps[0].fields, 'model');
      //
      if (model == 'source') {
        this.selectedStepReader = selSteps[0];
      } else if (model == 'transformation') {
        this.selectedStepEditor = selSteps[0];
      } else if (model == 'sink') {
        this.selectedStepWriter = selSteps[0];
      }
      console.log('step is cached. name: ' + name + ' model: ' + model);
    }
  }

  getSelectedStep(modeltype) {
    console.log('step from cache. model: ' + modeltype);
    if (modeltype == 'reader') {
      return this.selectedStepReader;
    } else if (modeltype == 'editor') {
      return this.selectedStepEditor;
    } else if (modeltype == 'writer') {
      return this.selectedStepWriter;
    }
  }

  createOrGetWorkflow() {

    if (!this.selectedWorkflow) {
      console.log('***************');
      this.selectedWorkflow = this.workflowDataService.getWorkflow();
      this.selectedWorkflow.fields = this.clonedSeedData(this.seedBasicData);
      let sampleSrc = this.workflowDataService.getClonedStep();
      sampleSrc.fields = this.clonedSeedData(this.seedReaderData);
      let sampleTrans = this.workflowDataService.getClonedStep();
      sampleTrans.fields = this.clonedSeedData(this.seedEditorData);
      let sampleSink = this.workflowDataService.getClonedStep();
      sampleSink.fields = this.clonedSeedData(this.seedWriterData);
      // let tempOpts: KeyVal[] = []
      // tempOpts.push(new KeyVal('opt1','optval1'));
      // tempOpts.push(new KeyVal('opt2','optval2'));
      // let i = 0;
      // for(i = 0;i < tempOpts.length;i++) {
      //   let kv = <KeyVal>tempOpts[i];
      //   console.log(kv.key,kv.value);
      //   //console.log(tempOpts[i]);
      // }
      //
      this.selectedWorkflow.steps.push(sampleSrc);
      this.selectedWorkflow.steps.push(sampleTrans);
      this.selectedWorkflow.steps.push(sampleSink);
    }
    return this.selectedWorkflow;
  }


  selectWorkflow(name) {
    //
    //this.selectedWorkflow = this.workflowDataService.getWorkflow();
    //this.selectedWorkflow.fields = this.seedBasicData;
    //
    this.createOrGetWorkflow();
    let modeWDef: WorkflowDef[] = this.wflworkflowList.filter((w: WorkflowDef, i: number, a: WorkflowDef[]) => {return (w.name == name);})
    let mode = modeWDef ? modeWDef[0].mode : '';
    let pIdx = this.selectedWorkflow.fields.findIndex(i => i.key === "process");
    (<KeyVal>this.selectedWorkflow.fields[pIdx]).value = name;
    let mIdx = this.selectedWorkflow.fields.findIndex(i => i.key === "mode");
    console.log(' mode parameter found at: ' + mIdx);
    (<KeyVal>this.selectedWorkflow.fields[mIdx]).value = mode;
  }


  getStepListDefs() {
    let defs = [];
    if (this.selectedWorkflow) {
      this.selectedWorkflow.steps.forEach(step => {
        let name = '', model='', fro='', label='';
        step.fields.forEach(kv => {
          if (kv.key == 'name')
            name = kv.value;
          else if (kv.key == 'model')
            model = kv.value;
          else if (kv.key == 'from')
            fro = kv.value;
          else if (kv.key == 'label')
            label = kv.value;
        });
        defs.push({name:name,model:model,from:fro,label:label});
      });
    }
    return defs;
  }

  customStringify() {
    var jw = {};
    this.selectedWorkflow.fields.forEach(kv => {
      jw[kv.key] = kv.value;
    });
    jw.attributes = {};
    this.selectedWorkflow.attributes.forEach(kv => {
      jw.attributes[kv.key] = kv.value;
    });
    if (!Object.keys(jw.attributes).length > 0) jw.attributes = undefined;
    jw.steps = [];
    this.selectedWorkflow.steps.forEach(step => {
      var jstep = {};
      step.fields.forEach(kv => {
        jstep[kv.key] = kv.value;
      });
      jstep.options =  {};
      step.options.forEach(kv => {
        jstep.options[kv.key] = kv.value;
      });
      if (!Object.keys(jstep.options).length > 0) jstep.options = undefined;
      jstep.attributes =  {};
      step.attributes.forEach(kv => {
        jstep.attributes[kv.key] = kv.value;
      });
      if (!Object.keys(jstep.attributes).length > 0) jstep.attributes = undefined;
      jstep.conversions = [];
      step.conversions.forEach(kvg => {
        let jscg = {};
        kvg.group.forEach(kv => {
          jscg[kv.key] = kv.value;
        });
        jstep.conversions.push(jscg);
      });
      if (!jstep.conversions || !jstep.conversions.length > 0) jstep.conversions = undefined;
      jstep.include =  {};
      step.include.forEach(kv => {
        jstep.include[kv.key] = kv.value;
      });
      if (!Object.keys(jstep.include).length > 0) jstep.include = undefined;
      jstep.post =  {};
      step.post.forEach(kv => {
        jstep.post[kv.key] = kv.value;
      });
      if (!Object.keys(jstep.post).length > 0) jstep.post = undefined;
      if (step.splitter.splits) {
        jstep.splitter = {};
        jstep.splitter.splits = [];
        jstep.splitter.tempView = step.splitter.tempView;
        step.splitter.splits.forEach(kvg => {
          let jssg = {};
          kvg.group.forEach(kv => {
            jssg[kv.key] = kv.value;
          });
          jstep.splitter.splits.push(jssg);
        });
      }
      
      if (!jstep.splitter || !Object.keys(jstep.splitter).length > 0 || !jstep.splitter.splits || !jstep.splitter.splits.length > 0) jstep.splitter = undefined;
      jw.steps.push(jstep);
    });
    
    let jsonStr = JSON.stringify(jw, null, 2);
    //let jsonStr = JSON.stringify(jw);
    //let ystr = YAML.stringify(jw);
    //let a = jsyaml.safeDump(jw);
    //console.log("JSON String: ", jsyaml.dump(JSON.parse(jsonStr)));
    //console.log("JSON String: ", YAML.stringify(JSON.parse(jsonStr)));

    return jsonStr;
  }

}