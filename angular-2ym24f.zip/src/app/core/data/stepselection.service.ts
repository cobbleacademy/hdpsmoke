import { Injectable } from '@angular/core';
import { StepSelection } from '../model/models';
import { Observable, of } from 'rxjs';
import { pipe } from 'rxjs';
import { map } from 'rxjs/operators';
//import { Http, Response } from "@angular/http";
import { HttpClient, HttpHeaders, HttpResponse } from "@angular/common/http";

@Injectable()
export class StepSelectionService {

  SELECTION_DATA: StepSelection =
    { id: 1, name: 'Workflow' };

  constructor(private http: HttpClient) {
  }

  private extractData(res: HttpResponse<any[]>) {
    let body = res.body;
    return body || {};
  }
  private handleError(error: any) {
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
  getFiles(): Observable<HttpResponse<any[]>> {

    console.log('calling...')
    
    let names: string[] = ['a','b'];

    //return of<string[]>(names);

    //console.log("files: " + relt);
    //resp => {console.log('resp:' + resp); resp}
    //.catch(this.handleError);
    return this.http.get<any[]>("/assets/", {observe: 'response', responseType: 'text' as 'json'});
  }

  createArticle(): Observable<Object> {
    let httpHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    });
    let options = {
      headers: httpHeaders
    };
    return this.http.post<Object>('/assets/create.json',
      {
        id: 100,
        title: 'Java Functional Interface',
        category: 'Java 8',
        writer: 'Krishna'
      }
    );
  }


  getData(): Observable<StepSelection> {
    return of<StepSelection>(this.SELECTION_DATA);
  }

  getJsonData(): Promise<any[]> {
    return this.http.get<any[]>('/assets/report.yml',{observe: 'response', responseType: 'text' as 'json'}).toPromise()
    .then(rs => rs.body);
  }

  getSelection(): number {
    return this.SELECTION_DATA.id;
  }

  setSelection(id, name) {
    this.SELECTION_DATA.id = id;
    this.SELECTION_DATA.name = name;
  }

  dataLength() {
    return 1;
  }
}