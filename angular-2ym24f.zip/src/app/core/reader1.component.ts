import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import {Workflow, Step, Splitter} from './core/model/models';
import {WorkflowDataService} from '../core/data/workflowdata.service';

@Component({
  selector: 'app-reader1',
  templateUrl: './reader.component.html',
  styleUrls: [ './reader.component.css' ]
})
export class Reader1Component implements OnInit {

  name = 'Angular';

  stepInd: number = 1;
  selectedInd: number = -1;

  dynamicForm: FormGroup;
  optionsForm: FormGroup;
  attrsForm: FormGroup;
  postForm: FormGroup;

  step: Step = {}

  seedData = [
    { key: 'name', value: 'readKafka', delete: false },
    { key: 'model' , value: 'source', delete: false },
    { key: 'format' , value: 'kafka', delete: false },
    { key: 'label' , value: 'kafkaStream', delete: false }
  ];

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  constructor(private fb: FormBuilder, public workflowDataService: WorkflowDataService) {}

  ngOnInit() {
    this.dynamicForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.step = this.workflowDataService.getSampleStep()
    this.seedFieldsFormArray();

    this.optionsForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.attrsForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.postForm = this.fb.group({
      fields: this.fb.array([])
    });

    console.log(`Array Size: `, this.fieldsFormArray.length);

    this.firstFormGroup = this.fb.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this.fb.group({
      secondCtrl: ['', Validators.required]
    });
  }

  selectedLayout = 1;

  seedFieldsFormArray() {
    this.seedData.forEach(seedDatum => {
      const formGroup = this.createFieldGroup();
      formGroup.addControl('key', this.getFormControl());
      formGroup.addControl('value', this.getFormControl());
      formGroup.patchValue(seedDatum);
      this.fieldsFormArray.push(formGroup);
    });
  }

  updateKeyValModel(kvMap: Map<string, string>, formArray: FormArray) {
    let i = 0
    for(i = 0;i < formArray.length;i++) {
      let fg = (<FormGroup>formArray.at(i))
      let fcKey = (<FormControl>fg.get('key'))
      let fcVal = (<FormControl>fg.get('value'))
      if (fcKey.value.trim.length > 0 && fcVal.value.trim.length > 0)
       kvMap.set(fcKey.value, fcVal.value);
    }
  }

  updateModel() {
    let i = 0
    let fldMap = new Map()
    this.updateKeyValModel(fldMap, (<FormArray>this.dynamicForm.get('fields')))
    this.step.name = fldMap.get('name');
    this.step.model = fldMap.get('model');
    this.step.from = fldMap.get('from');
    this.step.format = fldMap.get('format');
    this.step.command = fldMap.get('command');
    this.step.label = fldMap.get('label');
    this.step.options = fldMap.get('options');
    this.step.attributes = fldMap.get('attributes');
    this.step.conversions = fldMap.get('conversions');
    this.step.include = fldMap.get('include');
    this.step.post = fldMap.get('post');
    //
    this.updateKeyValModel(this.step.options, (<FormArray>this.optionsForm.get('fields')));
    //
    this.updateKeyValModel(this.step.attributes, (<FormArray>this.attrsForm.get('fields')));
    //
    this.updateKeyValModel(this.step.post, (<FormArray>this.postForm.get('fields')));
  }

  addFieldToFieldsFormArray() {
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    this.fieldsFormArray.push(formGroup);
  }

  removeFieldFromFieldsFormArray(index) {
    this.fieldsFormArray.removeAt(index);
  }

  get fieldsFormArray() {
    if (this.stepInd == 1) {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (this.stepInd == 2) {
      return (<FormArray>this.optionsForm.get('fields'));
    } else if (this.stepInd == 3) {
      return (<FormArray>this.attrsForm.get('fields'));
    } else if (this.stepInd == 4) {
      return (<FormArray>this.postForm.get('fields'));
    }
  }

  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  getFormControl() {
    return this.fb.control(null);
  }

  createFieldGroup() {
    return this.fb.group({});
  }

  save() {
    this.updateModel()
    console.log("Saving Workflow Step: " + this.step.name);
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < 4) {
      this.stepInd = this.selectedInd + 1
    }
  }

}
