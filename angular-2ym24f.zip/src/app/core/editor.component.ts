import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { BaseStepComponent } from '../core/basestep.component';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, KeyValGroup, Workflow, Step, Splitter } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent extends BaseStepComponent implements OnInit {

  stageInd = 3;
  stageName = 'editor';


  stepVals = ['basic', 'opts', 'attrs', 'convs', 'incl', 'post', 'split']

  seedData1 = [
    { key: 'name', value: 'transKafka', delete: false },
    { key: 'model', value: 'transformation', delete: false },
    { key: 'from', value: 'kafkaStream', delete: false },
    { key: 'label', value: 'transStream', delete: false }
  ];

  seedData = [
    new KeyVal('name', 'transKafka', false),
    new KeyVal('model', 'transformation', false),
    new KeyVal('from', 'kafkaStream', false),
    new KeyVal('label', 'transStream', false),
  ];

  constructor(public formBuilder: FormBuilder, public workflowDataService: WorkflowDataService, public workflowCacheService: WorkflowCacheService, public stepSelectionService: StepSelectionService, public route: ActivatedRoute, public router: Router) { super(formBuilder, workflowDataService, workflowCacheService, stepSelectionService, route, router); }

  ngOnInit() {
    super.baseStepInit();
  }

  selectedLayout = 1;

}