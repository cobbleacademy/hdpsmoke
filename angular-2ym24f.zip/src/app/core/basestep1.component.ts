import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, Workflow, Step, Splitter } from './core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';

@Component({
  template: ''
})
export class BaseStep1Component {

  name = 'Angular';
  jsonify = ""

  stageInd: number = 1;
  stageName: string = 'workflow';

  stepInd: number = 1;
  stepVals = ['basic', 'opts', 'attrs', 'convs', 'incl', 'post', 'split']
  selectedInd: number = -1;

  dynamicForm: FormGroup;
  optionsForm: FormGroup;
  attrsForm: FormGroup;
  convsForm: FormGroup;
  inclForm: FormGroup;
  postForm: FormGroup;
  splitterForm: FormGroup;

  step: Step = {};

  selectedStepForm: FormGroup;
  selectedStep: Step = {};

  seedData = [];
  
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;


  constructor(public formBuilder: FormBuilder, public workflowDataService: WorkflowDataService, public workflowCacheService:  WorkflowCacheService, public stepSelectionService: StepSelectionService) {}

  baseStepInit() {

    //
    this.stepSelectionService.setSelection(this.stageInd, this.stageName);

    //
    this.dynamicForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    //this.step = this.workflowDataService.getSampleStep()
    //this.seedFieldsFormArray();

    this.optionsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.attrsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.convsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.inclForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.postForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.splitterForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    console.log(`Array Size: `, this.fieldsFormArray.length);

    this.selectedStep = this.workflowCacheService.getSelectedStep();
    console.log('Returned selectedstep from Cache: '+ this.selectedStep.name);
    this.selectedStepForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });
    this.selectedStep.fields = this.seedData;
    this.toFormGroup(this.selectedStep.fields);

    //
    //
    this.firstFormGroup = this.formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this.formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

  toFormGroup(kvArr: KeyVal[]) {
    let fgArray: FormArray = this.fieldsFormArray;
    kvArr.forEach(kv => {
      // const formGroup = this.createFieldGroup();
      // formGroup.addControl('key', this.getFormControl());
      // formGroup.addControl('value', this.getFormControl());
      // formGroup.patchValue({key:kv.key,value:kv.value});
      // (<FormArray>this.selectedStepForm.get('fields')).push(formGroup);
      fgArray.push(this.formBuilder.group({key: kv.key, value: kv.value}));
    });
  }


  seedFieldsFormArray1() {
    this.seedData.forEach(seedDatum => {
      const formGroup = this.createFieldGroup();
      formGroup.addControl('key', this.getFormControl());
      formGroup.addControl('value', this.getFormControl());
      formGroup.patchValue(seedDatum);
      this.fieldsFormArray.push(formGroup);
    });
  }

  updateKeyValModel(kvMap: Map<string, string>, formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let fg = (<FormGroup>formArray.at(i));
      let fcKey = (<FormControl>fg.get('key'));
      let fcVal = (<FormControl>fg.get('value'));
      //console.log(fcKey.value + " ** " + fcKey.value.length + ' ** ' + fcVal.value.length);
      if (fcKey.value.length > 0 && fcVal.value.length > 0) {
        kvMap.set(fcKey.value, fcVal.value);
      }
      
    }
  }

  updateKeyValSetModel(kvMapArr: Map<string, string>[], formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let kvMap: Map<string, string>;
      let fgFArr = (<FormArray>(<FormGroup>formArray.at(i)).get('fields'+i));
      let j = 0;
      for(j = 0;j < fgFArr.length;j++) {
        let fg = (<FormGroup>fgFArr.at(j));
        let fcKey = (<FormControl>fg.get('key'));
        let fcVal = (<FormControl>fg.get('value'));
        if (fcKey.value.length > 0 && fcVal.value.length > 0) {
          console.log('fieldset map: ', fcKey.value, fcVal.value)
          kvMap.set(fcKey.value, fcVal.value);
        }
      }
      kvMapArr.push(kvMap)     
    }
  }

  updateKeyValHdrSetModel(hdrView: string, kvMapArr: Map<string, string>[], formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let fgFArr = (<FormArray>(<FormGroup>formArray.at(i)).get('fields'+i));
      let kvMap: Map<string, string>;
      let j = 0;
      for(j = 0;j < fgFArr.length;j++) {
        let fg = (<FormGroup>fgFArr.at(j));
        let fcKey = (<FormControl>fg.get('key'));
        let fcVal = (<FormControl>fg.get('value'));
        if (fcKey.value.length > 0 && fcVal.value.length > 0) {
          console.log('fieldhdrset map: ', fcKey.value, fcVal.value)
          if (i == 0)
            hdrView = fcVal.value;
          else 
            kvMap.set(fcKey.value, fcVal.value);
        }
      }
      kvMapArr.push(kvMap)     
    }
  }

  updateModel() {
    let fldMap = new Map();
    this.updateKeyValModel(fldMap, (<FormArray>this.dynamicForm.get('fields')));
    this.step.name = fldMap.get('name');
    this.step.model = fldMap.get('model');
    this.step.from = fldMap.get('from');
    this.step.format = fldMap.get('format');
    this.step.command = fldMap.get('command');
    this.step.label = fldMap.get('label');
    //this.step.conversions = fldMap.get('conversions');
    //
    this.updateKeyValModel(this.step.options, (<FormArray>this.optionsForm.get('fields')));
    if (!(this.step.options.size > 0)) this.step.options = undefined;
    //
    this.updateKeyValModel(this.step.attributes, (<FormArray>this.attrsForm.get('fields')));
    if (!(this.step.attributes.size > 0)) this.step.attributes = undefined;
    //
    this.updateKeyValSetModel(this.step.conversions, (<FormArray>this.convsForm.get('fields')));
    if (!(this.step.conversions.length > 0)) this.step.conversions = undefined;
    //
    this.updateKeyValModel(this.step.include, (<FormArray>this.inclForm.get('fields')));
    if (!(this.step.include.size > 0)) this.step.include = undefined;
    //
    this.updateKeyValModel(this.step.post, (<FormArray>this.postForm.get('fields')));
    if (!(this.step.post.size > 0)) this.step.post = undefined;
    //
    this.updateKeyValHdrSetModel(this.step.splitter.tempView, this.step.splitter.splits, (<FormArray>this.splitterForm.get('fields')));
    if (!this.step.splitter || !this.step.splitter.tempView) this.step.splitter = undefined;
    if (this.step.splitter && !(this.step.splitter.tempView.length > 0)) this.step.splitter = undefined;
    if (this.step.splitter && !(this.step.splitter.splits.length > 0)) this.step.splitter = undefined;
  }

  addFieldSetToFieldsFormArray() {
    const formArray = this.createFormArray()
    let atNumber: number = this.fieldsFormArray.length + 1
    const childformGroup = this.buildFormGroup()
    childformGroup.patchValue({ key: 'seq', value: ''+atNumber });
    childformGroup.removeControl('delete')
    formArray.push(childformGroup);
    //
    const formGroup = this.createFieldGroup();
    formGroup.addControl('fields'+this.fieldsFormArray.length, formArray);
    this.fieldsFormArray.push(formGroup);
  }

  addFieldHdrSetToFieldsFormArray() {
    const formArray = this.createFormArray()
    let atNumber: number = this.fieldsFormArray.length + 1
    const childformGroup = this.buildFormGroup()
    if (this.fieldsFormArray.length == 0) {
      childformGroup.patchValue({ key: 'tempView', value: '' });
      childformGroup.removeControl('delete')
    }
    formArray.push(childformGroup);
    //
    const formGroup = this.createFieldGroup();
    formGroup.addControl('fields'+this.fieldsFormArray.length, formArray);
    this.fieldsFormArray.push(formGroup);
  }

  removeFieldSetFromFieldsFormArray(setIndex) {
    if (this.fieldsFormArray.length-1 == setIndex)
      this.fieldsFormArray.removeAt(setIndex);
  }

  addFieldToFieldSetArray(setIndex) {
    //console.log("Adding Field At: " + setIndex);
    let fieldSetFormArray = (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields'+setIndex));
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    fieldSetFormArray.push(formGroup);
  }

  removeFieldFromFieldSetFormArray(setIndex, index) {
    (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields'+setIndex)).removeAt(index);
  }

  addFieldToFieldsFormArray1() {
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    this.fieldsFormArray.push(formGroup);
  }

  removeFieldFromFieldsFormArray1(index) {
    this.fieldsFormArray.removeAt(index);
  }
  

  get fieldsFormArray() {
    let localFormName =  this.stepVals[this.stepInd - 1]
    if (localFormName == 'basic') {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (localFormName == 'opts') {
      return (<FormArray>this.optionsForm.get('fields'));
    } else if (localFormName == 'attrs') {
      return (<FormArray>this.attrsForm.get('fields'));
    } else if (localFormName == 'convs') {
      return (<FormArray>this.convsForm.get('fields'));
    } else if (localFormName == 'incl') {
      return (<FormArray>this.inclForm.get('fields'));
    } else if (localFormName == 'post') {
      return (<FormArray>this.postForm.get('fields'));
    } else if (localFormName == 'split') {
      return (<FormArray>this.splitterForm.get('fields'));
    }
  }

  boolVal(boolStr) {
    return (String(boolStr) == 'true');
  }

  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  buildFormGroup() {
    const childformGroup = this.createFieldGroup();
    childformGroup.addControl('key', this.getFormControl());
    childformGroup.addControl('value', this.getFormControl());
    childformGroup.addControl('delete', this.getFormControl());
    return childformGroup;
  }

  getFormControl() {
    return this.formBuilder.control(null);
  }

  createFieldGroup() {
    return this.formBuilder.group({});
  }

  createFormArray() {
    return this.formBuilder.array([]);
  }

  save() {
    this.updateModel()
    console.log("Saving Workflow Step: " + this.step.name);
    this.workflowDataService.addStep(this.step)
    this.jsonify = this.workflowDataService.stringify();
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    console.log('doSelectedInd: ' + evt.selectedIndex + ' prev ind: ' + evt.previouslySelectedIndex);
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < this.stepVals.length) {
      this.stepInd = this.selectedInd + 1
    }
  }

}         
