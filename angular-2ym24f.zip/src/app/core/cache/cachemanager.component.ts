import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { Workflow, Step, Splitter } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { ActivatedRoute } from '@angular/router';
import { WorkflowDef } from '../workflowdef';


@Component({
  selector: 'app-cache',
  template: `<h1>Hello {{name}}!</h1>`,
  styles: [`h1 { font-family: Lato; }`]
})
export class CacheMangerComponent implements OnInit {

  //
  selectedWorkflow: Workflow;


  //
  workflowColumns = [ 'name', 'file', 'mode', 'operations'];
  //
  wflworkflowList: WorkflowDef[] = [
    { name:'FileFlow', file:'./resources/workflow_hdfs.yml', mode: 'batch'},
    { name:'KafkaFlow', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow02', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow02', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow03', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow03', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow04', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow04', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow05', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow05', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow06', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow06', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow07', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow07', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow08', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow08', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow09', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow09', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow10', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow10', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow11', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow11', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow12', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow12', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow13', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow13', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow14', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow14', file:'./resources/workflow_kafka.yml', mode: 'stream'},
  ];



  constructor(public workflowDataService: WorkflowDataService, stepSelectionService: StepSelectionService, private route: ActivatedRoute) { }

  ngOnInit() {}

  filterStepModel(model) {
    let retArr: WorkflowDef[] = this.selectedWorkflow.steps.filter((s: WorkflowDef, i: number, a: WorkflowDef[]) => {return s.model == 'source';});
    return retArr ? retArr[0] : {};
  }

  stepSources() { return this.filterStepModel('source'); }
  stepTransformations() { return this.filterStepModel('transformation'); }
  stepSinks() { return this.filterStepModel('sink'); }

  newWorkflow() {
    this.selectedWorkflow = this.workflowDataService.getWorkflow();
    let sampleStep = this.workflowDataService.getSampleStep();
    sampleStep.name = 'newStep';
    return this.selectedWorkflow;
  }


  selectWorkflow(name) {
    this.selectedWorkflow = this.workflowDataService.getWorkflow();
    let modeWDef: WorkflowDef[] = this.wflworkflowList.filter((w: WorkflowDef, i: number, a: WorkflowDef[]) => {return (w.name == name);})
    let mode = modeWDef ? modeWDef[0].mode : '';
    this.selectedWorkflow.process = name;
    this.selectedWorkflow.mode = mode;
  }

}