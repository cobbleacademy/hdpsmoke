import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { LayoutDirective, FlexDirective } from '@angular/flex-layout';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
//import { Http, Response } from "@angular/http";
import { HttpClient, HttpResponseBase, HttpResponse } from "@angular/common/http";

import { StepSelection } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
//import { Yaml, jsyaml } from 'js-yaml';  
import jsyaml = require('js-yaml');
 



@Component({
  selector: 'app-flowview',
  templateUrl: './flowview.component.html',
  styleUrls: [ './flowview.component.css' ]
})
export class FlowViewComponent implements OnInit {

  name = 'Angular';

  constructor(public workflowCacheService:  WorkflowCacheService, public stepSelectionService: StepSelectionService) {
    
  }

  ngOnInit() {
    //console.log('ALL NEW Data: ', this.data);
  }

  get data() {
    return this.workflowCacheService.customStringify();
  }

  get code() {
    return jsyaml.dump(JSON.parse(this.workflowCacheService.customStringify()));
  }

}