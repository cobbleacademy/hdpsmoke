export class StepSelection{
  id: number;
  name: string;

  constructor(
    id: number,
    name: string,
  ) {
    this.id = id;
    this.name = name;
  }
}

export class KeyVal{
  key: string;
  value: string;
  remove?: boolean;

  constructor(
    key: string,
    value: string,
    remove?: boolean
  ) {
    this.key = key;
    this.value = value;
    this.remove = remove;
  }
}

export class KeyValGroup{
  group: KeyVal[];
 
  constructor(
    group: KeyVal[]
  ) {
    this.group = group;
  }
}

export class Splitter{
  tempView: string;
  splits: KeyValGroup[];

  constructor(
    tempView: string,
    splits: KeyValGroup[]
  ) {
    this.tempView = tempView;
    this.splits = splits;
  }
}

// export class Splitter{
//   tempView: string;
//   splits: Map<String, String>[];

//   constructor(
//     tempView: string,
//     splits: Map<string, string>[]
//   ) {
//     this.tempView = tempView;
//     this.splits = splits;
//   }
// }
// export class Step {
//   name: string;
//   model: string;
//   from: string;
//   format: string;
//   command: string;
//   label: string;
//   tabs: KeyVal[];
//   options: Map<string, string>;
//   attributes: Map<string, string>;
//   conversions: Map<string, string>[];
//   include: Map<string, string>;
//   post: Map<string, string>;
//   splitter: Splitter;

//   constructor(
//     name: string,
//     model: string,
//     from: string,
//     format: string,
//     command: string,
//     label: string,
//     tabs: KeyVal[],
//     options: Map<string, string>,
//     attributes: Map<string, string>,
//     conversions: Map<string, string>[],
//     include: Map<string, string>,
//     post: Map<string, string>,
//     splitter: Splitter) {
//     this.name = name;
//     this.model = model;
//     this.from = from;
//     this.format = format;
//     this.command = command;
//     this.label = label;
//     this.tabs = tabs;
//     this.options = options;
//     this.attributes = attributes;
//     this.conversions = conversions;
//     this.include = include;
//     this.post = post;
//     this.splitter = splitter;
//   }
// }


export class Step {
  fields: KeyVal[];
  options: KeyVal[];
  attributes: KeyVal[];
  conversions: KeyValGroup[];
  include: KeyVal[];
  post: KeyVal[];
  splitter: Splitter;

  constructor(
    fields: KeyVal[],
    options: KeyVal[],
    attributes: KeyVal[],
    conversions: KeyValGroup[],
    include: KeyVal[],
    post: KeyVal[],
    splitter: Splitter) {
    this.fields = fields;
    this.options = options;
    this.attributes = attributes;
    this.conversions = conversions;
    this.include = include;
    this.post = post;
    this.splitter = splitter;
  }
}


export class Workflow {
  fields: KeyVal[];
  attributes: KeyVal[];
  steps: Step[];

  constructor(
    fields: KeyVal[],
    attributes: KeyVal[],
    steps: Step[]
  ) {
    this.fields = fields;
    this.attributes = attributes;    
    this.steps = steps;
  }
}




// export class Workflow{
//   process: string;
//   mode: string; 
//   qualityConfig: string;
//   qualityStatus: string;
//   triggerProc: string;
//   triggerScript: string;
//   triggerScriptPath: string;
//   steps: Step[];
//   attributes: Map<string, string>;

//   constructor(
//     process: string,
//     mode: string, 
//     qualityConfig: string,
//     qualityStatus: string,
//     triggerProc: string,
//     triggerScript: string,
//     triggerScriptPath: string,
//     steps: Step[],
//     attributes: Map<string, string>
//   ) {
//     this.process = process;
//     this.mode = mode;
//     this.qualityConfig = qualityConfig;
//     this.qualityStatus = qualityStatus;
//     this.triggerProc = triggerProc;
//     this.triggerScript = triggerScript;
//     this.triggerScriptPath = triggerScriptPath;
//     this.steps = steps;
//     this.attributes = attributes;    
//   }
// }

export class JsonWorkflow {
  process: string;
  mode: string; 
  qualityConfig: string;
  qualityStatus: string;
  triggerProc: string;
  triggerScript: string;
  triggerScriptPath: string;
  attributes: Map<string, string>;

  constructor(
    process: string,
    mode: string, 
    qualityConfig: string,
    qualityStatus: string,
    triggerProc: string,
    triggerScript: string,
    triggerScriptPath: string,
    attributes: Map<string, string>
  ) {
    this.process = process;
    this.mode = mode;
    this.qualityConfig = qualityConfig;
    this.qualityStatus = qualityStatus;
    this.triggerProc = triggerProc;
    this.triggerScript = triggerScript;
    this.triggerScriptPath = triggerScriptPath;
    this.attributes = attributes;    
  }
}

export class Basic{
  fields: KeyVal[];
  attributes: KeyVal[];
  steps: Step[];

  constructor(
    fields: KeyVal[],
    attributes: KeyVal[],
    steps: Step[]
  ) {
    this.fields = fields;
    this.attributes = attributes;    
    this.steps = steps;
  }
}