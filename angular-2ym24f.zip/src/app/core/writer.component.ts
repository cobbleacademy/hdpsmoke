import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { BaseStepComponent } from './basestep.component';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, KeyValGroup, Step, Splitter, Workflow } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-writer',
  templateUrl: './writer.component.html',
  styleUrls: ['./writer.component.css']
})
export class WriterComponent extends BaseStepComponent implements OnInit {

  stageInd = 4;
  stageName = 'writer';

  stepVals = ['basic', 'opts', 'attrs']

  seedData1 = [
    { key: 'name', value: 'sinkKafka', delete: false },
    { key: 'model', value: 'sink', delete: false },
    { key: 'format', value: 'kafka', delete: false },
    { key: 'from', value: 'transStream', delete: false }
  ];

  seedData = [
    new KeyVal('name', 'sinkKafka', false),
    new KeyVal('model', 'sink', false),
    new KeyVal('format', 'kafka', false),
    new KeyVal('from', 'transStream', false),
  ];

  constructor(public formBuilder: FormBuilder, public workflowDataService: WorkflowDataService, public workflowCacheService: WorkflowCacheService, public stepSelectionService: StepSelectionService, public route: ActivatedRoute, public router: Router) { 
    super(formBuilder, workflowDataService, workflowCacheService, stepSelectionService, route, router); 
  }

  ngOnInit() {
    super.baseStepInit();
  }

  selectedLayout = 1;

}
