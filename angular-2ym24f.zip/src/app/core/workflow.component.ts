import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, KeyValGroup, Splitter, Step, Basic, Workflow } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { ActivatedRoute, Router } from '@angular/router';



@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.css']
})
export class WorkflowComponent implements OnInit {

  name = 'Angular';

  workflowName = '';
  sub = {};

  selectedWorkflow: Workflow;
  stepSources: Step[];
  selectedDatasource = {}
  selectedColumns = ['name', 'model', 'from', 'label', 'operations'];

  stepInd: number = 1;
  stepVals = ['basic', 'attrs', 'steps']
  selectedInd: number = 0;

  dynamicForm: FormGroup;
  attrsForm: FormGroup;
  stepsForm: FormGroup;

  isLinear = false;
  workflow: Workflow;

  constructor(private fb: FormBuilder, public workflowDataService: WorkflowDataService, stepSelectionService: StepSelectionService, private workflowCacheService: WorkflowCacheService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {

    //
    let wname;
    let wmode;
    this.sub = this.route.params.subscribe(params => {
      wname = params['name']; // param 'name'
      wmode = params['mode']; // param 'mode'
    });

    //
    this.dynamicForm = this.fb.group({
      fields: this.fb.array([])
    });
    this.attrsForm = this.fb.group({
      fields: this.fb.array([])
    });
    this.stepsForm = this.fb.group({
      fields: this.fb.array([])
    });

    // create or get existing workflow
    if (wname && wname.length > 0) {
      this.workflowCacheService.selectWorkflow(wname);
    }
    //
    this.selectedWorkflow = this.workflowCacheService.createOrGetWorkflow();
    console.log('workflow display started as: ', this.selectedInd);
    this.toFormGroup(<FormArray>this.dynamicForm.get('fields'), this.selectedWorkflow.fields);
    this.toFormGroup(<FormArray>this.attrsForm.get('fields'), this.selectedWorkflow.attributes);
    let tobeselectedSteps = this.workflowCacheService.stepSources();


    let nIdx = tobeselectedSteps[0].fields.findIndex(i => i.key === "name");
    let stepName = (<KeyVal>(tobeselectedSteps[0].fields[nIdx])).value;
    console.log("default step to: " + stepName);

    this.workflowCacheService.selectStep(stepName);
    //this.selectedWorkflow.steps
    this.selectedDatasource = new MatTableDataSource<Step>(this.workflowCacheService.getStepListDefs());
    console.log("steps size: ", this.selectedWorkflow.steps.length);

    console.log("workflow init: ", this.selectedWorkflow.fields['process']);

    console.log(`Array Size: `, this.fieldsFormArray.length);

  }

  get fieldsFormArray() {
    if (this.selectedInd == 0) {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (this.selectedInd == 1) {
      return (<FormArray>this.attrsForm.get('fields'));
    } else if (this.selectedInd == 2) {
      return (<FormArray>this.stepsForm.get('fields'));
    }
  }


  toFormGroup(formArray: FormArray, kvArr: KeyVal[]) {
    kvArr.forEach(kv => {
      // const formGroup = this.createFieldGroup();
      // formGroup.addControl('key', this.getFormControl());
      // formGroup.addControl('value', this.getFormControl());
      // formGroup.patchValue({key:kv.key,value:kv.value});
      // (<FormArray>this.selectedStepForm.get('fields')).push(formGroup);
      formArray.push(this.fb.group({key: kv.key, value: kv.value}));
    });
  }


  addFieldToFieldsFormArray() {
    let fgArray: FormArray = this.fieldsFormArray;
    let kv = new KeyVal("","", true);
    if (this.selectedInd == 0) {
      this.selectedWorkflow.fields.push(kv);
      console.log("fields size: " + this.selectedWorkflow.fields.length);
    } else if (this.selectedInd == 1) {
      this.selectedWorkflow.attributes.push(kv);
    }
    fgArray.push(this.fb.group({key: kv.key, value: kv.value, remove: kv.remove}));
    console.log("add new with kv group: " + fgArray.length);
  }

  removeFieldFromFieldsFormArray(index) {
    let fgArray: FormArray = this.fieldsFormArray;
    fgArray.removeAt(index);
    if (this.selectedInd == 0) {
      this.selectedWorkflow.fields.splice(index);
      console.log("fields size: " + this.selectedWorkflow.fields.length);
    }
    else if (this.selectedInd == 1) {
      this.selectedWorkflow.attributes.splice(index);
    }
    console.log("remove kv group: " + fgArray.length);
  }

  editStep(name, model) {
    let toberouter = '';
    if (model == 'source') {
      toberouter = "/reader";
    } else if (model == 'transformation') {
      toberouter = "/editor";
    } else if (model == 'sink') {
      toberouter = "/writer";
    }
    this.router.navigate([toberouter, {name: name, model: model}]);
  }

  editStep1(name, model) {
    let tobeselectedSteps = [];
    let toberouter = '';
    if (model == 'source') {
      tobeselectedSteps = this.workflowCacheService.stepSources();
      toberouter = "/reader";
    } else if (model == 'transformation') {
      tobeselectedSteps = this.workflowCacheService.stepTransformations();
      toberouter = "/editor";
    } else if (model == 'sink') {
      tobeselectedSteps = this.workflowCacheService.stepSinks();
      toberouter = "/writer";
    }

    let nIdx = tobeselectedSteps[0].fields.findIndex(i => i.key === "name");
    let stepName = (<KeyVal>(tobeselectedSteps[0].fields[nIdx])).value;
    console.log("default step to: " + stepName);

    this.workflowCacheService.selectStep(stepName);

    this.router.navigate([toberouter]);
  }

  selectedLayout = 1;


  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  getFormControl() {
    return this.fb.control(null);
  }

  createFieldGroup() {
    return this.fb.group({});
  }

  save() {
    //console.log(this.dynamicForm.value);
    console.log("Saving Workflow Definition: ");
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < this.stepVals.length) {
      this.stepInd = this.selectedInd + 1
    }
  }

}
