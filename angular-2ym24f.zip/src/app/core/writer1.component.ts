import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';


@Component({
  selector: 'app-writer',
  templateUrl: './writer.component.html',
  styleUrls: [ './writer.component.css' ]
})
export class WriterComponent implements OnInit {

  name = 'Angular';

  stepInd: number = 1;
  selectedInd: number = -1;

  dynamicForm: FormGroup;
  optionsForm: FormGroup;
  attrsForm: FormGroup;
  postForm: FormGroup;

  seedData = [
    { key: 'name', value: 'sinkKafka', delete: false },
    { key: 'model' , value: 'sink', delete: false },
    { key: 'format' , value: 'kafka', delete: false },
    { key: 'from' , value: 'transStream', delete: false }
  ];

  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.dynamicForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.seedFieldsFormArray();

    this.optionsForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.attrsForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.postForm = this.fb.group({
      fields: this.fb.array([])
    });

    console.log(`Array Size: `, this.fieldsFormArray.length);

    this.firstFormGroup = this.fb.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this.fb.group({
      secondCtrl: ['', Validators.required]
    });
  }

  selectedLayout = 1;

  seedFieldsFormArray() {
    this.seedData.forEach(seedDatum => {
      const formGroup = this.createFieldGroup();
      formGroup.addControl('key', this.getFormControl());
      formGroup.addControl('value', this.getFormControl());
      formGroup.patchValue(seedDatum);
      this.fieldsFormArray.push(formGroup);
    });
  }

  addFieldToFieldsFormArray() {
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    this.fieldsFormArray.push(formGroup);
  }

  removeFieldFromFieldsFormArray(index) {
    this.fieldsFormArray.removeAt(index);
  }

  get fieldsFormArray() {
    if (this.stepInd == 1) {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (this.stepInd == 2) {
      return (<FormArray>this.optionsForm.get('fields'));
    } else if (this.stepInd == 3) {
      return (<FormArray>this.attrsForm.get('fields'));
    } else if (this.stepInd == 4) {
      return (<FormArray>this.postForm.get('fields'));
    }
  }

  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  getFormControl() {
    return this.fb.control(null);
  }

  createFieldGroup() {
    return this.fb.group({});
  }

  save() {
    console.log(this.dynamicForm.value);
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < 3) {
      this.stepInd = this.selectedInd + 1
    }
  }

}
