import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { BaseStepComponent } from '../core/basestep.component';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, KeyValGroup, Step, Splitter, Workflow } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-reader',
  templateUrl: './reader.component.html',
  styleUrls: [ './reader.component.css' ]
})
export class ReaderComponent extends BaseStepComponent implements OnInit {

  stageInd = 2;
  stageName = 'reader';

  stepVals = ['basic', 'opts', 'attrs', 'post']

  seedData = [
    new KeyVal('name', 'readKafka', false),
    new KeyVal('model', 'source', false),
    new KeyVal('format', 'kafka', false),
    new KeyVal('label', 'kafkaStream', false),
  ];

  constructor(public formBuilder: FormBuilder, public workflowDataService: WorkflowDataService, public workflowCacheService: WorkflowCacheService, public stepSelectionService: StepSelectionService, public route: ActivatedRoute, public router: Router) { super(formBuilder,  workflowDataService, workflowCacheService, stepSelectionService, route, router); }

  ngOnInit() {
    super.baseStepInit();
  }

  selectedLayout = 1;


}
