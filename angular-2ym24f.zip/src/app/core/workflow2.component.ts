import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import {MatTableDataSource, MatPaginator, MatSort,MatSnackBar} from '@angular/material';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import {Workflow, Step, Splitter} from './core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import {WorkflowDataService} from '../core/data/workflowdata.service';
import {WorkflowCacheService} from '../core/data/workflowcache.service';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: [ './workflow.component.css' ]
})
export class Workflow2Component implements OnInit {

  name = 'Angular';

  workflowName = '';
  sub = {};

  selectedWorkflow: Workflow;
  stepSources: Step[];
  selectedDatasource = {}
  selectedColumns = [ 'name', 'model', 'from', 'label', 'operations' ];

  stepInd: number = 1;
  selectedInd: number = -1;

  dynamicForm: FormGroup;
  attrsForm: FormGroup;

  seedData = [
    { key: 'process', value: 'FileFlow', delete: false },
    { key: 'mode' , value: 'batch', delete: false },
    { key: 'qualityConfig' , value: 'invalid_col_config', delete: false },
    { key: 'qualityStatus' , value: 'invalid_col_stats', delete: false },
    { key: 'triggerScript' , value: 'trigger_run.sh', delete: false },
    { key: 'triggerScriptPath' , value: './scripts', delete: false }
  ];

  isLinear = false;
  workflow: Workflow = {};

  constructor(private fb: FormBuilder, public workflowDataService: WorkflowDataService, stepSelectionService: StepSelectionService, private workflowCacheService: WorkflowCacheService, private route: ActivatedRoute) {}

  ngOnInit() {

    //
    this.sub = this.route.params.subscribe(params => {
      let wname = params['name']; // param 'name'
      let wmode = params['mode']; // param 'mode'
      if (wname && wname.length > 0)
        this.seedData[0] = { key: 'process', value: wname, delete: false };
      if (wmode && wmode.length > 0)
        this.seedData[1] = { key: 'mode' , value: wmode, delete: false };
    });

    //
    this.dynamicForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.workflow = this.workflowDataService.getWorkflow();

    this.seedFieldsFormArray();

    this.attrsForm = this.fb.group({
      fields: this.fb.array([])
    });

    this.selectedWorkflow = this.workflowCacheService.newWorkflow();
    this.stepSources = this.workflowCacheService.stepSources();
    this.workflowCacheService.selectStep(this.stepSources[0].name);
    this.selectedDatasource = new MatTableDataSource<Step>(this.selectedWorkflow.steps);
    console.log("steps size: ", this.stepSources.length);

    console.log("workflow init: ", this.workflow.process);

    console.log(`Array Size: `, this.fieldsFormArray.length);

  }

  
  selectedLayout = 1;

  seedFieldsFormArray() {
    this.seedData.forEach(seedDatum => {
      const formGroup = this.createFieldGroup();
      formGroup.addControl('key', this.getFormControl());
      formGroup.addControl('value', this.getFormControl());
      formGroup.patchValue(seedDatum);
      this.fieldsFormArray.push(formGroup);
    });
    this.updateModel()
  }

  updateModel() {
    let i = 0
    let fldMap = new Map()
    let farr = (<FormArray>this.dynamicForm.get('fields'))
    for(i = 0;i < farr.length;i++) {
      let fg = (<FormGroup>farr.at(i))
      let fcKey = (<FormControl>fg.get('key'))
      let fcVal = (<FormControl>fg.get('value'))
      fldMap.set(fcKey.value, fcVal.value)
    }
    this.workflow.process = fldMap.get('process');
    this.workflow.mode = fldMap.get('process');
    this.workflow.qualityConfig = fldMap.get('qualityConfig');
    this.workflow.qualityStatus = fldMap.get('qualityStatus');
    this.workflow.triggerProc = fldMap.get('triggerProc');
    this.workflow.triggerScript = fldMap.get('triggerScript');
    this.workflow.triggerScriptPath = fldMap.get('triggerScriptPath');

  }

  addFieldToFieldsFormArray() {
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    this.fieldsFormArray.push(formGroup);
    console.log("Workflow Details: " + this.workflow.process)
  }

  removeFieldFromFieldsFormArray(index) {
    this.fieldsFormArray.removeAt(index);
  }

  get fieldsFormArray() {
    if (this.stepInd == 1) {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (this.stepInd == 2) {
      return (<FormArray>this.attrsForm.get('fields'));
    }
  }

  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  getFormControl() {
    return this.fb.control(null);
  }

  createFieldGroup() {
    return this.fb.group({});
  }

  save() {
    //console.log(this.dynamicForm.value);
    this.updateModel()
    console.log("Saving Workflow Definition: " + this.workflow.process);
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < 2) {
      this.stepInd = this.selectedInd + 1
    }
  }

}
