import { Component, ViewChild, ViewChildren, QueryList, ViewContainerRef, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { KeyVal, KeyValGroup, Workflow, Step, Splitter } from '../core/model/models';
import { StepSelectionService } from '../core/data/stepselection.service';
import { WorkflowCacheService } from '../core/data/workflowcache.service';
import { WorkflowDataService } from '../core/data/workflowdata.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  template: ''
})
export class BaseStepComponent {

  name = 'Angular';
  jsonify = ""

  sub = {};

  stageInd: number = 1;
  stageName: string = 'workflow';

  stepInd: number = 1;
  stepVals = ['basic', 'opts', 'attrs', 'convs', 'incl', 'post', 'split']
  selectedInd: number = -1;
  stepTempViewLabel = 'tempView';

  dynamicForm: FormGroup;
  optionsForm: FormGroup;
  attrsForm: FormGroup;
  convsForm: FormGroup;
  inclForm: FormGroup;
  postForm: FormGroup;
  splitterForm: FormGroup;

  step: Step;

  selectedStepForm: FormGroup;
  //selectedStep: Step;
  selectedStepReader: Step;
  selectedStepEditor: Step;
  selectedStepWriter: Step;

  seedData = [];
  
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;


  constructor(public formBuilder: FormBuilder, public workflowDataService: WorkflowDataService, public workflowCacheService:  WorkflowCacheService, public stepSelectionService: StepSelectionService, public route: ActivatedRoute, public router: Router) {}

  baseStepInit() {

    //
    this.routedStep();

    //
    this.stepSelectionService.setSelection(this.stageInd, this.stageName);

    //
    this.dynamicForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    //this.step = this.workflowDataService.getSampleStep()
    //this.seedFieldsFormArray();

    this.optionsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.attrsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.convsForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.inclForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.postForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    this.splitterForm = this.formBuilder.group({
      fields: this.formBuilder.array([])
    });

    console.log(`Array Size: `, this.fieldsFormArray.length);

    this.loadSelectedStep();
    console.log('Returned selectedstep from Cache for : '+ this.stageName);
    console.log(this.selectedStep.fields[0].value);
    // this.selectedStepForm = this.formBuilder.group({
    //   fields: this.formBuilder.array([])
    // });
    //this.selectedStep.fields = this.seedData;
    this.toFormGroup(<FormArray>this.dynamicForm.get('fields'), this.selectedStep.fields);
    this.toFormGroup(<FormArray>this.optionsForm.get('fields'), this.selectedStep.options);
    this.toFormGroup(<FormArray>this.attrsForm.get('fields'), this.selectedStep.attributes);
    this.toFormGroup(<FormArray>this.convsForm.get('fields'), this.selectedStep.conversions);
    this.toFormGroup(<FormArray>this.inclForm.get('fields'), this.selectedStep.include);
    this.toFormGroup(<FormArray>this.postForm.get('fields'), this.selectedStep.post);
    this.toFormGroupChildGroup(<FormArray>this.splitterForm.get('fields'), this.selectedStep.splitter);

    //
    //
    this.firstFormGroup = this.formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this.formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }


  routedStep() {
    //
    let name;
    let model;
    this.sub = this.route.params.subscribe(params => {
      name = params['name']; // param 'name'
      model = params['model']; // param 'mode'
    });

    if (!name || !model) {
      console.log('creating new step of type: ' + this.stageName);
      this.workflowCacheService.createStep(this.stageName);
    } else {
      console.log('selecting step: ' + name);
      this.workflowCacheService.selectStep(name);
    }

  }


  loadSelectedStep() {
    let tempSelStep = this.workflowCacheService.getSelectedStep(this.stageName);
    if (this.stageName == 'reader')
      this.selectedStepReader = tempSelStep;
    else if (this.stageName == 'editor')
      this.selectedStepEditor = tempSelStep;
    else if (this.stageName == 'writer')
      this.selectedStepWriter = tempSelStep;
  }

  get selectedStep() {
    if (this.stageName == 'reader') {
      return this.selectedStepReader;
    } else if (this.stageName == 'editor') {
      return this.selectedStepEditor;
    } else if (this.stageName == 'writer') {
      return this.selectedStepWriter;
    }
  }


  clearFormGroup(formArray: FormArray) {
    let len:number = formArray.length;
    let i = 0;

    for(i = len;i>=1;i--) {
      formArray.removeAt(i);
    }
  }

  toFormGroup(formArray: FormArray, kvArr: KeyVal[]) {
    kvArr.forEach(kv => {
      // const formGroup = this.createFieldGroup();
      // formGroup.addControl('key', this.getFormControl());
      // formGroup.addControl('value', this.getFormControl());
      // formGroup.patchValue({key:kv.key,value:kv.value});
      // (<FormArray>this.selectedStepForm.get('fields')).push(formGroup);
      formArray.push(this.formBuilder.group({key: kv.key, value: kv.value}));
    });
  }

  toFormGroupChildGroup(formArray: FormArray, splitter: Splitter) {
    //formArray.push(this.formBuilder.group({key: 'tempView', value: ''}));
    if (splitter.splits) {
      // if (splitter.tempView) {
      //   let childArray = this.formBuilder.array([]);
      //   childArray.push(this.formBuilder.group({key: 'tempView', value: splitter.tempView}));
      // }
      splitter.splits.forEach(kvg => {
        let childArray = this.formBuilder.array([]);
        kvg.group.forEach(kv => {
          childArray.push(this.formBuilder.group({key: kv.key, value: kv.value, remove: kv.remove}));
        });
        formArray.push(this.formBuilder.group({fields: childArray}));
      });
    }
  }


  updateKeyValModel(kvMap: Map<string, string>, formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let fg = (<FormGroup>formArray.at(i));
      let fcKey = (<FormControl>fg.get('key'));
      let fcVal = (<FormControl>fg.get('value'));
      //console.log(fcKey.value + " ** " + fcKey.value.length + ' ** ' + fcVal.value.length);
      if (fcKey.value.length > 0 && fcVal.value.length > 0) {
        kvMap.set(fcKey.value, fcVal.value);
      }
      
    }
  }

  updateKeyValSetModel(kvMapArr: Map<string, string>[], formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let kvMap: Map<string, string>;
      let fgFArr = (<FormArray>(<FormGroup>formArray.at(i)).get('fields'+i));
      let j = 0;
      for(j = 0;j < fgFArr.length;j++) {
        let fg = (<FormGroup>fgFArr.at(j));
        let fcKey = (<FormControl>fg.get('key'));
        let fcVal = (<FormControl>fg.get('value'));
        if (fcKey.value.length > 0 && fcVal.value.length > 0) {
          console.log('fieldset map: ', fcKey.value, fcVal.value)
          kvMap.set(fcKey.value, fcVal.value);
        }
      }
      kvMapArr.push(kvMap)     
    }
  }

  updateKeyValHdrSetModel(hdrView: string, kvMapArr: Map<string, string>[], formArray: FormArray) {
    let i = 0;
    for(i = 0;i < formArray.length;i++) {
      let fgFArr = (<FormArray>(<FormGroup>formArray.at(i)).get('fields'+i));
      let kvMap: Map<string, string>;
      let j = 0;
      for(j = 0;j < fgFArr.length;j++) {
        let fg = (<FormGroup>fgFArr.at(j));
        let fcKey = (<FormControl>fg.get('key'));
        let fcVal = (<FormControl>fg.get('value'));
        if (fcKey.value.length > 0 && fcVal.value.length > 0) {
          console.log('fieldhdrset map: ', fcKey.value, fcVal.value)
          if (i == 0)
            hdrView = fcVal.value;
          else 
            kvMap.set(fcKey.value, fcVal.value);
        }
      }
      kvMapArr.push(kvMap)     
    }
  }

  updateModel() {
    let fldMap = new Map();
    this.updateKeyValModel(fldMap, (<FormArray>this.dynamicForm.get('fields')));
    this.step.name = fldMap.get('name');
    this.step.model = fldMap.get('model');
    this.step.from = fldMap.get('from');
    this.step.format = fldMap.get('format');
    this.step.command = fldMap.get('command');
    this.step.label = fldMap.get('label');
    //this.step.conversions = fldMap.get('conversions');
    //
    this.updateKeyValModel(this.step.options, (<FormArray>this.optionsForm.get('fields')));
    if (!(this.step.options.size > 0)) this.step.options = undefined;
    //
    this.updateKeyValModel(this.step.attributes, (<FormArray>this.attrsForm.get('fields')));
    if (!(this.step.attributes.size > 0)) this.step.attributes = undefined;
    //
    this.updateKeyValSetModel(this.step.conversions, (<FormArray>this.convsForm.get('fields')));
    if (!(this.step.conversions.length > 0)) this.step.conversions = undefined;
    //
    this.updateKeyValModel(this.step.include, (<FormArray>this.inclForm.get('fields')));
    if (!(this.step.include.size > 0)) this.step.include = undefined;
    //
    this.updateKeyValModel(this.step.post, (<FormArray>this.postForm.get('fields')));
    if (!(this.step.post.size > 0)) this.step.post = undefined;
    //
    this.updateKeyValHdrSetModel(this.step.splitter.tempView, this.step.splitter.splits, (<FormArray>this.splitterForm.get('fields')));
    if (!this.step.splitter || !this.step.splitter.tempView) this.step.splitter = undefined;
    if (this.step.splitter && !(this.step.splitter.tempView.length > 0)) this.step.splitter = undefined;
    if (this.step.splitter && !(this.step.splitter.splits.length > 0)) this.step.splitter = undefined;
  }

  removeFieldFromFieldsFormArray(index) {
    let fgArray: FormArray = this.fieldsFormArray;
    fgArray.removeAt(index);
    this.formFields().splice(index);
    console.log("remove kv group: " + fgArray.length);
  }

  addFieldToFieldsFormArray() {
    let fgArray: FormArray = this.fieldsFormArray;
    let kv = new KeyVal("","", true);
    this.formFields().push(kv);
    fgArray.push(this.formBuilder.group({key: kv.key, value: kv.value, remove: kv.remove}));
    console.log("add new with kv group: " + fgArray.length);
  }


  //
  //
  removeFieldFromFieldSetFormArray(setIndex, index) {
    (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields')).removeAt(index);
    this.formFieldsGroup()[setIndex].group.splice(index);
    //let kvg: KeyValGroup = this.formFieldsGroup()[setIndex];
    //kvg.group.splice(index);
  }

  addFieldToFieldSetArray(setIndex) {
    console.log("Adding Field At: " + setIndex);
    let fieldSetFormArray = (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields'));
    console.log("with existing size: " + this.formFieldsGroup().length);
    let kv = new KeyVal("","", true);
    let kvg: KeyValGroup = this.formFieldsGroup()[setIndex];
    kvg.group.push(kv);
    fieldSetFormArray.push(this.formBuilder.group({key: kv.key, value: kv.value, remove: kv.remove}));
  }



  removeFieldSetFromFieldsFormArray(setIndex) {
    console.log('removing set at: ' + setIndex + ' of total: ' + this.fieldsFormArray.length);
    let localFormName =  this.stepVals[this.stepInd - 1]
    if (this.fieldsFormArray.length-1 == setIndex) {
      this.fieldsFormArray.removeAt(setIndex);
      if (localFormName == 'split' && setIndex == -1) {
        this.selectedStep.splitter = undefined;
      } else {
        this.formFieldsGroup().splice(setIndex);
      }
    }
  }

  addFieldHdrSetToFieldsFormArray() {
    let formArray: FormArray = this.fieldsFormArray;
    console.log('adding hdr set of total: ' + formArray.length);
    let childArray = this.formBuilder.array([]);
    if (formArray.length == -1) {
      let kv = new KeyVal('tempView','');
      let grp: KeyVal[] = [];
      grp.push(kv);
      let kvg = new KeyValGroup(grp);
      this.selectedStep.splitter.tempView = '';
      childArray.push(this.formBuilder.group({key: kv.key, value: kv.value}));
    } else {    
      let kv = new KeyVal("","", true);
      let grp: KeyVal[] = [];
      grp.push(kv);
      let kvg = new KeyValGroup(grp);
      this.formFieldsGroup().push(kvg);
      childArray.push(this.formBuilder.group({key: kv.key, value: kv.value, remove: kv.remove}));
    }
    formArray.push(this.formBuilder.group({fields: childArray}));
  }



  addFieldSetToFieldsFormArray() {
    let formArray: FormArray = this.fieldsFormArray;
    let childArray = this.formBuilder.array([]);
    let kv = new KeyVal('seq',''+(formArray.length+1));
    let grp: KeyVal[] = [];
    grp.push(kv);
    let kvg = new KeyValGroup(grp);
    this.formFieldsGroup().push(kvg);
    childArray.push(this.formBuilder.group({key: kv.key, value: kv.value}));
    formArray.push(this.formBuilder.group({fields: childArray}));
  }
  //
  //
  addFieldSetToFieldsFormArray1() {
    const formArray = this.createFormArray()
    let atNumber: number = this.fieldsFormArray.length + 1
    const childformGroup = this.buildFormGroup()
    childformGroup.patchValue({ key: 'seq', value: ''+atNumber });
    childformGroup.removeControl('delete')
    formArray.push(childformGroup);
    //
    const formGroup = this.createFieldGroup();
    formGroup.addControl('fields'+this.fieldsFormArray.length, formArray);
    this.fieldsFormArray.push(formGroup);
  }


  addFieldHdrSetToFieldsFormArray1() {
    const formArray = this.createFormArray()
    let atNumber: number = this.fieldsFormArray.length + 1
    const childformGroup = this.buildFormGroup()
    if (this.fieldsFormArray.length == 0) {
      childformGroup.patchValue({ key: 'tempView', value: '' });
      childformGroup.removeControl('delete')
    }
    formArray.push(childformGroup);
    //
    const formGroup = this.createFieldGroup();
    formGroup.addControl('fields'+this.fieldsFormArray.length, formArray);
    this.fieldsFormArray.push(formGroup);
  }

  removeFieldSetFromFieldsFormArray1(setIndex) {
    if (this.fieldsFormArray.length-1 == setIndex)
      this.fieldsFormArray.removeAt(setIndex);
  }

  addFieldToFieldSetArray1(setIndex) {
    //console.log("Adding Field At: " + setIndex);
    let fieldSetFormArray = (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields'+setIndex));
    const formGroup = this.createFieldGroup();
    formGroup.addControl('key', this.getFormControl());
    formGroup.addControl('value', this.getFormControl());
    formGroup.addControl('delete', this.getFormControl());
    formGroup.patchValue({ delete: true });
    fieldSetFormArray.push(formGroup);
  }

  removeFieldFromFieldSetFormArray1(setIndex, index) {
    (<FormArray>(<FormGroup>this.fieldsFormArray.at(setIndex)).get('fields'+setIndex)).removeAt(index);
  }
  //
  //

  formFields() {
    let localFormName =  this.stepVals[this.stepInd - 1]
    if (localFormName == 'basic') {
      return this.selectedStep.fields;
    } else if (localFormName == 'opts') {
      return this.selectedStep.options;
    } else if (localFormName == 'attrs') {
      return this.selectedStep.attributes;
    } else if (localFormName == 'convs') {
      return [];
    } else if (localFormName == 'incl') {
      return this.selectedStep.include;
    } else if (localFormName == 'post') {
      return this.selectedStep.post;
    } else if (localFormName == 'split') {
      return [];
    }
  }

  formFieldsGroup() {
    let localFormName =  this.stepVals[this.stepInd - 1]
    if (localFormName == 'convs') {
      return this.selectedStep.conversions;
    } else if (localFormName == 'split') {
      if (!this.selectedStep.splitter.splits) {
        this.selectedStep.splitter = new Splitter("",[]);
      }
      return this.selectedStep.splitter.splits;
    }
  }

  get fieldsFormArray() {
    let localFormName =  this.stepVals[this.stepInd - 1]
    if (localFormName == 'basic') {
      return (<FormArray>this.dynamicForm.get('fields'));
    } else if (localFormName == 'opts') {
      return (<FormArray>this.optionsForm.get('fields'));
    } else if (localFormName == 'attrs') {
      return (<FormArray>this.attrsForm.get('fields'));
    } else if (localFormName == 'convs') {
      return (<FormArray>this.convsForm.get('fields'));
    } else if (localFormName == 'incl') {
      return (<FormArray>this.inclForm.get('fields'));
    } else if (localFormName == 'post') {
      return (<FormArray>this.postForm.get('fields'));
    } else if (localFormName == 'split') {
      return (<FormArray>this.splitterForm.get('fields'));
    }
  }

  boolVal(boolStr) {
    return (String(boolStr) == 'true');
  }

  getFieldGroupAtIndex(index) {
    return (<FormGroup>this.fieldsFormArray.at(index));
  }

  buildFormGroup() {
    const childformGroup = this.createFieldGroup();
    childformGroup.addControl('key', this.getFormControl());
    childformGroup.addControl('value', this.getFormControl());
    childformGroup.addControl('delete', this.getFormControl());
    return childformGroup;
  }

  getFormControl() {
    return this.formBuilder.control(null);
  }

  createFieldGroup() {
    return this.formBuilder.group({});
  }

  createFormArray() {
    return this.formBuilder.array([]);
  }

  save() {
    ///this.updateModel()
    //console.log("Saving Workflow Step: " + this.step.name);
    //this.workflowDataService.addStep(this.step)
    //this.jsonify = this.workflowDataService.stringify();
    this.jsonify = JSON.parse(this.workflowCacheService.customStringify());
  }

  doSelectedInd(evt: StepperSelectionEvent): void {
    console.log('doSelectedInd: ' + evt.selectedIndex + ' prev ind: ' + evt.previouslySelectedIndex);
    this.selectedInd = evt.selectedIndex
    if (this.selectedInd < this.stepVals.length) {
      this.stepInd = this.selectedInd + 1
    }
  }

}