import { Component, Input, OnInit, ViewChild} from '@angular/core';
import {MatTableDataSource, MatPaginator, MatSort,MatSnackBar} from '@angular/material';
import { WorkflowDef } from '../workflowdef';
import { Router } from '@angular/router';


@Component({
  selector: 'app-workflow-list',
  templateUrl: './workflow-list.component.html',
  styleUrls: [ './workflow-list.component.css' ]
})
export class WorkflowListComponent  {
  @Input() name: string;

  wflowdefs: WorkflowDef[] = [
    { name:'FileFlow', file:'./resources/workflow_hdfs.yml', mode: 'batch'},
    { name:'KafkaFlow', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow02', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow02', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow03', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow03', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow04', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow04', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow05', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow05', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow06', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow06', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow07', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow07', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow08', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow08', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow09', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow09', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow10', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow10', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow11', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow11', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow12', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow12', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow13', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow13', file:'./resources/workflow_kafka.yml', mode: 'stream'},
    { name:'FileFlow14', file:'./resources/workflow_hdfs.yml', mode: 'stream'},
    { name:'KafkaFlow14', file:'./resources/workflow_kafka.yml', mode: 'stream'},
  ];

  
  loading = true;

  dataSource = new MatTableDataSource<WorkflowDef>(this.wflowdefs);
  
  displayedColumns = [ 'name', 'file', 'mode', 'operations'];
  pageSize = 4;
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor (private router: Router) {}

  deleteWorkflow(name){
    
    let snackBarRef = this.snackBar.open(`Deleting Workflow #${name}`);
  }

  editWorkflow(name, mode){
    //let snackBarRef = this.snackBar.open(`Editing Workflow #${name}`);
    this.router.navigate(['/workflow', name, mode]);

  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnInit(): void {
    setTimeout(() => {
      
      this.loading = false;
      
    }, 100);

    /*this.dataService.getCustomers(this.startIndex,this.endIndex).subscribe((d: Customer[])=>{
      this.dataSource.data = d;
      this.loading = false;
    });*/
    

    
  }  
}