export interface Customer{
    id: number;
    name: string;
    job: string;
}