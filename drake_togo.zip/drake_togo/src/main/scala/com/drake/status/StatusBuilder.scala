package com.drake.status

import com.drake.model.Model.Step
import com.drake.{BaseTrait, SparkHelper}
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.apache.spark.sql.{DataFrame, SaveMode}

/**
  * A Builder class for Writer for output content
  */
object StatusBuilder {

  /**
    * Builds specific Status
    */
  class BaseStatus(handlername: String) extends StatusBuilder {

    name = handlername

    /**
      * Status DataFrame content to Sink
      * @param step
      * @return
      */
    override def statusSink(step: Step, status: DataFrame): Unit = {
      logger.debug("BaseStatus:statusSink")

      //
      val sparkSession = SparkHelper.getSparkSession()
      val stepAttrs = step.attributes.getOrElse(Map())

      //
      //status.show(false)

      //
      status
        .write
        .format("csv")
        .partitionBy("src_system")
        .mode(SaveMode.Append)
        .save(stepAttrs.getOrElse("statusPath", "false"))

    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): StatusBuilder = {
    new BaseStatus(s)
  }

  // an alternative factory method (use one or the other)
  def getStatusBuilder(s: String): StatusBuilder = {
    new BaseStatus(s)
  }

}

/**
  * A Builder interface for all the StatusSink Writer
  */
trait StatusBuilder extends BaseTrait {

  var name: String = _


  /**
    * Status DataFrame content to Sink
    * @param step
    * @return
    */
  def statusSink(step: Step, status: DataFrame): Unit

}

