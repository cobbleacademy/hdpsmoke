package com.drake.editor

import com.drake.SparkHelper
import com.drake.model.Model.{SplitDataFrame, Step}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable

/**
  * An Invalid Config Builder to capture data quality errors
  */
class RawInvalidConfigBuilder(handlername: String) extends EditorBuilder {

  name = handlername

  /**
    * Returns the transformed input DataFrame
    *
    * @param step
    * @return
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {

    val sess = SparkHelper.getSparkSession()

    val schema = StructType(
      Array(StructField("db_name", StringType),
        StructField("table_name", StringType),
        StructField("col_name", StringType),
        StructField("data_type", StringType),
        StructField("data_type_check", IntegerType),
        StructField("null_check", IntegerType),
        StructField("empty_check", IntegerType),
        StructField("dup_check", IntegerType),
        StructField("range_check", IntegerType),
        StructField("range_check_values", StringType),
        StructField("const_check", IntegerType),
        StructField("const_check_values", StringType)
      ))

    val sumColNames = Seq("db_name","table_name","col_name")

    val configDf = sess.read.format("csv").option("header", "true").schema(schema).load("input/valid_config/validcols.csv")

    val configArr = configDf.rdd.collect()

    //
    def rowDataTypeChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("data_type_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        val dataTypeName = chkCol.getAs[String]("data_type")
        try {
          //row.getAs(colName).getClass
          dataTypeName match {
            case "Int" => if (row.getAs(colName).toString.equals(row.getAs[Int](colName).toString.toInt)) row.getAs[Double](colName).getClass
            case "Long" => if (row.getAs(colName).toString.equals(row.getAs[Long](colName).toString.toLong)) row.getAs[Double](colName).getClass //if (!row.getAs(colName).isInstanceOf[Long]) row.getAs(colName).getClass //println("Verifying Long :" + row.getAs(colName).getClass+ " " + row.getAs(colName).isInstanceOf[Long] + " "+colName)
            case "String" => if (row.getAs(colName).toString.equals(row.getAs[String](colName).toString)) row.getAs[Double](colName).getClass
            case "Float" => if (row.getAs(colName).toString.equals(row.getAs[Float](colName).toString.toFloat)) row.getAs[Double](colName).getClass
            case "Double" => if (row.getAs(colName).toString.equals(row.getAs[Double](colName).toString.toDouble)) row.getAs[Double](colName).getClass
            case _ => ""
          }
        } catch {
          case x: Throwable => if (colList.length > 0) colList += "~" + colName else colList += colName
        }
      })
      colList
    })
    //
    def rowNullChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("null_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == null) {if (colList.length > 0) colList += "~" + colName else colList += colName}
      })
      colList
    })
    //
    def rowEmptyChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("empty_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == "") {if (colList.length > 0) colList += "~" + colName else colList += colName}
      })
      colList
    })



    //
    val totalRecCount = input.count
    var mutColChkMap = mutable.Map[String, mutable.Map[String, Long]]()
    val colDupChkStat = "dupChkStat"
    configArr.foreach( chkCol => {
      val colName = chkCol.getAs[String]("col_name")
      val cnt = input.groupBy(colName).count.filter("count = 1").count
      var innrMap = mutColChkMap.getOrElse(colDupChkStat, mutable.Map[String, Long]())
      innrMap += colName -> (totalRecCount - cnt)
      mutColChkMap += colDupChkStat -> innrMap
    })

    mutColChkMap.foreach(println)

    //
    val chkStatDF = input
      .withColumn("datatypechkstat", rowDataTypeChk(struct(input.columns.map(col): _*)))
      .withColumn("nullchkstat", rowNullChk(struct(input.columns.map(col): _*)))
      .withColumn("emptychkstat", rowEmptyChk(struct(input.columns.map(col): _*)))

    //
    val sumColMap = Map(
      "sumDatatypechkstat" -> "datatypechkstat",
      "sumNullchkstat" -> "nullchkstat",
      "sumEmptychkstat" -> "emptychkstat"
      )
    sumColMap.foreach(sumCol => {
      configArr.foreach( chkCol => {
        val colName = chkCol.getAs[String]("col_name").toString
        val cnt = chkStatDF.filter(col(sumCol._2).contains(colName)).count
        var innrMap = mutColChkMap.getOrElse(sumCol._1, mutable.Map[String, Long]())
        innrMap += colName -> cnt
        mutColChkMap += sumCol._1 -> innrMap
      })
    })

    mutColChkMap.foreach(println)

    //
    val sumChkStatRawDF = configDf.select(sumColNames.map(c => col(c)): _*)
    val sumChkStatInitDF = mutColChkMap.keys.foldLeft(sumChkStatRawDF)((sumChkStatRawDF, colNm) => sumChkStatRawDF.withColumn(colNm , lit("0") ) )
    //
    //
    def rowReplaceChkVal = udf((colNm: String, colGrp: String) => {
      val ret: Long = mutColChkMap.getOrElse(colGrp, mutable.Map[String, Long]()).getOrElse(colNm, 0)
      ret
    })

    val sumChkStatDF = mutColChkMap.keys.foldLeft(sumChkStatInitDF)((sumChkStatInitDF, colNm) => sumChkStatInitDF.withColumn(colNm, rowReplaceChkVal(col("col_name"), lit(colNm)) ) )

    sumChkStatDF.show(false)

    //
    def concatColChkPrefix = udf((pfx: String, colVal: String) => {
      if (!colVal.isEmpty) pfx + colVal else ""
    })


    val gen = chkStatDF
      .withColumn("stat", concat_ws(" ",concatColChkPrefix(lit("DataTypeCheck:"),col("datatypechkstat")), concatColChkPrefix(lit("NullCheck:"),col("nullchkstat")), concatColChkPrefix(lit("EmptyCheck:"),col("emptychkstat"))))

//    val gen = input.map(r => {
//
//      val nullChkCols = configArr.filter(p => p.getAs[Int]("null_chk") == 1)
//      var nullColList = "NullCheck:"
//
//      nullChkCols.map(nilCol => {
//        val colName = nilCol.getAs[String]("col_name")
//        if (r.getAs(colName) == null || r.getAs(colName) == "")   nullColList += colName
//      })
//
//      //Row(r.getAs[String]("db_name"),r.getAs[String]("table_name"),r.getAs[String]("col_name"))
//      r
//    })

    gen.show(false)

    //
    //input.where(input.col("columnname").isNull).count()

    //
    def rowHasNull = udf((row: Row) => row.anyNull)

    //
    val statusDf = input
      .withColumn("fwstatus", rowHasNull(struct(input.columns.map(col): _*)))

    val invalidDf = statusDf.filter(statusDf("fwstatus") === lit("true")).drop("fwstatus")

    //invalidDf

    //
    Seq(SplitDataFrame(step.label.getOrElse(""), invalidDf))
  }
}
