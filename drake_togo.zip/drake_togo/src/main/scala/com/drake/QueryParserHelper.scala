package com.drake

/**
  * A helper class to enrich query with special parameters to induce dynamic value just before sent for execution
  */
object QueryParserHelper {


  /**
    * Replace and return dynamic variables
    * @param sql
    * @return
    */
  def replaceSessionArgs(sql: String): String = {
    //
    var retSql = sql
    var parseVals = Map[String, String]()

    //
    // find dynamic variable in query and find corresponding values
    //
    if (sql.contains("$")) {
      //
      var startDolInd = -2
      var foundDol = true
      //
      while (foundDol) {
        val dolInd = sql.indexOf("$", startDolInd+1)
        //println("dolInd: " + dolInd)
        if (dolInd > 0) {
          val hashInd = sql.indexOf("#", dolInd+1)
          //println("hashInd: " + hashInd)
          if (hashInd > 0) {
            var breakInd = -1
            if (breakInd < 0) breakInd = sql.indexOf("'", hashInd+1)
            if (breakInd < 0) breakInd = sql.indexOf(",", hashInd+1)
            if (breakInd < 0) breakInd = sql.indexOf("", hashInd+1)
            if (breakInd < 0) breakInd = sql.indexOf(" ", hashInd+1)
            //println("breakInd: " + breakInd)
            if (breakInd > 0) {
              startDolInd = breakInd
              val k = sql.substring(dolInd, breakInd)
              //println("key: " + k)
              val v = SessionDataHelper.parentageLookup(k)
              //println("key: " + k + " -> value: " + v)
              parseVals += k -> v
              if (breakInd == sql.length-1) foundDol = false
            } else {
              foundDol = false
            }
          } else {
            foundDol = false
          }
        } else {
          foundDol = false
        }
        startDolInd = startDolInd+1
      }

    }

    //
    // now replace dynamic variable with values
    //
    parseVals.map(f => {
      println(f._1 + " -> " + f._2)
      retSql = retSql.replace(f._1, f._2)
      f
    })

    //
    retSql
  }

}
