package com.drake

import org.apache.spark.sql.types.StructType

import scala.reflect.runtime.universe.{Quasiquote, runtimeMirror}
import scala.tools.reflect.ToolBox


/**
  * An Evaluator for dynamic scala code in the form of string (or file)
  */
object CodeEvaluator {
  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): CodeEvaluator = {
    getCodeEvaluator(s)
  }

  // an alternative factory method (use one or the other)
  def getCodeEvaluator(s: String): CodeEvaluator = {
    new BaseCodeEvaluator(s)
  }

  /**
    * Builds specific Code Evaluator
    */
  class BaseCodeEvaluator(handlername: String) extends CodeEvaluator {

    name = handlername

    //
    val mirror = runtimeMirror(getClass.getClassLoader)
    val tbox = ToolBox(mirror).mkToolBox()

    //
    val functionWrapper = "object BaseCodeEvaluatorWrapper { " + name + "}"
    val functionSymbol = tbox.define(tbox.parse(functionWrapper).asInstanceOf[tbox.u.ImplDef])

    /**
      * Schecma from given code
      *
      * @param step
      * @return
      */
    override def evaluateSchema(code: String): StructType = {
      //
      logger.debug("BaseCodeEvaluator:evaluateSchema")

      //
      // Map each element using user specified function
      val schemaEval = tbox.eval(q"$functionSymbol.getSchema()")
      //println("************dynamic schema****************")
      //println(schemaEval)
      schemaEval.asInstanceOf[StructType]
    }


  }

}


/**
  * A Evaluator interface for dynamic scala code
  */
trait CodeEvaluator extends BaseTrait {

  var name: String = _


  /**
    * Schecma from given code
    *
    * @param step
    * @return
    */
  def evaluateSchema(code: String): StructType

}

