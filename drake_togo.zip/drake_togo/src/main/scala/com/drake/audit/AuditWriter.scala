package com.drake.reader

import com.drake._
import com.drake.model.Model.Audit
import org.apache.spark.sql.SaveMode

/**
  * An Audit Writer for the Sink process
  */
object AuditWriter {

  /**
    * Builds specific Reader
    */
  class BaseAuditWriter(handlername: String) extends AuditWriter {

    name = handlername

    /**
      * @param audit
      * @return
      *         Stores given audit data for sink which was in process
      */
    override def storeAuditRef(audit: Audit): Unit = {
      logger.debug("BaseAuditWriter:storeAuditReference")

      //
      val sparkSession = SparkHelper.getSparkSession()

      import sparkSession.implicits._

      val auditDF = Seq(audit).toDF()

      //
      val opts = Map[String, String]()

      //
      //
      auditDF
        .write //Stream
        .format("csv")
        .options(opts)
        //.partitionBy(partCols: _*)
        .mode(SaveMode.Append)
        .save("output/audit")

      //
    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): AuditWriter = {
    getAuditWriter(s)
  }

  // an alternative factory method (use one or the other)
  def getAuditWriter(s: String): AuditWriter = {
    new BaseAuditWriter(s)
  }

}

/**
  * An Audit Writer for the Sink process
  */
trait AuditWriter extends BaseTrait {

  var name: String = _

  /**
    * Returns DataFrame by reading data from source with defined type
    *
    * @param audit
    * @return
    */
  def storeAuditRef(audit: Audit): Unit

}
