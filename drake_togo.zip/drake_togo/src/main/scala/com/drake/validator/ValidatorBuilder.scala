package com.drake.validator

import com.drake.BaseTrait
import com.drake.model.Model.Step
import org.apache.spark.sql.DataFrame

/**
  * A Builder class for Validation on input content
  */
object ValidatorBuilder {

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): ValidatorBuilder = {
    getWriterBuilder(s)
  }

  // an alternative factory method (use one or the other)
  def getWriterBuilder(s: String): ValidatorBuilder = {
    new BaseValidator(s)
  }

  /**
    * Builds specific Writer
    */
  class BaseValidator(handlername: String) extends ValidatorBuilder {

    name = handlername

    /**
      * Valdidates the content in all DataFrame columns
      *
      * @param step
      * @return
      */
    override def validContent(step: Step, input: DataFrame): Boolean = {
      logger.debug("BaseValidator:validContent")

      var valid = true

      //
      //input.select(input.columns.map(c => isnull(col(c)).alias(c)): _*)

      val firstNull = input.filter(row => row.anyNull).head(1)

      firstNull.map(row => valid = false)

      //def rowHasNull = udf((row: Row) => row.anyNull)

      //val multiplyDf = input.withColumn("status", rowHasNull(struct(input.columns.map(col): _*)))

      valid
    }


  }

}


/**
  * A Builder interface for content validations
  */
trait ValidatorBuilder extends BaseTrait {

  var name: String = _


  /**
    * Writes DataFrame content to Sink
    *
    * @param step
    * @return
    */
  def validContent(step: Step, input: DataFrame): Boolean

}
