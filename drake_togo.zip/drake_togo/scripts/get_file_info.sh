#!/bin/bash
# My example bash script
#echo "Hello World"
#echo "FILE_DATE=`hadoop fs -cat {HDFS_TMP_FILE} | awk -F '[|.]' '{print $1}'`"
echo "FILE_NAME=sales-sample_20181222_00.csv"
echo "FILE_DATE=2018-12-22"
echo "FILE_HR=00"
echo "FILE_CNT=120"