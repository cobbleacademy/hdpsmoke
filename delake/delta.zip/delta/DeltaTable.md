Delta Lake and Delta Engine
===========================

Overview
--------
Delta Lake is an open source storage layer that provides ACID transactions, scalable metadata handling, and unifies streaming and batch data processing. Delta Lake runs on top of existing data lake and is fully compatible with Apache Spark APIs. Automatically handles schema variations to prevent insertion of bad records during ingestion. Data versioning enables rollbacks, full historical audit trails, and reproducible machine learning experiments. Supports merge, update and delete operations. Delta Engine optimizations make Delta Lake operations highly performant, supporting a variety of workloads ranging from large-scale ETL processing to ad-hoc, interactive queries.


![](delta-0.jpg)



Delta table
-----------

- Load or modify the data as described in below steps, these steps makes CDC data lands into delta lake table.

  - At T1, create inventory delta lake table with food items
  - At T2, the cheese items are updated/appended into inventory delta lake table
  - At T3, the tools items are updated/appended into inventory delta lake table
  - At T4, the armor items are appended into inventory delta lake table

```scala
val path = new java.io.File("./inventory/").getCanonicalPath

// read T1 json file
df = spark.read.json(path)

// create inventory delta lake table
df.write.format("delta").mode(SaveMode.Overwrite).save(path)

val deltaTable = DeltaTable.forPath(spark, path)

// T2 update T1 and append T2 json file
deltaTable.update(condition = expr("category == 'food' AND description == 'Bread' AND itemid == 'FI-AG-G08' AND price == 1.0"), Map("price" -> lit(2.0)))
df.write.format("delta").mode(SaveMode.Append).save(path)

// T3 update T2 and append T3 json file
deltaTable.update(condition = expr("category == 'cheese' AND description == 'Manchego' AND itemid == 'ST-RF-M04' AND price == 4.0"), Map("price" -> lit(6.0)))
df.write.format("delta").mode(SaveMode.Append).save(path)

// T4 append T4 json file
df.write.format("delta").mode(SaveMode.Append).save(path)
```

- Data after each time delta lake table is updated

```
// T1: food items
+--------+-----------+---------+-----+
|category|description|   itemid|price|
+--------+-----------+---------+-----+
|    food|       Wine| MB-AG-G0|  4.0|
|    food|      Bread|FI-AG-G08|  1.0|
|    food|   Crackers|BS-AG-G09| 10.0|
+--------+-----------+---------+-----+

// T2: updated food item and appended cheese items
+--------+-----------+---------+-----+
|category|description|   itemid|price|
+--------+-----------+---------+-----+
|  cheese|  Roquefort|SC-MG-G10|  4.0|
|  cheese|   Manchego|ST-RF-M04|  4.0|
|  cheese|       Feta|SP-FA-R08|  6.0|
|  cheese|  Camembert|SC-QT-G12| 35.0|
|    food|       Wine| MB-AG-G0|  4.0|
|    food|      Bread|FI-AG-G08|  2.0|
|    food|   Crackers|BS-AG-G09| 10.0|
+--------+-----------+---------+-----+

// T3: update cheese item and appended tools items
+--------+----------------------------+---------+-----+
|category|description                 |itemid   |price|
+--------+----------------------------+---------+-----+
|tools   |'Epic Fondue Set'           |WC-SH-A01|90.0 |
|tools   |'Cheese Board of Glory'     |CU-PG-G06|65.0 |
|tools   |'The Best Cheese Knife'     |WC-SH-A02|9.0  |
|cheese  |Roquefort                   |SC-MG-G10|4.0  |
|cheese  |Manchego                    |ST-RF-M04|6.0  |
|cheese  |Feta                        |SP-FA-R08|6.0  |
|cheese  |Camembert                   |SC-QT-G12|35.0 |
|food    |Wine                        |MB-AG-G0 |4.0  |
|food    |Bread                       |FI-AG-G08|2.0  |
|food    |Crackers                    |BS-AG-G09|10.0 |
+--------+----------------------------+---------+-----+


// T4: appended armor items
+--------+----------------------------+---------+-----+
|category|description                 |itemid   |price|
+--------+----------------------------+---------+-----+
|armor   |'Vegan Friendly Gloves'     |DB-SG-G01|25.0 |
|armor   |'Superbly Comfortable Boots'|DC-SG-G02|30.0 |
|tools   |'Epic Fondue Set'           |WC-SH-A01|90.0 |
|tools   |'Cheese Board of Glory'     |CU-PG-G06|65.0 |
|tools   |'The Best Cheese Knife'     |WC-SH-A02|9.0  |
|cheese  |Roquefort                   |SC-MG-G10|4.0  |
|cheese  |Manchego                    |ST-RF-M04|6.0  |
|cheese  |Feta                        |SP-FA-R08|6.0  |
|cheese  |Camembert                   |SC-QT-G12|35.0 |
|food    |Wine                        |MB-AG-G0 |4.0  |
|food    |Bread                       |FI-AG-G08|2.0  |
|food    |Crackers                    |BS-AG-G09|10.0 |
+--------+----------------------------+---------+-----+

```

Time Travel
------------

- The below statements to retrieve latest as well as point-in-time snapshots

```scala
val path = new java.io.File("./inventory/").getCanonicalPath

spark.sql("CREATE TABLE inventory (category string,description string, itemid string, price double) USING DELTA LOCATION './inventory/'")

//latest
spark.read.format("delta").load(path).show

// At T4 or latest
spark.read.format("delta").option("versionAsOf", 5).load(path).show

// At T3
spark.read.format("delta").option("versionAsOf", 4).load(path).show

// At T2
spark.read.format("delta").option("versionAsOf", 2).load(path).show

// At T1
spark.read.format("delta").option("versionAsOf", 0).load(path).show

```

Time travel snapshot data
-------------------------

```
//Latest Data
+--------+----------------------------+---------+-----+
|category|description                 |itemid   |price|
+--------+----------------------------+---------+-----+
|armor   |'Vegan Friendly Gloves'     |DB-SG-G01|25.0 |
|armor   |'Superbly Comfortable Boots'|DC-SG-G02|30.0 |
|tools   |'Epic Fondue Set'           |WC-SH-A01|90.0 |
|tools   |'Cheese Board of Glory'     |CU-PG-G06|65.0 |
|tools   |'The Best Cheese Knife'     |WC-SH-A02|9.0  |
|cheese  |Roquefort                   |SC-MG-G10|4.0  |
|cheese  |Manchego                    |ST-RF-M04|6.0  |
|cheese  |Feta                        |SP-FA-R08|6.0  |
|cheese  |Camembert                   |SC-QT-G12|35.0 |
|food    |Wine                        |MB-AG-G0 |4.0  |
|food    |Bread                       |FI-AG-G08|2.0  |
|food    |Crackers                    |BS-AG-G09|10.0 |
+--------+----------------------------+---------+-----+


// T4 point-in-time snapshot
+--------+----------------------------+---------+-----+
|category|description                 |itemid   |price|
+--------+----------------------------+---------+-----+
|armor   |'Vegan Friendly Gloves'     |DB-SG-G01|25.0 |
|armor   |'Superbly Comfortable Boots'|DC-SG-G02|30.0 |
|tools   |'Epic Fondue Set'           |WC-SH-A01|90.0 |
|tools   |'Cheese Board of Glory'     |CU-PG-G06|65.0 |
|tools   |'The Best Cheese Knife'     |WC-SH-A02|9.0  |
|cheese  |Roquefort                   |SC-MG-G10|4.0  |
|cheese  |Manchego                    |ST-RF-M04|6.0  |
|cheese  |Feta                        |SP-FA-R08|6.0  |
|cheese  |Camembert                   |SC-QT-G12|35.0 |
|food    |Wine                        |MB-AG-G0 |4.0  |
|food    |Bread                       |FI-AG-G08|2.0  |
|food    |Crackers                    |BS-AG-G09|10.0 |
+--------+----------------------------+---------+-----+


// T3 point-in-time snapshot
+--------+-----------------------+---------+-----+
|category|description            |itemid   |price|
+--------+-----------------------+---------+-----+
|tools   |'Epic Fondue Set'      |WC-SH-A01|90.0 |
|tools   |'Cheese Board of Glory'|CU-PG-G06|65.0 |
|tools   |'The Best Cheese Knife'|WC-SH-A02|9.0  |
|cheese  |Roquefort              |SC-MG-G10|4.0  |
|cheese  |Manchego               |ST-RF-M04|6.0  |
|cheese  |Feta                   |SP-FA-R08|6.0  |
|cheese  |Camembert              |SC-QT-G12|35.0 |
|food    |Wine                   |MB-AG-G0 |4.0  |
|food    |Bread                  |FI-AG-G08|2.0  |
|food    |Crackers               |BS-AG-G09|10.0 |
+--------+-----------------------+---------+-----+


// T2 point-in-time snapshot
+--------+-----------+---------+-----+
|category|description|itemid   |price|
+--------+-----------+---------+-----+
|cheese  |Roquefort  |SC-MG-G10|4.0  |
|cheese  |Manchego   |ST-RF-M04|4.0  |
|cheese  |Feta       |SP-FA-R08|6.0  |
|cheese  |Camembert  |SC-QT-G12|35.0 |
|food    |Wine       |MB-AG-G0 |4.0  |
|food    |Bread      |FI-AG-G08|2.0  |
|food    |Crackers   |BS-AG-G09|10.0 |
+--------+-----------+---------+-----+


// T1 point-in-time snapshot
+--------+-----------+---------+-----+
|category|description|itemid   |price|
+--------+-----------+---------+-----+
|food    |Wine       |MB-AG-G0 |4.0  |
|food    |Bread      |FI-AG-G08|1.0  |
|food    |Crackers   |BS-AG-G09|10.0 |
+--------+-----------+---------+-----+
```


Supported Fetaures
------------------

* Table batch reads and writes
* Table streaming reads and writes
* Table deletes, updates, and merges
* Concurrency control
* Table versioning
* Table optimize
* Change data feed
* Constraints
