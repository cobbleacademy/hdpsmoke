CDC - Change Data Capture 
=========================

CDC is a software design pattern used to determine and track the data that has changed. This is a data integration 
approach based on which changes are captured and delivered to different consumption systems to take certain action on changed data.

There are several methodologies available to capture a change in the system. In this methodology 
one system has the data changed from previous point in time where second system needs to perform an action on changed data.

![](cdc-0.png)

CDC - ways to capture
----------------------

* Timestamps
  * A column such as LAST_UPDATE, etc. are common.

* Version numbers
  * A column such as VERSION_NUMBER represents current and previous versions for similar rows

* Status indicators
  * A column such STATUS indicates where a change is significant or not

* Time/Version/Status
  * This combines the above 3 options

* Triggers
  * An event can be fired in reaction to a change then updates another system/table/queue/topic etc

* Event programming
  * Involves a programming for the generated change event to update another system/table/queue or perform some action

* Log scanners
  * Most DBMS systems maintain transaction log of each change that happens to table data. This option provides a non-intrusive approach to capture changes across the database rather than single table.

Example
-------

The below example items inventory shows the changes as time moves on.

Items Inventory:
---------------

The following data shows how items added or removed or updated at given point of time along with the history.

![](cdc-1.jpg)

##### At Time T1, an inventory of food items started wtih below price values


```
T1:
{"category": "food", "itemid": "MB-AG-G0", "price": 4.0, "description": "Wine"}, 
{"category": "food", "itemid": "FI-AG-G08", "price": 1.0, "description": "Bread"}, 
{"category": "food", "itemid": "BS-AG-G09", "price": 10.0, "description": "Crackers"},
```

##### At Time T2, some of food prices updated and new cheese items added to inventory

```
T2:
{"category": "food", "itemid": "FI-AG-G08", "price": 2.0, "description": "Bread"}, 
{"category": "cheese", "itemid": "SC-MG-G10", "price": 4.0, "description": "Roquefort"}, 
{"category": "cheese", "itemid": "ST-RF-M04", "price": 4.0, "description": "Manchego"}, 
{"category": "cheese", "itemid": "SP-FA-R08", "price": 6.0, "description": "Feta"}, 
{"category": "cheese", "itemid": "SC-QT-G12", "price": 35.0, "description": "Camembert"}, 
```

##### At Time T3, some of cheese prices updated and new tools items added to inventory

```
T3:
{"category": "cheese", "itemid": "ST-RF-M04", "price": 6.0, "description": "Manchego"}, 
{"category": "tools", "itemid": "WC-SH-A01", "price": 90.0, "description": "'Epic Fondue Set'"}, 
{"category": "tools", "itemid": "CU-PG-G06", "price": 65.0, "description": "'Cheese Board of Glory'"}, 
{"category": "tools", "itemid": "WC-SH-A02", "price": 9.0, "description": "'The Best Cheese Knife'"}, 
```

##### At Time T4, just new armor items added to inventory

```
T4:
{"category": "armor", "itemid": "DB-SG-G01", "price": 25.0, "description": "'Vegan Friendly Gloves'"}, 
{"category": "armor", "itemid": "DC-SG-G02", "price": 30.0, "description": "'Superbly Comfortable Boots'"}
```

From the above data, possible questions can be raised 
-----------------------------------------------------

* Is there a system that
  * can show latest inventory
  * can show inventory at a given point-in-time
  * allows corrections to data
  * allows ACID transactions
  * unifies batch and streaming
  * allow stream from prior changes
  * allow check constraints on values
  * capture change data


##### Let's see which system handles above scenarios..........