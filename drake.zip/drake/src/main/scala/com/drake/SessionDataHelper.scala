package com.drake

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

import scala.collection.mutable
import java.time.{Instant, LocalDate, LocalTime}

/**
  * A Helper class to save session data by step in pipeline
  */
object SessionDataHelper {

  private var sessionData: mutable.Map[String, mutable.Map[String, String]] = _

  /**
    * Returns SessionData across packages
    */
  def buildSessionData(args: Array[String]): Unit = {
    //
    sessionData = mutable.Map[String, mutable.Map[String, String]]()

    //
    // Add arguments as default step
    //
    val stepMap: mutable.Map[String, String] = mutable.Map[String, String]()
    for((x,i) <- args.view.zipWithIndex) stepMap += (i.toString -> x)
    sessionData += ("args" -> stepMap)

    //
    // Add sys values as default step
    //
    val procConstMap: mutable.Map[String, String] = mutable.Map(
      "processEpochMs" -> Instant.now.toEpochMilli.toString,
      "processEpochSec" -> Instant.now.getEpochSecond.toString,
      "processDt" -> LocalDate.now.toString,
      "processHr" -> LocalTime.now.getHour.toString
    )
    sessionData += ("sys" -> procConstMap)
  }


  /**
    * Returns value for the given key with parentage step
    * @param parentageKey
    * @return
    */
  def parentageLookup(parentageKey: String): String = {
    //
    var value = parentageKey

    //
    if (parentageKey.startsWith("$")) {
      val arr = parentageKey.substring(1).split("#")
      val stepMap: mutable.Map[String, String] = sessionData.getOrElse(arr(0).toString, mutable.Map[String, String]())
      value = stepMap.getOrElse(arr(1), "")
    }

    //
    value
  }

  /**
    * Returns the Spark Session Data
    *
    * @return
    */
  def getSessionData(): mutable.Map[String, mutable.Map[String, String]] = {
    sessionData
  }

}
