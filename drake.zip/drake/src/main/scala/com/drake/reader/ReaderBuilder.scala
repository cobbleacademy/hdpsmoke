package com.drake.reader

import java.text.SimpleDateFormat
import java.util.Calendar

import com.drake._
import com.drake.model.Model.Step
import com.drake.status.StatusBuilder
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.apache.spark.sql.types.StructType

import scala.collection.mutable

/**
  * A Builder interface for all the Source Readers
  */
object ReaderBuilder {

  /**
    * Builds specific Reader
    */
  class BaseReader(handlername: String) extends ReaderBuilder {

    name = handlername

    /**
      * Builds the scheam from the given code
      *
      * @param schemaAttrs
      * @return
      */
    def createSchema(schemaAttrs: Map[String, String]): StructType = {

      // instantiate and delegate to Schema class
      val klassName = schemaAttrs.getOrElse("schemaCommand", com.drake.schema.SchemaBuilder.DEFAULT_SCHEMA_BUILDER)
      val schemaKlass = Class.forName(klassName).getConstructor(name.getClass).newInstance(name).asInstanceOf[ {def buildSchema(schemaAttrs: Map[String, String]): StructType}]

      // Default Schema Build
      val readerSchema = schemaKlass.buildSchema(schemaAttrs)
      println(readerSchema)

      readerSchema
    }


    /**
      * Saves Properties in SessionData
      *
      * @param step
      * @param readFile
      */
    def saveSessionData(step: Step, readFrame: DataFrame): Unit = {
      //
      val stepAttrs = step.attributes.getOrElse(Map())
      val postAttrs = step.post.getOrElse(Map())

      //
      val cnt = readFrame.rdd.count()
      val fnames = readFrame.inputFiles.map(_.split("/").last).mkString("|")
      val now = Calendar.getInstance().getTime()
      val nowFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SZ")
      val nowStr = nowFormat.format(now)
      val statusComment = stepAttrs.getOrElse("statusComment", "")
      //
      val sessDataMap = SessionDataHelper.getSessionData()
      val stepMap: mutable.Map[String, String]
      = mutable.Map("fileName" -> fnames, "fileDt" -> "2018-12-22", "fileHr" -> "00", "count" -> cnt.toString, "startTime" -> nowStr, "endTime" -> "", "comment" -> statusComment, "srcSystem" -> "sales")
      sessDataMap += (name -> stepMap)

      // Run post process scripts
      if (!postAttrs.isEmpty) {
        import sys.process._
        val cmd = postAttrs.getOrElse("path", "") + "/" + postAttrs.getOrElse("name", "")
        val shellResult = Process(cmd).lineStream //cmd.!!;val arr = shellResult.split("\\n")
        println("Printing shellResult....")
        shellResult.foreach(x => {
          val arr = x.split("=")
          println(x + " ++ " + arr(0) + " = " + arr(1))
          stepMap += (arr(0) -> arr(1))
          println(stepMap.getOrElse(arr(0), ""))
        })
      }

    }

    /**
      * Store the status of read file
      *
      * @param step
      */
    def logStatus(step: Step): Unit = {
      //
      val sparkSession = SparkHelper.getSparkSession()
      val sessDataMap = SessionDataHelper.getSessionData()
      val stepMap: mutable.Map[String, String] = sessDataMap.getOrElse(name, mutable.Map[String, String]())

      //
      import sparkSession.implicits._
      //
      val statusDf = Seq(
        (stepMap.get("fileName"), stepMap.get("fileDt"), stepMap.get("fileHr"), stepMap.get("count")
          , stepMap.get("comment"), stepMap.get("srcSystem")
        )
      ).toDF("file_name", "file_dt", "file_hr", "record_count", "comment", "src_system")
        .withColumn("start_time", lit(current_timestamp()))
        .withColumn("end_time", lit(""))
        .select("file_name", "file_dt", "file_hr", "record_count", "start_time", "end_time", "comment", "src_system")

      //
      StatusBuilder(name).statusSink(step, statusDf)

    }

    /**
      * Returns DataFrame by reading data from source with defined type
      *
      * @param step
      * @return
      */
    override def readSource(step: Step): DataFrame = {
      logger.debug("BaseReader:readSource")

      //
      val sparkSession = SparkHelper.getSparkSession()

      //
      //val stepOpts = step.options.getOrElse(Seq(Attribute("", ""))) val stepOptsMap = Map(stepOpts map { a => a.key -> a.value }: _*)
      //
      val stepOpts = step.options.getOrElse(Map())
      val stepAttrs = step.attributes.getOrElse(Map())
      val postAttrs = step.post.getOrElse(Map())

      //
      var inStreamDf: DataFrame = null

      //
      if ("stream".equals(PropsUtil.getWorkflow().mode)) {

        //
        var streamDf: DataFrame = null

        //
        if ("kafka".equals(step.format.getOrElse(""))) {

          // merge bot main and workflow options
          val mergedOpts = PropsUtil.getKafkaConsumerParams() ++ stepOpts

          //
          streamDf = sparkSession
            .readStream
            .options(mergedOpts)
            .format(step.format.getOrElse(""))
            .load()
            .selectExpr(stepAttrs.getOrElse("kafkaSelectExpr", "*"))

        } else {

          //
          streamDf = sparkSession
            .readStream
            .options(stepOpts)
            .format(step.format.getOrElse(""))
            .schema(createSchema(stepAttrs)) // create schema
            .load()

        }

        // return
        inStreamDf = streamDf

      } else {

        if ("hive".equals(step.format.getOrElse(""))) {
          //
          inStreamDf = sparkSession.sql(stepAttrs.getOrElse("sql", ""))

        } else if ("fixedwidth".equals(step.format.getOrElse(""))) {

          //
          // read fixedwidth files
          //
          val fixedRawDf = sparkSession.read
            .options(stepOpts)
            .text()
            .filter(r => !r.getAs[String](0).trim.isEmpty)

          // return
          inStreamDf = fixedRawDf

        } else if ("jdbc".equals(step.format.getOrElse(""))) {

          //
          val jdbcDf = sparkSession
            .read
            .format(step.format.getOrElse(""))
            .options(stepOpts)
            //.option("partitionColumn", "owner_id")
            //.option("lowerBound", 1)
            //.option("upperBound", 10000)
            .load()

          //
          jdbcDf.printSchema()
          jdbcDf.show(false)

          // return
          inStreamDf = jdbcDf

        } else {

          //
          val fileStreamDf = sparkSession.read
            .options(stepOpts)
            .format(step.format.getOrElse("")) //"org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
            .schema(createSchema(stepAttrs)) // create schema
            .load()
          //.csv(stepAttrs.getOrElse("path", ""))

          // not needed when running on cluster but stanalone mode
          //val localPrefix = "/Users/nnagaraju/IDEAWorkspace/drake/"
          val localPrefix = ""

          //val ldstDrTbl = "drop table if exists load_status"
          //val ldstCrTbl = s"create table if not exists load_status(file_name string,file_dt string,file_hr string,record_count string,start_time string,end_time string,comment string) partitioned by (src_system string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/load_status'"
          //val stgDrTbl = "drop table if exists sales_stg"
          //val stgCrTbl = "create external table if not exists sales_stg(transactionId int,customerId int,itemId int,amountPaid double) row format delimited fields terminated by ',' stored as textfile location 'input/sales'"
          //val domDrTbl = "drop table if exists sales"
          //val domCrTbl = "create table if not exists sales(transactionId int,customerId int,itemId int,amountPaid double) partitioned by (process_dt string, process_hr int) row format delimited fields terminated by ',' stored as textfile location 'output/sales'"
          //val salesInvDrTbl = "drop table if exists sales_invalid"
          //val salesInvCrTbl = s"create table if not exists sales_invalid(transactionId int,customerId int,itemId int,amountPaid double,invalid_reason string,uuid string,process_epoch bigint,process_dt string,process_hr string) partitioned by (event_dt string, event_hr int) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/sales_invalid'"
          //val domDrTbl = "drop table if exists sales_dom"
          //val domCrTbl = s"create table if not exists sales_dom(transactionId int,customerId int,itemId int,amountPaid double,uuid string,process_epoch bigint,process_dt string,process_hr string) partitioned by (event_dt string, event_hr int) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/sales_dom'"
          //val invColCfgDrTbl = "drop table if exists invalid_col_config"
          //val invColCfgCrTbl = s"create table if not exists invalid_col_config(table_name string,col_name string,data_type string,data_type_check int,null_check int,empty_check int,dup_check int,range_check int,range_check_values string,const_check int,const_check_values string) partitioned by (src_system string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}input/config/invalid_col_config'"
          //val invColStDrTbl = "drop table if exists invalid_col_stats"
          //val invColStCrTbl = s"create table if not exists invalid_col_stats(table_name string,col_name string,sum_dtype_chk_cnt bigint,sum_null_chk_cnt bigint,sum_empty_chk_cnt bigint,sum_dup_chk_cnt bigint,sum_range_chk_cnt bigint,sum_const_chk_cnt bigint,event_hr int,process_epoch bigint,process_dt string,process_hr string) partitioned by (src_system string, event_dt string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/invalid_col_stats'"
          //sparkSession.sql(ldstDrTbl)
          //sparkSession.sql(ldstCrTbl)
          //sparkSession.sql(stgDrTbl)
          //sparkSession.sql(stgCrTbl)
          //sparkSession.sql(salesInvDrTbl)
          //sparkSession.sql(salesInvCrTbl)
          //sparkSession.sql(domDrTbl)
          //sparkSession.sql(domCrTbl)
          //sparkSession.sql(invColCfgDrTbl)
          //sparkSession.sql(invColCfgCrTbl)
          //sparkSession.sql(invColStDrTbl)
          //sparkSession.sql(invColStCrTbl)

          //
          //sparkSession.sql("show databases").show(false)
          //sparkSession.sql("show tables").show(false)
          //sparkSession.sql("select * from sales_stg").show(false)
          //sparkSession.sql("show partitions sales").show(false)
          //sparkSession.sql("show partitions sales_dom").show(false)
          //sparkSession.sql("alter table sales_dom drop if exists partition (process_dt = '2018-12-22')")
          //sparkSession.sql("show partitions sales_dom").show(false)
          //sparkSession.sql("select * from sales").show(false)
          //sparkSession.sql("select * from sales_dom").show(false)

          // return
          inStreamDf = fileStreamDf
        }

        // save properties in session
        saveSessionData(step, inStreamDf)

        //
        // Run post process scripts
        if ("true".equals(stepAttrs.getOrElse("logStatus", "false"))) logStatus(step)

      }


      //
      inStreamDf
    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): ReaderBuilder = {
    getReaderBuilder(s)
  }

  // an alternative factory method (use one or the other)
  def getReaderBuilder(s: String): ReaderBuilder = {
    new BaseReader(s)
  }

}

/**
  * A Builder interface for all the Source Readers
  */
trait ReaderBuilder extends BaseTrait {

  var name: String = _

  /**
    * Returns DataFrame by reading data from source with defined type
    *
    * @param step
    * @return
    */
  def readSource(step: Step): DataFrame

}
