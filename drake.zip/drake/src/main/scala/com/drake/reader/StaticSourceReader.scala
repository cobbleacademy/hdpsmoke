package com.drake.reader

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.broadcast.Broadcast
import java.util.{Calendar, Date}

import scala.collection.mutable

import com.drake.{BaseTrait, SparkHelper}



object StaticSourceReader extends BaseTrait {

  var invCfgData:Array[Row]=null
  var invCfgDataBC:Broadcast[Array[Row]]=null
  var sumChkColDataBC:Broadcast[Map[String, Map[String, Long]]]=null


  /**
    * Initialize Invalid Config Data
    * @param config
    * @return
    */
  def initInvalidConfigReference(configAttrs: Map[String, String]): Unit = {
    //
    logger.info("StaticSourceReader: Creating Invalid Config references")
    val sess =  SparkHelper.getSparkSession()

    //
    sess.sql("msck repair table invalid_col_config")
    val invCfgDF = sess.sql("select * from invalid_col_config where src_system='" + configAttrs.getOrElse("invalidSrcSystem","") + "' and table_name='" + configAttrs.getOrElse("invalidTable","") + "'")
    //println("invCfgDF show")
    //invCfgDF.show(false)

    //
    val invCfgData = invCfgDF.rdd.collect()
    invCfgDataBC=sess.sparkContext.broadcast(invCfgData)
  }


  /**
    * Returns InvalidConfig Broadcast
    * @return
    */
  def getInvCfgDataBroadcast(): Broadcast[Array[Row]] = {
    invCfgDataBC
  }


  /**
    * Returns broadcasted InvalidConfig data
    * @return
    */
  def getInvCfgData(): Array[Row] = {
    invCfgDataBC.value
  }


  /**
    * Returns Broadcast reference of SumChkCol data
    * @param sumChkColMap
    * @return
    */
  def broadcastSumChkColReference(sumChkColMap: Map[String, Map[String, Long]]): Broadcast[Map[String, Map[String, Long]]] = {
    sumChkColDataBC=SparkHelper.getSparkSession.sparkContext.broadcast(sumChkColMap)
    sumChkColDataBC
  }


  /**
    * Returns broadcasted SumChkCol data
    * @return
    */
  def getSumChkColData(): Map[String, Map[String, Long]] = {
    sumChkColDataBC.value
  }


  /**
    * Initialize Invalid Config Data
    * @param config
    * @return
    */
  def getSampleSumChkColDataFrame(configAttrs: Map[String, String]): DataFrame = {
    SparkHelper.getSparkSession.sql("select table_name,col_name from invalid_col_config where src_system='" + configAttrs.getOrElse("invalidSrcSystem","") + "' and table_name='" + configAttrs.getOrElse("invalidTable","") + "'")
  }


  /**
    * Initialize all static sources
    * @param configAttrs
    */
  def initializeStaticSources(configAttrs: Map[String, String]): Unit = {
    initInvalidConfigReference(configAttrs)
  }


}
