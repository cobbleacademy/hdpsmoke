package com.drake.schema

import com.drake.BaseTrait
import org.apache.spark.sql.types.StructType

/**
  * A Builder interface for all the Schema definitions
  */
object SchemaBuilder {

  final val DEFAULT_SCHEMA_BUILDER: String = "com.drake.schema.DefaultSchemaBuilder"
  final val FIXED_WIDTH_SCHEMA_BUILDER: String = "com.drake.schema.FixedWidthSchemaBuilder"

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String): SchemaBuilder = {
    getSchemaBuilder(s)
  }

  // an alternative factory method (use one or the other)
  def getSchemaBuilder(s: String): SchemaBuilder = {
    new DefaultSchemaBuilder(s)
  }

}

/**
  * A Builder interface for all the Schema definitions
  */
trait SchemaBuilder extends BaseTrait {

  var name: String = _
  final val DEFAULT_BUILDER: String = "com.drake.schema.DefaultSchemaBuilder"
  final val FIXED_WIDTH_SCHEMA_BUILDER: String = "com.drake.schema.FixedWidthSchemaBuilder"

  /**
    * Returns the StructType for the source content
    *
    * @param step
    * @return
    */
  def buildSchema(schemaAttrs: Map[String, String]): StructType

  /**
    * Returns the Seq of Ints to mark fixed widths
    *
    * @param schemaAttrs
    * @return
    */
  def buildFixedWidths(schemaAttrs: Map[String, String]): Seq[Int] = {
    Seq[Int]()
  }


  /**
    * Returns true if Record contains/belongs-to given schema
    * @param record
    * @param schemaAttrs
    * @return
    */
  def buildSchemaConformanceFunc(schemaAttrs: Map[String, String]) = (record: String) => {
    true
  }


}

