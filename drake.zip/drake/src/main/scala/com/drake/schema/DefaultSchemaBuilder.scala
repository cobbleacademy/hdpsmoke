package com.drake.schema

import com.drake.PropsUtil
import org.apache.spark.sql.types.StructType

import scala.reflect.runtime.universe.{Quasiquote, runtimeMirror}
import scala.tools.reflect.ToolBox


/**
  * A Default SchemaBuilder for CSV File
  */
class DefaultSchemaBuilder(handlername: String) extends SchemaBuilder {

  name = handlername

  //
  val mirror = runtimeMirror(getClass.getClassLoader)
  val tbox = ToolBox(mirror).mkToolBox()

  /**
    * Returns the StructType for the source content
    *
    * @param step
    * @return
    */
  override def buildSchema(schemaAttrs: Map[String, String]): StructType = {

    //
    val schemaCode = PropsUtil.loadSchemaCode(schemaAttrs.getOrElse("schemaPath", ""))

    //
    val functionWrapper = "object DefaultSchemaBuilderWrapper { " + schemaCode + "}"
    val functionSymbol = tbox.define(tbox.parse(functionWrapper).asInstanceOf[tbox.u.ImplDef])

    //
    val schemaEval = tbox.eval(q"$functionSymbol.getSchema()")
    val schema = schemaEval.asInstanceOf[StructType]

    //
    //
    //    val schema = StructType(
    //      Array(StructField("transactionId", StringType),
    //        StructField("customerId", StringType),
    //        StructField("itemId", StringType),
    //        StructField("amountPaid", StringType)))

    schema
  }

}
