package com.drake.schema

import com.drake.PropsUtil

import scala.reflect.runtime.universe.Quasiquote


/**
  * A Default SchemaBuilder for Fixed Width Files
  */
class FixedWidthSchemaBuilder(handlername: String) extends DefaultSchemaBuilder(handlername) {

  /**
    * Returns the Seq of Ints to mark fixed widths
    *
    * @param step
    * @return
    */
  override def buildFixedWidths(schemaAttrs: Map[String, String]): Seq[Int] = {

    //
    val schemaCode = PropsUtil.loadSchemaCode(schemaAttrs.getOrElse("schemaPath", ""))

    //
    val functionWrapper = "object DefaultSchemaBuilderWrapper { " + schemaCode + "}"
    val functionSymbol = tbox.define(tbox.parse(functionWrapper).asInstanceOf[tbox.u.ImplDef])

    //
    val fixedWidthEval = tbox.eval(q"$functionSymbol.getFixedWidths()")
    val fixedWidths = fixedWidthEval.asInstanceOf[Seq[Int]]

    fixedWidths
  }


  /**
    * Returns whether input record conforms to schema
    * @param record
    * @param schemaAttrs
    * @return
    */
  override def buildSchemaConformanceFunc(schemaAttrs: Map[String, String]): (String => Boolean) = {
    //
    import scala.reflect.runtime.universe._
    import scala.reflect.runtime.currentMirror
    import scala.tools.reflect.ToolBox

    lazy val toolbox = currentMirror.mkToolBox()

//    println("Printing  Symbol details....")
//    println(functionSymbol.info)
//    println(functionSymbol.fullName)
//    println(functionSymbol.isType)
//    println(functionSymbol.isConstructor)
//    println("Printing  Symbol details DONE.")

    //
    lazy val func = {
      //
      val schemaCode = PropsUtil.loadContainsSchemaCode(schemaAttrs.getOrElse("schemaPath", ""))
      val functionWrapper = "new com.drake.DefaultSchemaBuilderWrapper with Serializable { " + schemaCode + "}"
      val functionSymbol = tbox.define(tbox.parse(functionWrapper).asInstanceOf[toolbox.u.ImplDef])
      toolbox.eval(q"$functionSymbol.containsSchemaVal _").asInstanceOf[String => Boolean]
    }

    func
  }

}
