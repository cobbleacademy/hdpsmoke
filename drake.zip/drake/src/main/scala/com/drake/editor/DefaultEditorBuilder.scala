package com.drake.editor

import com.drake.{PropsUtil, SessionDataHelper}
import com.drake.model.Model.{SplitDataFrame, Splitter, Step}
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions.{col, from_json, lit, udf}
import org.apache.spark.sql.types.StructType

import scala.collection.mutable
import scala.reflect.runtime.universe.{Quasiquote, runtimeMirror}
import scala.reflect.runtime.currentMirror
import scala.tools.reflect.ToolBox

/**
  * A Default Editor Builder for CSV File
  */
class DefaultEditorBuilder(handlername: String) extends EditorBuilder {

  name = handlername

  /**
    * Builds the scheam from the given code
    * @param schemaAttrs
    * @return
    */
  def createSchema(schemaAttrs: Map[String, String]): StructType = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", com.drake.schema.SchemaBuilder.DEFAULT_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(name.getClass).newInstance(name).asInstanceOf[ {def buildSchema(schemaAttrs: Map[String, String]): StructType}]

    // Default Schema Build
    val readerSchema = schemaKlass.buildSchema(schemaAttrs)
    println(readerSchema)

    readerSchema
  }


  /**
    * Builds the FixedWidths from the given code
    *
    * @param schemaAttrs
    * @return
    */
  def createFixedWidths(schemaAttrs: Map[String, String]): Seq[Int] = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", com.drake.schema.SchemaBuilder.FIXED_WIDTH_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(name.getClass).newInstance(name).asInstanceOf[ {def buildFixedWidths(schemaAttrs: Map[String, String]): Seq[Int]}]

    // FixedLength Build
    val readerFixedLengths = schemaKlass.buildFixedWidths(schemaAttrs)
    println(readerFixedLengths)

    readerFixedLengths
  }


  /**
    * Ruturns Function from the schema configuration file, this returned function is ready to be executed on data
    * @param record
    * @param schemaAttrs
    * @return
    */
  def createContainsSchemaFunction(schemaAttrs: Map[String, String]): (String => Boolean) = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", com.drake.schema.SchemaBuilder.FIXED_WIDTH_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(name.getClass).newInstance(name).asInstanceOf[ {def buildSchemaConformanceFunc(schemaAttrs: Map[String, String]): (String => Boolean)}]

    // FixedLength Build
    val readerFuncContainsSchema = schemaKlass.buildSchemaConformanceFunc(schemaAttrs)
    //println(readerFuncContainsSchema)

    //
    readerFuncContainsSchema
  }


  /**
    * Parses the input data into multiple strings split based on sequence of fixed widths
    * @param line
    * @param lengths
    * @return
    */
  def parseFixedWidths(line: String, lengths: Seq[Int]): Seq[String] = {
    lengths.indices.foldLeft((line, Array.empty[String])) { case ((rem, fields), idx) =>
      val len = lengths(idx)
      val fld = rem.take(len).trim
      (rem.drop(len), fields :+ fld)
    }._2
  }


  /**
    * Returns DataFrame after processing category
    * @param startDF
    * @param inclAttrs
    * @return
    */
  def includeAttributeTransform(startDF: DataFrame, inclAttrs: Map[String, String]): DataFrame = {
    //
    //val sessDataMap = SessionDataHelper.getSessionData()
    val inclColsMap: mutable.Map[String, String] = mutable.Map[String, String]()

    //
    // include process
    //
    inclAttrs.map(x => {
      val key = x._1
      var value = x._2
      value = SessionDataHelper.parentageLookup(value)
      inclColsMap += (key -> value)
    })
    //
    val inclDf = inclColsMap.foldLeft(startDF)((df, c) =>
      df.withColumn(c._1, lit(c._2))
    )

    //
    inclDf
  }


  /**
    * Returns DataFrame after processing category
    * @param startDF
    * @param startAttrs
    * @return
    */
  def categoryTransform(startDF: DataFrame, startAttrs: Map[String, String]): DataFrame = {

    //
    val ss = startDF.sparkSession
    var categoryDfVar: DataFrame = startDF
    import ss.implicits._

    //
    if ("sql".equals(startAttrs.getOrElse("category", ""))) {
      if (startAttrs.get("currentTempView").isDefined) startDF.createOrReplaceTempView(startAttrs.getOrElse("currentTempView", ""))
      categoryDfVar = ss.sql(startAttrs.getOrElse("sql", ""))

    } else if ("fromjsonschema".equals(startAttrs.getOrElse("category", ""))) {
      // create schema
      val readerSchema = createSchema(startAttrs)

      //
      val jsonColumn = startAttrs.getOrElse("fromJsonColumn", "")
      val jsonAlias = startAttrs.getOrElse("fromJsonAlias", "")

      if ("" != jsonAlias) {
        categoryDfVar = startDF
          .select(from_json(col(jsonColumn), readerSchema).alias(jsonAlias))
          .select(jsonAlias + ".*")
      }

    } else if ("fixedwidthschema".equals(startAttrs.getOrElse("category", ""))) {
      // create schema
      val readerSchema = createSchema(startAttrs)
      val lengths = createFixedWidths(startAttrs)
      // containsFunc takes string(input) and determines whether schema confirms or not
      ///
      ///
      ///
      ///
      val containsFunc = udf {
        new Function1[String,Boolean] with Serializable {
          import scala.reflect.runtime.currentMirror
          import scala.tools.reflect.ToolBox

          lazy val toolbox = currentMirror.mkToolBox()
          lazy val func = {
            println("reflected function") // triggered at every worker
            val schemaCode = PropsUtil.loadContainsSchemaCode(startAttrs.getOrElse("schemaPath", ""))
            toolbox.eval(toolbox.parse(schemaCode)).asInstanceOf[String => Boolean]
          }

          def apply(s: String): Boolean = func(s)
        }
      }
      ///
      ///
      ///
      ///
      val colNames = readerSchema.fieldNames
      val colTypes = readerSchema.fields.map(f => f.dataType)
      val fixedwidthsize = startAttrs.getOrElse("fixedwidthsize", "0").toInt

      //
      val fwMapDf = startDF
        .filter(containsFunc(col("value")))
        .map(r => parseFixedWidths(r.getAs[String](0), lengths))
        .toDF()
      //
      val fwAllColsDf = lengths.indices.foldLeft(fwMapDf) { case (result, idx) =>
        result.withColumn(colNames(idx), $"value".getItem(idx).cast(colTypes(idx)))
      }
      //
      categoryDfVar = fwAllColsDf.drop("value")
    }

    //categoryDfVar.show(false)

    //
    categoryDfVar
  }


  /**
    * @param begin
    * @param iterDf
    * @param convArray
    * @return Returns DataFrame after processing categories in sequence of transformations
    */
  def recursiveCategoryTransform(begin: Int, iterDf: DataFrame, convArray: Array[Map[String, String]]): DataFrame = {

    //
    var iterCurrDfVar: DataFrame = iterDf
    val ss: SparkSession = iterDf.sparkSession

    //
    val iterConvAttrGroup = convArray.filter(x => begin == x.getOrElse("seq","-1").toInt)
    //
    if (!iterConvAttrGroup.isEmpty) {
      //
      val iterConvAttrCurr: Map[String, String] = iterConvAttrGroup(0)
      val nextIterCurrDf: DataFrame = categoryTransform(iterDf, iterConvAttrCurr)

      //
      iterCurrDfVar = recursiveCategoryTransform((begin+1), nextIterCurrDf, convArray)
    }

    //
    iterCurrDfVar
  }


  /**
    * //
    * //val multiplyDf = inclDf.withColumn("amountPaid", input("amountPaid") * 2)
    * //def rowHasNull = udf((row: Row) => row.anyNull)
    * //val multiplyDf = input.withColumn("status", rowHasNull(struct(input.columns.map(col): _*)))
    * //multiplyDf
    *
    * @param step
    * @return Returns the transformed input DataFrame
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {

    //
    //
    //
    val ss = input.sparkSession
    val sessDataMap = SessionDataHelper.getSessionData()
    val inclColsMap: mutable.Map[String, String] = mutable.Map[String, String]()
    val stepAttrs = step.attributes.getOrElse(Map())
    val convAttrs = step.conversions.getOrElse(Array[Map[String, String]]())
    val inclAttrs = step.include.getOrElse(Map())
    val postAttrs = step.post.getOrElse(Map())
    val splitter = step.splitter.getOrElse(Splitter("", Seq[Map[String, String]]()))


    //
    // pre process before include and post
    //
    var preDfVar: DataFrame = input
    // custom transformations either sql or schema
    if (!stepAttrs.isEmpty) preDfVar = categoryTransform(input, stepAttrs)
    //
    val preDf = preDfVar



    //
    // pre process before include and post
    //
    var convDfVar: DataFrame = preDf
    //
    if (!convAttrs.isEmpty) convDfVar = recursiveCategoryTransform(1, preDf, convAttrs)
    //
    val convDf = convDfVar




    //
    // include process
    //
    var inclDfVar: DataFrame = convDf
    //
    if (!inclAttrs.isEmpty) inclDfVar = includeAttributeTransform(convDf, inclAttrs)
    //
    val inclDf = inclDfVar




    //
    // post sql execution
    //
    var postDfVar: DataFrame = inclDf
    // custom transformations either sql or schema
    if (!postAttrs.isEmpty) postDfVar = categoryTransform(inclDf, postAttrs)
    //
    val postDf = postDfVar


    //
    var mutSplitDfSeqVar: Seq[SplitDataFrame] = Seq(SplitDataFrame(step.label.getOrElse(""), postDf))
    //
    if (!splitter.tempView.isEmpty) {
      // register tempView as
      postDf.createOrReplaceTempView(splitter.tempView)
      splitter.splits.foreach(f => {
        val currDf: DataFrame = categoryTransform(postDf, f)
        val currSplitDf = SplitDataFrame(f.getOrElse("label", ""), currDf)
        mutSplitDfSeqVar = mutSplitDfSeqVar :+ currSplitDf
      })
    }
    //
    val mutSplitDfSeq = mutSplitDfSeqVar



    //
    mutSplitDfSeq
  }
}
