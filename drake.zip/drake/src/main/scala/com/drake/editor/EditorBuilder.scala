package com.drake.editor

import com.drake.BaseTrait
import com.drake.model.Model.{SplitDataFrame, Step}
import org.apache.spark.sql.DataFrame

/**
  * A Builder interface for all the transformations
  */
trait EditorBuilder extends BaseTrait {

  var name: String = _

  /**
    * Returns the transformed DataFrame
    *
    * @param step
    * @return
    */
  def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame]

}


