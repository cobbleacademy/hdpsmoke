package com.drake.editor

import com.drake.model.Model.{SplitDataFrame, Step}
import org.apache.spark.sql.functions.{col, lit, struct, udf}
import org.apache.spark.sql.{DataFrame, Row}

/**
  * A Default Editor Builder for CSV File
  */
class DefaultInValidEditorBuilder(handlername: String) extends EditorBuilder {

  name = handlername

  /**
    * Returns the transformed input DataFrame
    *
    * @param step
    * @return
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {
    //
    def rowHasNull = udf((row: Row) => row.anyNull)

    //
    val statusDf = input
      .withColumn("fwstatus", rowHasNull(struct(input.columns.map(col): _*)))

    val invalidDf = statusDf.filter(statusDf("fwstatus") === lit("true")).drop("fwstatus")

    //invalidDf

    //
    Seq(SplitDataFrame(step.label.getOrElse(""), invalidDf))
  }
}
