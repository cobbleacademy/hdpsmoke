Terminal Tab1:
=========================

cd ~/AppDev/vueworkspace/

npm install --global @vue/cli
npm audit fix --force

vue create file-csv-vue

npm install vue-csv-import --save
npm audit fix --force

npm install axios --save
npm install papaparse --save
npm install vue-sidebar-menu --save

npm audit fix --force

<copy attached App.vue and PreviewCsv.vue into src/App.vue & src/components/PreviewCsv.vue>

Terminal Tab2: (To kill press Cntrl+C)
=========================
npm run serve


Open Browser as below:
==========================
  App running at:
  - Local:   http://localhost:8080/ 
  - Network: http://192.168.86.145:8080/



Alternative Tool:
==========================
https://valoremreply.com/post/building-confidence-in-your-data-with-delta-live-tables-and-valorem-data-quality-dashboard/?utm_source=LinkedIn&utm_medium=social&utm_campaign=socialpost
