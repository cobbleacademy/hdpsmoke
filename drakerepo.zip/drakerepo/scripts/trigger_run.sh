#!/bin/bash
echo "FuncName=$1"
echo "ProcName=$2"
