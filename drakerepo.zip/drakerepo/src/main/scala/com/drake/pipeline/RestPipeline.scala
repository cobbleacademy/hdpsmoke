package com.drake.pipeline

import com.drake.{BaseTrait, PropsUtil}
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import akka.Done
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.StatusCodes
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.{ExceptionHandler, Route}
import akka.http.scaladsl.server.directives.Credentials
import akka.stream.ActorMaterializer
import com.drake.crypto.CryptoBuilder
import spray.json.{JsString, JsValue, JsonFormat, deserializationError}
import spray.json.DefaultJsonProtocol._

import scala.collection.mutable
import scala.concurrent.duration._
import scala.concurrent.Future
import scala.util.Try




/**
  * A pipeline runs in rest equivalent mode which reads from dataset and returns another dataset
  */
object RestPipeline extends BaseTrait {

  //
  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()
  implicit val executionConext = system.dispatcher


  /**
    * An entry point to run REST pipeline
    * @param inData
    */
  def runRestPipeline(inData: Map[String, String]): Unit = {
    //
    Pipeline.runRestPipeline(inData)
  }


  /**
    * A secured Web Sservice request to generate response
    *
    * @param strings
    */
  def webServiceSecured(strings: Array[String]): Unit = {

    case class BasicAuthCredentials(username: String, password: String)

    case class OAuthToken(access_token: String = java.util.UUID.randomUUID().toString,
                          token_type: String = "bearer",
                          expires_in: Int = 3600)

    case class LoggedInUser(basicAuthCrendentials: String,
                            oAuthToken: OAuthToken = new OAuthToken,
                            loggedAt: LocalDateTime = LocalDateTime.now())


    //
    // all implicits
    //
    implicit val localDateTimeFormat = new JsonFormat[LocalDateTime] {

      private val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME
      private val deserializationErrorMessage =
        s"Expected date time in ISO offset date time format ex. ${LocalDateTime.now().format(formatter)}"

      override def write(obj: LocalDateTime): JsValue = JsString(formatter.format(obj))

      override def read(json: JsValue): LocalDateTime = {
        json match {
          case JsString(dtString) =>
            Try(LocalDateTime.parse(dtString, formatter)).getOrElse(deserializationError(deserializationErrorMessage))
          case _ => deserializationError(deserializationErrorMessage)
        }
      }

    }
    //
    implicit val basicAuthFormat = jsonFormat2(BasicAuthCredentials)
    implicit val oAuthTokenFormat = jsonFormat3(OAuthToken)
    implicit val loggedInUserFormat = jsonFormat3(LoggedInUser)

    //
    // An exception handler for route
    //
    val exceptionHandler = ExceptionHandler {
      case e: Exception => complete(StatusCodes.Conflict, e.getMessage)
    }

    //
    val bindServer = PropsUtil.propValue("spark.rest.bind.server", "0.0.0.0")
    val bindPort = PropsUtil.propValue("spark.rest.bind.port", "8180")
    val bindAuth = PropsUtil.propValue("spark.rest.bind.auth", "auth")
    val bindResource = PropsUtil.propValue("spark.rest.bind.resource", "getRequest")
    //
    val bindUsers = PropsUtil.propValue("spark.rest.bind.users", "accel-app")
    val bindSecrets = PropsUtil.propValue("spark.rest.bind.secrets", "accel-app")
    val bindRoutes = PropsUtil.propValue("spark.rest.bind.routes", "accel-routes")
    val bindRealm = PropsUtil.propValue("spark.rest.bind.realm", "accel-realm")
    val bindTokExpEnabled = PropsUtil.propValue("spark.rest.bind.token.expire.enabled", "true").toBoolean
    val bindTokExpSec = PropsUtil.propValue("spark.rest.bind.token.expire.seconds", "-1").toInt
    val bindShowNumChars = PropsUtil.propValue("spark.rest.bind.show.numchars", "20").toInt


    //
    val validAuthCredentials = bindUsers.split(",").toSeq
    val validAuthSecrets = bindSecrets.split(",").toSeq
    val validBasicAuthCredentials = bindUsers.split(",").zipWithIndex.map( u => {
      val secZInd = bindSecrets.split(",").zipWithIndex
      val sec = if (secZInd.isDefinedAt(u._2)) secZInd(u._2)._1 else secZInd(0)._1
      BasicAuthCredentials(u._1, sec)
    })

    //
    val loggedInUsers = mutable.ArrayBuffer.empty[LoggedInUser]

    /**
      * An authenticator function to validate credentials
      * case p @ Credentials.Provided(id)
      * @param credentials if validBasicAuthCredentials.contains(id) && p.verify("Daim0nd") => Future.successful(Some(id))
      * @return
      */
    def authenticatorAsync(credentials: Credentials): Future[Option[String]] = {
      credentials match {
        case p @ Credentials.Provided(id)
          if validBasicAuthCredentials.filter(cred => (id.equals(cred.username) && p.verify(CryptoBuilder.decrypt(cred.password)))).size > 0
          => Future.successful(Some(id))
        case _ => Future.successful(None)
      }
    }


    /**
      * An OAuth2 authenticator Async
      * @param credentials
      * @return
      */
    def oAuth2AsyncAuthenticatorAsync(credentials: Credentials): Future[Option[LoggedInUser]] =
      credentials match {
        case p @ Credentials.Provided(id) =>
          Future.successful(loggedInUsers.find(user => if (p.verify(user.oAuthToken.access_token)) true else false))
        case _ => Future.successful(None)
      }


    /**
      * An OAuth2 authenticator
      * @param credentials
      * @return
      */
    def oAuth2Authenticator(credentials: Credentials): Option[LoggedInUser] =
      credentials match {
        case p @ Credentials.Provided(id) =>
          loggedInUsers.find(user => p.verify(user.oAuthToken.access_token))
        case _ => None
      }


    /**
      * Cleanup Expired Users from LoggedInUsers list
      */
    def cleanUpExpiredUsers(): Unit =
      loggedInUsers
      .filter(user => user.oAuthToken.expires_in > 0 && user.loggedAt.plusSeconds(user.oAuthToken.expires_in).isBefore(LocalDateTime.now()))
      .foreach(loggedInUsers -= _)

    //
    // http routes
    //
    val route: Route = logRequestResult(bindRoutes) {
      //
      post {
        //
        path(bindAuth) {
          //
          authenticateBasicAsync(realm = bindAuth, authenticatorAsync) { userName =>
            //
            rejectEmptyResponse {
              //
              val loggedInUser = LoggedInUser(userName, new OAuthToken(expires_in = if (bindTokExpEnabled) bindTokExpSec else -1))
              loggedInUsers.append(loggedInUser)
              complete(loggedInUser.oAuthToken)
              //
            } // rejectempty

          } // authenticate

        } ~
        //
        path(bindResource) {
          //
          authenticateOAuth2Async(realm = bindRoutes, oAuth2AsyncAuthenticatorAsync) { token =>
            //
            rejectEmptyResponse {
              //
              entity(as[String]) { request =>

                println("Request received from client...")
                logger.debug(request)
                println(request.slice(0,bindShowNumChars))
                val arrs = Array(request)
                val rslt = Pipeline.getRestPipelineResponse(arrs)
                println("Response generated...")
                logger.debug(rslt)
                println(rslt.slice(0,bindShowNumChars))
                println("for Request...")
                println(request.slice(0,bindShowNumChars))
                val saved = Future { Done }
                complete(Future.successful(rslt))

              } // entity

            } // reject

          } // authenticator

        } // path

      } // post

    } // route
    //

    //
    system.scheduler.schedule(5 minutes, 5 minutes)(cleanUpExpiredUsers())(executionConext)

    //
    val bindingFuture = Http().bindAndHandle(route, bindServer, bindPort.toInt)
    if (bindingFuture.value.isDefined) {
      val la = bindingFuture.value.get.get.localAddress
      println("bindhandle details: " + la.getAddress + " - " + la.getHostName + " - " + la.getHostString + " - " + la.getPort)
    }
    println(s"Server RestPipeline online at http://$bindServer:$bindPort/$bindResource .....")
    // StdIn.readLine() // let it run until user presses return
    // bindingFuture
    //    .flatMap(_.unbind()) // trigger unbinding from the port
    //    .onComplete(_ => {
    //      system.terminate()
    //      println("ALL STOPPED")
    //    }) // and shutdown when done

  }


  /**
    * A webservice request to generate response
    * @param args
    */
  def webService(args: Array[String]): Unit = {
    //
    val bindServer = PropsUtil.propValue("spark.rest.bind.server", "0.0.0.0")
    val bindPort = PropsUtil.propValue("spark.rest.bind.port", "8180")
    val bindResource = PropsUtil.propValue("spark.rest.bind.resource", "getRequest")

    //
    val route: Route =
      post {
        path(bindResource) {
          entity(as[String]) { request =>
            println("Request received from client...")
            println(request)
            val arrs = Array(request)
            val rslt = Pipeline.getRestPipelineResponse(arrs)
            println("Response generated...")
            println(rslt)
            println("for Request...")
            println(request)
            val saved = Future { Done }
            onComplete(saved) { dont =>
              complete(rslt)
            }
          }
        }

      }
    //

    //
    val bindingFuture = Http().bindAndHandle(route, bindServer, bindPort.toInt)
    if (bindingFuture.value.isDefined) {
      val la = bindingFuture.value.get.get.localAddress
      println("bindhandle details: " + la.getAddress + " - " + la.getHostName + " - " + la.getHostString + " - " + la.getPort)
    }
    println(s"Server RestPipeline online at http://$bindServer:$bindPort/$bindResource .....")
  }

  /**
    * An entry point to run pipeline of events
    *
    * @param args
    */
  def main(args: Array[String]): Unit = {

    //
    Pipeline.initRestPipeline(args)

    val secured = if (!args.isEmpty && args.length > 0) args(0).toBoolean else false

    // webservice initialization
    if (secured) webServiceSecured(args) else webService(args)

  }


}
