package com.drake.pipeline

import com.drake.model.HBaseUGIModel
import com.drake.model.Model.Audit
import com.drake.notify.NotificationBuilder
import com.drake.offset.OffsetStore
import com.drake.plan.{PlanExecutor, PlanExecutorBuilder, PlanTrigger}
import com.drake.reader.AuditWriter
import com.drake.storage.StorageHelper
import com.drake.{LocalMode, PropsUtil, SessionDataHelper, SparkHelper}
import org.apache.spark.sql.{DataFrame, SaveMode}
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.streaming.StreamingQueryListener.{QueryProgressEvent, QueryStartedEvent, QueryTerminatedEvent}

/**
  * A Pipeline runs actions in the dependency order to read, transform and persist the data
  */
object Pipeline {

  /**
    * An entry point to run pipeline of events
    *
    * @param args
    */
  def main(args: Array[String]): Unit = {

    var notifyBuilder: NotificationBuilder = null

    try {

      //
      PropsUtil.initialize()

      //
      LocalMode.secureLogin()

      //
      notifyBuilder = NotificationBuilder("mail")

      //
      SparkHelper.buildSparkSession()
      SparkHelper.getSparkSession.sparkContext.setLogLevel("INFO")

      //
      StorageHelper.buildSessionStorage(args)

      //
      SparkHelper.getSparkSession().streams.addListener(new DsStreamListener())

      //
      PlanTrigger.triggerPlanExecutor()

    } finally {

      if ("batch".equalsIgnoreCase(PropsUtil.getWorkflow().mode)) {
        println("Stopping Sprk Session........")
        SparkHelper.getSparkSession().stop()
        println("Stopped Sprk Session")
      }
    }

  }

  /**
    * Initialize Executors
    */
  private def executorInitialization(): Unit = {
    //
    val randoms = SparkHelper.getSparkSession().sparkContext.parallelize(1 to 1000, 100)
    randoms.foreach( f => {
      val conn = HBaseUGIModel.connection
      println("Testing HBase Connection Closed state")
      println(conn.isClosed)
    })
  }

  /**
    * An entry point to run pipeline of events
    * @param args
    */
  def runBatchPipeline(args: Array[String]): Unit = {
    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()
    SparkHelper.getSparkSession.sparkContext.setLogLevel("INFO")

    //
    StorageHelper.buildSessionStorage(args)

    //
    PlanExecutorBuilder().buildPlanExecutor()
  }


  /**
    * An entry point to run RT pipeline
    * @param args
    * @param inDataFrames
    * @return
    */
  def runRTPipeline(args: Array[String], inDataFrames: Map[String, DataFrame]): Map[String, DataFrame] = {
    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    inDataFrames.foreach(df => {
      if (SparkHelper.getSparkSession() == null) SparkHelper.buildSparkSession(df._2.sparkSession)
    })

    //
    StorageHelper.buildSessionStorage(args)

    //
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(inDataFrames)

    //
    outDataFrames
  }



  /**
    * An entry point to run RT pipeline
    * @param args
    * @param inDataFrames
    * @return
    */
  def runRTPipeline1(args: Array[String], inDataFrames: Map[String, DataFrame]): Map[String, DataFrame] = {
    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()

    //
    StorageHelper.buildSessionStorage(args)

    //
    val ss = SparkHelper.getSparkSession()
    val beginDF = ss.read.option("path", "input/domain=product").format("text").load()
    println("loading dataframe manually...." + beginDF.count())
    val beginMap: Map[String, DataFrame] = Map("request" -> beginDF)
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(beginMap)
    var outDataFrameVar: DataFrame = null
    outDataFrames.filter(f => f._1.equals("response")).foreach(f => outDataFrameVar = f._2)
    val outputFrame = outDataFrameVar
    outputFrame.write.format("orc").option("path", "output/domain=product").mode(SaveMode.Append).save()

    //
    outDataFrames
  }


  /**
    * An entry point to run RT pipeline
    * @param args
    * @param inDataFrames
    * @return
    */
  def runRTPipeline(args: Array[String]): Unit = {
    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()

    //
    StorageHelper.buildSessionStorage(Array[String]())

    //
    val ss = SparkHelper.getSparkSession()
    val beginDF = ss.read.option("path", "input/domain=product").format("text").load()
    println("loading dataframe manually...." + beginDF.count())
    val beginMap: Map[String, DataFrame] = Map("request" -> beginDF)
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(beginMap)
    var outDataFrameVar: DataFrame = null
    outDataFrames.filter(f => f._1.equals("response")).foreach(f => outDataFrameVar = f._2)
    val outputFrame = outDataFrameVar
    outputFrame.write.format("orc").option("path", "output/domain=product").mode(SaveMode.Append).save()

    //
    outDataFrames
  }


  /**
    * An entry point to run Rest pipeline
    * @param inData
    */
  def runRestPipeline(inData: Map[String, String]): Unit = {

    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()

    //
    StorageHelper.buildSessionStorage(Array[String]())

    val inputString = inData.getOrElse("inputString", "input/domain=product")
    val outputString = inData.getOrElse("outputString", "output/domain=product")

    //
    val ss = SparkHelper.getSparkSession()
    import ss.implicits._

    //
    val beginDF = Seq(inputString).toDF("value")
    println("loading dataframe manually...." + beginDF.count())
    val beginMap: Map[String, DataFrame] = Map("request" -> beginDF)

    //
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(beginMap)

    //
    var outDataFrameVar: DataFrame = null
    outDataFrames.filter(f => f._1.equals("response")).foreach(f => outDataFrameVar = f._2)
    val outputFrame = outDataFrameVar
    outputFrame.write.format("orc").option("path", "output/domain=product").mode(SaveMode.Append).save()

    //
  }



  /**
    * An entry point to run Rest pipeline
    * @param args
    * @return
    */
  def runRestPipeline(args: Array[String]): Unit = {

    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()

    //
    StorageHelper.buildSessionStorage(Array[String]())

    val inputString = if (!args.isEmpty && args.length > 0) args(0) else "input/domain=product"
    val ouputPath = if (!args.isEmpty && args.length > 1) args(1) else "output/domain=product"

    //
    val ss = SparkHelper.getSparkSession()
    import ss.implicits._

    //
    val beginDF = Seq(inputString).toDF("value")
    println("loading dataframe manually...." + beginDF.count())
    val beginMap: Map[String, DataFrame] = Map("request" -> beginDF)

    //
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(beginMap)

    //
    var outDataFrameVar: DataFrame = null
    outDataFrames.filter(f => f._1.equals("response")).foreach(f => outDataFrameVar = f._2)
    val outputFrame = outDataFrameVar
    outputFrame.write.format("orc").option("path", ouputPath).mode(SaveMode.Append).save()

    //
  }



  /**
    * An entry point to run Rest pipeline
    * @param args
    * @return
    */
  def initRestPipeline(args: Array[String]): String = {

    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    PropsUtil.initialize()

    //
    SparkHelper.buildSparkSession()

    //
    StorageHelper.buildSessionStorage(Array[String]())


    //
    val reslt = "number of arguments passed "  + args.length

    //
    reslt
  }



  /**
    * Returns the response for given input rest request
    * @param args
    * @return
    */
  def getRestPipelineResponse(args: Array[String]): String = {

    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()
    var resultVar = ""


    val inputString = if (!args.isEmpty && args.length > 0) args(0) else "input/domain=product"

    //
    val ss = SparkHelper.getSparkSession()
    import ss.implicits._

    //
    val beginDF = Seq(inputString).toDF("value")
    println("loading dataframe manually...." + beginDF.count())
    val beginMap: Map[String, DataFrame] = Map("request" -> beginDF)

    //
    outDataFrames = PlanExecutorBuilder().buildPlanExecutor(beginMap)

    // process output
    outDataFrames.filter(f => f._1.equals("response")).foreach(f => f._2.select("value").take(1).foreach(row => resultVar = row.getString(0).replaceAll("[\\[][{][}][\\]]","[]")))
    val result = resultVar

    //
    result
  }




  /**
    * An implementation of streaming query listener events
    */
  class DsStreamListener extends StreamingQueryListener {

    override def onQueryStarted(event: QueryStartedEvent): Unit = { println("Query Started: " + event.name) }

    override def onQueryProgress(event: QueryProgressEvent): Unit = {
      println("Query in progress")
      //StaticSourceHelper.refreshStaticSources()
      //println(event.progress)
      println("*********************Custom Progress******************")
      println("Sink Path: " + event.progress.sink.description)
      val sOffsets = event.progress.sources.map(_.startOffset).mkString
      val eOffsets = event.progress.sources.map(_.endOffset).mkString
      println("Sink Num of InputRows: " + event.progress.numInputRows)
      println("Sink Input Rows Per Second: " + event.progress.inputRowsPerSecond)
      println("Sink Processed Rows Per Second: " + event.progress.processedRowsPerSecond)
      if (event.progress.numInputRows != 0) {
        val audit = Audit(event.progress.id.toString, event.progress.runId.toString, event.progress.sink.description, event.progress.numInputRows, event.progress.inputRowsPerSecond, event.progress.processedRowsPerSecond, sOffsets, eOffsets)
        AuditWriter("Audit").storeAuditRef(audit)
      }
      event.progress.sources.foreach(x => {
        OffsetStore.getOffsetStore.saveOffsets((if(x.startOffset eq null) x.endOffset else x.startOffset), PropsUtil.propValue("kafka.group-id"))
      })
      println("*********************Custom Progress******************")
    }

    override def onQueryTerminated(event: QueryTerminatedEvent): Unit = { println("Query Terminated: " + event.runId) }
  }

}
