package com.drake.pipeline

import com.drake.plan.PlanExecutorBuilder
import com.drake.{BaseTrait, PropsUtil, SessionDataHelper, SparkHelper}
import org.apache.spark.sql.DataFrame

/**
  * A pipeline runs in real-time mode which reads dataset and returns another dataset
  */
object RTPipeline extends BaseTrait {

  /**
    * An entry point to run pipeline of events
    *
    * @param args
    * @param inDataFrames
    * @return
    */
  def runRTPipeline(args: Array[String], inDataFrames: Map[String, DataFrame]): Map[String, DataFrame] = {

    //
    var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    //
    outDataFrames = Pipeline.runRTPipeline(args, inDataFrames)

    //
    outDataFrames
  }


  /**
    * An entry point
    * @param args
    */
  def main(args: Array[String]): Unit = {
    Pipeline.runRTPipeline(args)
  }


}
