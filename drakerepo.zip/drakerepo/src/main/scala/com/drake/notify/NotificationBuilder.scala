package com.drake.notify

import com.drake.{BaseTrait, PropsUtil}
import javax.mail._
import javax.mail.internet.{InternetAddress, MimeMessage}


/**
  * A class to notify the host members on status/failure/successful states
  */
object NotificationBuilder extends BaseTrait {


  /**
    * Mail specific NotificationBuilder
    * @param str
    */
  class MailNotificationBuilder(handlername: String) extends NotificationBuilder {

    name = handlername
    var session: Session = _

    /**
      * Initializes Notification process
      */
    override def initialize(): Unit = {
      val properties = System.getProperties
      properties.put("mail.smtp.host", PropsUtil.propValue("smtp.host"))
      properties.put("mail.smtp.port", PropsUtil.propValue("smtp.port"))
      session = Session.getDefaultInstance(properties)
    }

    /**
      * Notified receivers a Message with subject and body
      *
      * @param sub
      * @param body
      */
    override def notifyMessage(sub: String, body: String): Unit = {
      val message = new MimeMessage(session)

      // set from to sub body
      message.setFrom(new InternetAddress(PropsUtil.propValue("smtp.from")))
      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(PropsUtil.propValue("smtp.to")).asInstanceOf[Array[Address]])
      message.setSubject(sub)
      message.setText(body)

      // then send it
      Transport.send(message)
    }
  }


  /**
    * preferred factory method
    * @param s
    * @return
    */
  def apply(s: String): NotificationBuilder = {
    getNotificationBuilder(s)
  }


  /**
    * an alternative factory method (use one or the other)
    * @param s
    * @return
    */
  def getNotificationBuilder(s: String): NotificationBuilder = {
    val builder = new MailNotificationBuilder(s)
    builder.initialize()
    builder
  }

}


/**
  * A Builder interface to notify the host members on status/failure/successful states
  */
trait NotificationBuilder extends BaseTrait {

  var name: String = _


  /**
    * Initializes Notification process
    */
  def initialize(): Unit


  /**
    * Notified receivers a Message with subject and body
    * @param sub
    * @param body
    */
  def notifyMessage(sub: String, body: String): Unit

}
