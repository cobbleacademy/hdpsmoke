package com.drake.function

import java.util.UUID

import com.drake.BaseTrait
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.udf
import org.json4s.JsonDSL._
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.Xml._


import scala.xml._


/**
  * A common functions needed for processing data
  */
object Func extends BaseTrait {

  implicit val formats = DefaultFormats

  /**
    * Define scala function for uuid
    */
  val uuidfunc = () => UUID.randomUUID().toString

  /**
    * Define scala function
    */
  val xmltojsonfunc: (String, Map[String, String]) => String = (input: String, startAttrs: Map[String, String]) => {

    // get config attributes
    val removeProlog = startAttrs.getOrElse("xmlRemoveProlog", "false").toBoolean
    val removeNamespaces = startAttrs.getOrElse("xmlRemoveNamespaces", "").split(",")
    val adjustNamespaces = startAttrs.getOrElse("xmlAdjustNamespaces", "").split(",")
    val elemsToArray = startAttrs.getOrElse("xmlArrayTransformTags", "").split(",")
    val applyCamelizedKeys = startAttrs.getOrElse("xmlApplyCamelizedKeys", "false").toBoolean


    /**
      * Identify XML Elements to remove
      *
      * @param element
      * @param beginTag
      * @param startElem
      * @param endElem
      * @param begInd
      * @param endInd
      * @return
      */
    def recursiveElement(element: String, beginTag: Boolean = false, startElem: String = "<?", endElem: String = "?>", begInd: Int = -1, endInd: Int = -1): String = {
      //
      var ind = element.indexOf(if (beginTag) startElem else endElem, begInd)

      //
      if (ind != -1)
        if (beginTag)
          recursiveElement(element, false, startElem, endElem, ind)
        else
          element.substring(ind+endElem.length).trim
      else
        element.trim
    }

    // remove comments
    var remCommInputVar = input.trim
    var recComInd = remCommInputVar.indexOf("<!--")
    while (recComInd != -1) {
      remCommInputVar = recursiveElement(remCommInputVar, true, "<!--", "-->")
      recComInd = remCommInputVar.indexOf("<!--")
    }
    val remCommInput = remCommInputVar
    logger.debug("remCommInput: " + remCommInput)

    // remove comments
    val remProInput = if (removeProlog) recursiveElement(remCommInput, true) else remCommInput
    logger.debug("remProInput: " + remProInput)

    // remove namespaces
    val remInput = removeNamespaces.foldLeft(remProInput) {(acc, ns) => (acc.replaceAll(ns+":","")) }
    logger.debug("remInput: " + remInput)

    // adjust namespaces (keeps namespace but removes colon)
    val adjInput = adjustNamespaces.foldLeft(remInput) {(acc, ns) => (acc.replaceAll(ns+":", ns)) }
    logger.debug("adjInput: " + adjInput)


    /**
      * Scan thru the inut for array able elements to provide array flavor
      *
      * @param mainInput
      * @param elem
      * @return
      */
    def enhanceToArrayTags(mainInput: String, elem: String): String = {

      //
      val (tagChar, runCheck) =
        if (mainInput.indexOf("<"+elem+">") != -1 || mainInput.indexOf("<"+elem+" ") != -1)
          if (mainInput.indexOf("<"+elem+">") != -1)
            (">", true)
          else
            (" ", true)
        else
          (">", false)

      //
      val beginTag = "<"+elem+tagChar
      logger.debug("beginTag: " + beginTag)


      def recursiveArrayTags(element: String, word: String, wordTag: String, elemCount: Int = 0, mainBegin: Int = -1, mainEnd: Int = -1, chunkBegin: Int = -1, chunkEnd: Int = -1): String = {
        //
        val dfltElem = if (elemCount == 1) "<" + word + "></" + word + ">" else ""

        //
        val lastli = element.indexOf("</" + word + ">", chunkBegin)
        val lastbi = element.indexOf(wordTag, lastli)
        val isFilledWithEmpty =
          if (lastbi != -1 && element.substring((lastli + word.length + 3), lastbi).trim.length == 0)
            true
          else
            false
        logger.debug("next close index: " + lastli + " next begin index: " + lastbi + " is Empty: " + isFilledWithEmpty)

        //
        val retElement =
          if ( (lastbi == -1) || ((lastbi > (lastli + word.length + 3)) && !isFilledWithEmpty) ) {

            //
            val chunkElement = element.substring(0, mainBegin) +
              "<" + word + "Array>" +
              element.substring(mainBegin, lastli + word.length + 3) +
              dfltElem +
              "</" + word + "Array>" +
              element.substring(lastli + word.length + 3, element.length)
            logger.debug("chunk element: " + chunkElement)

            //
            val mainli = lastli + (2*word.length) + (2*"Array".length) + (2*2) + 1 + dfltElem.length
            val mainbi = chunkElement.indexOf(wordTag, mainli)

            //
            if (mainbi != -1)
              recursiveArrayTags(chunkElement, word, wordTag, 1, mainbi, mainli, mainbi, lastli)
            else
              chunkElement


          } else {

            //
            recursiveArrayTags(element, word, wordTag, (elemCount+1), mainBegin, mainEnd, lastbi, lastli)
          }

        //
        retElement
      }



      // call inner func
      val retMainElem =
        if (runCheck) {
          //
          val mainbi = mainInput.indexOf(beginTag, -1)
          logger.debug("main begin index: " + mainbi)
          recursiveArrayTags(mainInput, elem, beginTag, 1, mainbi, -1, mainbi, -1)

        } else {
          //
          mainInput
        }

      //
      retMainElem
    }

    //
    val jsonStr =
      if (adjInput.length > 0) {
        //
        val replArrayInput = elemsToArray.foldLeft(adjInput) { (acc, s) =>
          enhanceToArrayTags(acc, s)
        }

        //
        val jsonRaw = toJson(XML.loadString("<tojson>"+ replArrayInput +"</tojson>").child)
        val json = if (applyCamelizedKeys) jsonRaw.camelizeKeys else jsonRaw

        //
        val jsonCompStr = compact(render(json))

        //
        jsonCompStr

      } else {
        ""
      }

    //
    jsonStr
  }


  /**
    * Define scala function
    */
  val jsonxmlfunc: String => String = (input: String) => toXml(parse(input)).toString()

  /**
    * Define scala function
    */
  val liststringfunc: (Seq[String], String) => String = (input: Seq[String], sep: String) => input.mkString(sep)



  /**
    * Generates glbal UUID
    */
  val uuid = udf(uuidfunc)


  /**
    * Defines spark udf from scala function
    */
  def xmltojson(startAttrs: Map[String, String]) = udf((s: String) => xmltojsonfunc(s, startAttrs))


  /**
    * Defines spark udf from scala function
    */
  val jsonxml = udf(jsonxmlfunc)

  /**
    * Defines spark udf from scala function
    */
  val liststring = udf(liststringfunc)



  /**
    * Genertes Global UUID
    * @param dataframe
    * @return
    */
  def registerUUID(dataframe: DataFrame) = {
    dataframe.sparkSession.udf.register("uuid", uuidfunc)
  }

  /**
    * Genertes XML to JSON
    * @param dataframe
    * @return
    */
  def registerXmlToJson(dataframe: DataFrame) = {
    dataframe.sparkSession.udf.register("xmltojson", xmltojsonfunc)
  }

  /**
    * Genertes XML via JSON from json string
    * @param dataframe
    * @return
    */
  def registerJsonXml(dataframe: DataFrame) = {
    dataframe.sparkSession.udf.register("jsonxml", jsonxmlfunc)
  }

  /**
    * Genertes String from collect_list
    * @param dataframe
    * @return
    */
  def registerListString(dataframe: DataFrame) = {
    dataframe.sparkSession.udf.register("liststring", liststringfunc)
  }


  /**
    * Registers all functions
    * @param dataframe
    * @return
    */
  def registerFunctions(dataframe: DataFrame) = {
    registerUUID(dataframe: DataFrame)
    registerXmlToJson(dataframe: DataFrame)
    registerJsonXml(dataframe: DataFrame)
    registerListString(dataframe: DataFrame)

  }

}
