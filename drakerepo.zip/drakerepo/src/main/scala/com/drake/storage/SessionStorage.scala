package com.drake.storage

import java.time.{Instant, LocalDate, LocalTime}

import com.drake.model.Model.CachedDataFrame
import com.drake.status.StatusBuilderHelper
import com.drake.{BaseTrait, PropsUtil}
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.{DataFrame, ForeachWriter, Row}

import scala.collection.mutable

object SessionStorage extends BaseTrait {

  // constants
  private var sessionData: mutable.Map[String, mutable.Map[String, String]] = _
  private var sessionCache: mutable.Map[String, DataFrame] = _
  private var frequencyCache: mutable.Map[String, CachedDataFrame] = _
  private var aliasDataFrames: mutable.Map[String, DataFrame] = _


  /**
    * Builds session scoped dataframes and data cache
    * @param args
    */
  def buildSessionStorage(args: Array[String]): Unit = {
    //
    sessionData = mutable.Map[String, mutable.Map[String, String]]()

    //
    // Add arguments as default step
    //
    val stepMap: mutable.Map[String, String] = mutable.Map[String, String]()
    for((x,i) <- args.view.zipWithIndex) stepMap += (i.toString -> x)
    sessionData += ("args" -> stepMap)

    //
    // Add sys values as default step
    //
    val procConstMap: mutable.Map[String, String] = mutable.Map(
      "processEpochMs" -> Instant.now.toEpochMilli.toString,
      "processEpochSec" -> Instant.now.getEpochSecond.toString,
      "processDt" -> LocalDate.now.toString,
      "processHr" -> LocalTime.now.getHour.toString
    )
    sessionData += ("sys" -> procConstMap)

    //
    // add props as map
    //
    sessionData += ("props" -> PropsUtil.getPropertiesAsMap)
    //
    print(sessionData)

    //
    sessionCache = mutable.Map[String, DataFrame]()
    frequencyCache = mutable.Map[String, CachedDataFrame]()
    aliasDataFrames = mutable.Map[String, DataFrame]()

  }


  /**
    * Appends map to existing session data
    * @param parent
    * @param map
    */
  def mutateSessionStorage(parent: String, map: mutable.Map[String, String]): Unit = {
    //
    val currMap = sessionData.getOrElse(parent, mutable.Map[String, String]())
    currMap ++= map
  }


  /**
    * Returns sessiondata across packages
    * @param args
    */
  def refreshSessionData(args: Array[String]): Unit = {
    //
    // add sys values as default step
    //
    val procConstMap: mutable.Map[String, String] = mutable.Map(
      "processEpochMs" -> Instant.now.toEpochMilli.toString,
      "processEpochSec" -> Instant.now.getEpochSecond.toString,
      "processDt" -> LocalDate.now.toString,
      "processHr" -> LocalTime.now.getHour.toString
    )
    sessionData += ("sys" -> procConstMap)

    //
    print(sessionData)
  }


  /**
    * Returns SessionData across packages
    * @param name
    * @param dataFrame
    */
  def addStepSessionData(name: String, dataFrame: DataFrame): Unit = {
    //
    var sessMap = mutable.Map[String, String]()

    //
    if(dataFrame.isStreaming) {
      //
      val ss = dataFrame.sparkSession

      val accunulator = ss.sparkContext.collectionAccumulator[(String, String)]
      val query:StreamingQuery = dataFrame.writeStream
        .foreach(new ForeachWriter[Row] {
          override def open(partitionId: Long, version: Long): Boolean = true

          override def process(row: Row): Unit = {
            println(s">> Process ${row}")
            accunulator.add((row.getString(0), row.getString(1)))
          }

          override def close(errorOrNull: Throwable): Unit = {

          }
        })
        .outputMode("append")
        .start()

      import scala.collection.JavaConverters._
      val accList = accunulator.value.asScala

      accList.foreach(t => {
        sessMap += (t._1 -> t._2)
      })

    } else {
      //
      // add step session values as default step
      //
      val sessImmMap = dataFrame.rdd.collect().map(row => (row.getString(0) -> row.getString(1)))
      val sessImmMapMulti = sessImmMap.groupBy(_._1).map { case (k,v) => (k,v.map(_._2).mkString(","))}
      val sessMap = collection.mutable.Map(sessImmMapMulti.toSeq: _*)
    }

    //
    val sessAllMap: mutable.Map[String, String] = sessionData.getOrElse(name, mutable.Map[String, String]()) ++ sessMap

    //
    sessionData += (name -> sessAllMap)

    //
    println("printing SessionData: " + sessionData)

  }


  /**
    * Returns sessionData object
    * @return
    */
  def getSessionData(): mutable.Map[String, mutable.Map[String, String]] = {
    sessionData
  }


  /**
    * adds dataframe to cache for given label
    * @param name
    * @param label
    * @param dataFrame
    */
  def addCache(name: String, label: String, dataFrame: DataFrame): Unit = {
    logger.info("cache invoked on label: " + label + " for step: " + name)
    val cachedCount = dataFrame.count()
    StatusBuilderHelper.addStatusComment(s"$label $cachedCount")
    println(s"cached on label: $label for step: $name with count: $cachedCount")
    sessionCache += (label -> dataFrame)
  }


  /**
    * Removes cache from session with given label
    * @param label
    */
  def removeCache(label: String): Unit = {
    logger.info("removing cache on label: "+ label)
    sessionCache.get(label).map(df => df.unpersist())
  }


  /**
    * Adds dataframe to cache for given label with frequency to destroy
    * @param name
    * @param label
    * @param dataFrame
    * @param freq
    */
  def addFrequencyCache(name: String, label: String, dataFrame: DataFrame, freq: Long): Unit = {
    //
    var cachedAtVar = Instant.now.getEpochSecond
    logger.info("cache invoked on label: " + label + " for step: " + name + " with frequency in seconds: " + freq)
    println("cache invoked on label: " + label + " for step: " + name + " with frequency in seconds: " + freq)
    frequencyCache.get(label).foreach(cdf => cachedAtVar = cdf.cachedAt)
    frequencyCache -= label
    val cachedAt = cachedAtVar
    val cdf = CachedDataFrame(label, dataFrame, freq, cachedAt)
    frequencyCache += (label -> cdf)
  }


  /**
    * Removes cached from spark for given label
    */
  def refreshFrequencyCache(): Unit = {
    logger.info("removing cache dataframes")
    frequencyCache.foreach(freq => {
      val cdf = freq._2
      if ((Instant.now.getEpochSecond - cdf.cachedAt) > cdf.freq) cdf.dataFrame.unpersist()
    })
  }


  /**
    * Adds Dataframe to alias enabled map
    * @param label
    * @param dataFrame
    */
  def addAliasEnabledDataFrame(label: String, dataFrame: DataFrame): Unit = {
    //
    aliasDataFrames += (label -> dataFrame)
    logger.info(s"printed adding alias dataframe for label: $label defined: $dataFrame")
  }


  /**
    * Returns the spark session cache details
    * @return
    */
  def getSessionCache(): mutable.Map[String, DataFrame] = {
    sessionCache
  }


  /**
    * Returns alias dataframes
    * @return
    */
  def getAliasDataFrames(): mutable.Map[String, DataFrame] = {
    aliasDataFrames
  }

}
