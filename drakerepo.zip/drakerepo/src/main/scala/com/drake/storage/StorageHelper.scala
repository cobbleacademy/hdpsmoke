package com.drake.storage

import com.drake.BaseTrait
import com.drake.model.Model.PlanCache
import org.apache.spark.sql.DataFrame

import scala.collection.mutable


/**
  * A Storage Helper class to determine the objects to save either into plan or session scope
  */
object StorageHelper extends BaseTrait {


  /**
    * Builds session scoped dataframe and data cache for sparksession
    * @param args
    */
  def buildSessionStorage(args: Array[String]): Unit = {
    //
    SessionStorage.buildSessionStorage(args)
  }


  /**
    * Builds plan scoped dataframe and data cache for sparksession
    * @param args
    * @return
    */
  def buildPlanStorage(args: Array[String]): PlanCache = {
    //
    PlanStorage.buildPlanStorage(args)
  }


  /**
    * Returns value for the given key with parentage step
    * @param parentageKey
    * @param data
    * @return
    */
  def parentageLookupWithSessionData(parentageKey: String, data: mutable.Map[String, mutable.Map[String, String]]): String = {
    //
    var value = parentageKey

    //
    def inLookup(inParentageKey: String, inData: mutable.Map[String, mutable.Map[String, String]]): String = {
      //
      var inValue = inParentageKey

      //
      logger.debug(s"key: $inParentageKey")
      val arr = inParentageKey.substring(1).split("#")
      val stepMap: mutable.Map[String, String] = inData.getOrElse(arr(0).toString, mutable.Map[String, String]())
      inValue = stepMap.getOrElse(arr(1), "")

      //
      inValue
    }

    //
    if (parentageKey.startsWith("$")) {
      value = inLookup(parentageKey, data)
      if (value.isEmpty) value = inLookup(parentageKey, SessionStorage.getSessionData())
      println(s"Key Replacement for key: $parentageKey value: $value")
    }

    //
    value
  }

  /**
    * Returns value for the given key with parentage step
    * @param parentageKey
    * @param data
    * @return
    */
  def parentageLookup(parentageKey: String, data: mutable.Map[String, mutable.Map[String, String]]): String = {
    //
    parentageLookupWithSessionData(parentageKey, data)
  }


  /**
    * find map values with dynamic variables and replace with real values
    * @param inMap
    * @param data
    * @return
    */
  def mapValuesTransform(inMap: Map[String, String], data: mutable.Map[String, mutable.Map[String, String]]): Map[String, String] = {
    //
    val outMap: mutable.Map[String, String] = mutable.Map[String, String]()

    //
    // replace value dynamic variable with values
    //
    logger.debug("Attributes Replacement")
    inMap.map(x => {
      val key = x._1
      var value = x._2
      value = parentageLookup(value, data)
      logger.debug(key + " -> " + value)
      outMap += (key -> value)
    })

    //
    outMap.toMap
  }


    /**
    * Returns value for the give key either from plan or session
    *
    * @param stepName
    * @param dataKey
    * @param defaultValue
    * @param data
    * @return
    */
  def getDataMapValue(stepName: String, dataKey: String, defaultValue: String, data: mutable.Map[String, mutable.Map[String, String]]): String = {
    //
    var resVal = defaultValue

    //
    def recursiveValue(inStepName: String, inDataKey: String, inData: mutable.Map[String, mutable.Map[String, String]]): Option[String] = {
      inData.getOrElse(inStepName, mutable.Map[String, String]()).get(inDataKey)
    }

    //
    val planBasedVal = recursiveValue(stepName, dataKey, data)
    resVal = planBasedVal.getOrElse({
      val sessBasedVal = recursiveValue(stepName, dataKey, SessionStorage.getSessionData())
      sessBasedVal.getOrElse(defaultValue)
    })

    //
    resVal
  }



  /**
    * Returns dataframe for given label
    * @param label
    * @param aliasDataFrames
    * @return
    */
  def getAliasDataFrame(label: String, aliasDataFrames: mutable.Map[String, DataFrame]): Option[DataFrame] = {
    //
    var replacedDf: Option[DataFrame] = None
    replacedDf = if(aliasDataFrames.get(label).isDefined) aliasDataFrames.get(label) else SessionStorage.getAliasDataFrames().get(label)
    logger.info(s"printed finding the dataframe for lable: $label defined: ${replacedDf.isDefined}")
    //
    replacedDf
  }


  /**
    * Appends map to existing session data
    * @param parent
    * @param map
    */
  def mutateSessionStorage(parent: String, map: mutable.Map[String, String]): Unit = {
    SessionStorage.mutateSessionStorage(parent, map)
  }


  /**
    * Refresh SessionStorage sessiondata
    * @param args
    */
  def refreshSessionData(args: Array[String]): Unit = {
    SessionStorage.refreshSessionData(args)
  }


  /**
    * Refresh SessionStorage frequencycache
    */
  def refreshFrequencyCache(): Unit = {
    SessionStorage.refreshFrequencyCache()
  }


  /**
    * Returns SessionStorage sessionData
    *
    * @return
    */
  def getSessionData(): mutable.Map[String, mutable.Map[String, String]] = {
    SessionStorage.getSessionData()
  }

  /**
    * Refresh SessionStorage frequencycache
    */
  def clearPlanCache(planCache: PlanCache): Unit = {
    PlanStorage.clearPlanCache(planCache)
  }



}
