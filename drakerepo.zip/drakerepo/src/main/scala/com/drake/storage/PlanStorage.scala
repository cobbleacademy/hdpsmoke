package com.drake.storage

import java.time.{Instant, LocalDate, LocalTime}

import com.drake.BaseTrait
import com.drake.model.Model.PlanCache
import org.apache.spark.sql.DataFrame

import scala.collection.mutable
import scala.collection.mutable.ListBuffer


/**
  * A plan scoped storage to manage dataframes and cache during execution
  */
object PlanStorage extends BaseTrait {


  /**
    * Builds plan scoped objects in cache
    *
    * @param args
    * @return
    */
  def buildPlanStorage(args: Array[String]): PlanCache = {
    //
    val cachedDataFrames = ListBuffer[DataFrame]()
    val referncedDataFrames = mutable.Map[String, DataFrame]()


    //
    // add plan values as default step
    //
    val planData = mutable.Map[String, mutable.Map[String, String]]()
    val procConstMap: mutable.Map[String, String] = mutable.Map(
      "processEpochMs" -> Instant.now.toEpochMilli.toString,
      "processEpochSec" -> Instant.now.getEpochSecond.toString,
      "processDt" -> LocalDate.now.toString,
      "processHr" -> LocalTime.now.getHour.toString
    )
    planData += ("plan" -> procConstMap)
    println(planData)

    //
    val planCache = new PlanCache(planData, cachedDataFrames, referncedDataFrames)

    //
    planCache
  }


  /**
    * Returns PlanCache within Plan Data
    * @param name
    * @param dataFrame
    * @param planCache
    */
  def addStepPlanData(name: String, dataFrame: DataFrame, planCache: PlanCache): Unit = {
    //
    // add step session values as default step
    //
    val sessImmMap = dataFrame.rdd.collect().map(row => (row.getString(0) -> row.getString(1)))
    val sessImmMapMulti = sessImmMap.groupBy(_._1).map { case (k,v) => (k,v.map(_._2).mkString(","))}
    val sessMap = collection.mutable.Map(sessImmMapMulti.toSeq: _*)

    planCache.planData += (name -> sessMap)
  }



  /**
    * Returns PlanCache within Plan Data
    * @param name
    * @param dataFrame
    * @param planCache
    */
  def addStepPlanCache(name: String, dataFrame: DataFrame, planCache: PlanCache): Unit = {
    //
    planCache.cachedDataFrames += dataFrame
  }



  /**
    * Returns PlanCache within Plan Data
    * @param label
    * @param dataFrame
    * @param planCache
    */
  def addAliasEnabledDataFrame(label: String, dataFrame: DataFrame, planCache: PlanCache): Unit = {
    //
    planCache.aliasDataFrames += (label -> dataFrame)
    logger.info(s"printed adding alias dataframe for label: $label defined: $dataFrame")
  }


  /**
    * Clears cached from Plan scoped execution
    * @param planCache
    */
  def clearPlanCache(planCache: PlanCache): Unit = {
    //
    planCache.cachedDataFrames.foreach(df => df.unpersist())
    //
    planCache.aliasDataFrames.clear()
  }


}
