package com.drake

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.concurrent.TimeUnit

import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.json4s._
import org.json4s.jackson.JsonMethods._
import org.json4s.Xml._

import scala.collection.mutable.ListBuffer
import scala.xml._


/**
  * Created FileStream
  */
object FileStreamExample {

  implicit val formats = DefaultFormats

  def transfile(args: Array[String]): Unit = {

    val sparkSession = SparkSession.builder
      .master("local")
      .appName("example")
      .getOrCreate()

    val schema = StructType(
      Array(StructField("transactionId", StringType),
            StructField("customerId", StringType),
            StructField("itemId", StringType),
            StructField("amountPaid", StringType)))

    //create stream from folder
    val fileStreamDf1 = sparkSession.read//Stream
      .option("header", "true")
      .schema(schema)
      .csv("input/sales")

    //println("count:" + fileStreamDf1.rdd.count())
    //fileStreamDf1.inputFiles.map(x => println("out:"+x))

    val cnt = fileStreamDf1.rdd.count()
    val fnames = fileStreamDf1.inputFiles.map(_.split("/").last).mkString("|")
    val now = Calendar.getInstance().getTime()
    val nowFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val nowStr = nowFormat.format(now)

    //println("file:///Users/nnagaraju/IDEAWorkspace/drake/input/sales01.csv".split("/").last)

    import sparkSession.implicits._
    val statusDf = Seq(
      (fnames,"2018-12-22","00",cnt,"sales")
    ).toDF("file_name","file_dt","file_hr","count","src_system")
        .withColumn("start_time", lit(current_timestamp()))
      .withColumn("end_time", lit(""))
        .select("file_name","file_dt","file_hr","count","start_time","end_time","src_system")

    statusDf.show(false)

    statusDf
      .write
      .format("csv")
      .partitionBy("src_system")
      .mode(SaveMode.Append)
      .option("codec","org.apache.hadoop.io.compress.GzipCodec")
      .save("output/status")


    //println("stats:" + fnames+","+cnt+","+nowStr)




//    val query = fileStreamDf.writeStream
//      .format("console")
//      .outputMode(OutputMode.Append()).start()
//
//      query.awaitTermination()

  }
  def wholeTextFiles(args: Array[String]): Unit = {
    val sparkSession = SparkSession.builder
      .master("local")
      .appName("example")
      .getOrCreate()

    //create stream from folder
    val statusDf = sparkSession.read//Stream
      .text("input/multiple")
    val statusRDDRaw = sparkSession.sparkContext.wholeTextFiles("input/multiple")

    val statusRDD = statusRDDRaw.flatMap(item => {
      val key = item._1
      val keyvalue = item._2

      //.substring(item._2.indexOf("<catalog>"))
      println("my key:" + key)
      //println("my value:" + keyvalue)
      //val jsonStr = compact(render(toJson(XML.loadString("<tojson>"+keyvalue+"</tojson>").child)))
      //println(jsonStr)
      //jsonStr

      val lookupElement = "catalog"
      val beginTag = "<" + lookupElement
      val endTag = "</"+lookupElement+">"
      var elemArray = ListBuffer[String]();

      var ctgInd = -1
      ctgInd = keyvalue.indexOf(beginTag, ctgInd)
      while (ctgInd != -1) {
        val toCtgInd = keyvalue.indexOf(endTag, ctgInd) + endTag.length
        val currElemData = keyvalue.substring(ctgInd, toCtgInd)
        val jsonStr = compact(render(toJson(XML.loadString("<tojson>"+currElemData+"</tojson>").child)))
        //println(jsonStr)
        val myjson = toJson(XML.loadString("<tojson>"+currElemData+"</tojson>").child)
        println(toXml(myjson))
        elemArray += jsonStr
        ctgInd = keyvalue.indexOf(beginTag, toCtgInd)
      }
      println("Divided into multiple strings: " + elemArray.length)

      elemArray.toArray[String]
    })


    val statusRDD1 = statusRDDRaw

    statusRDD.foreach(println)

    //val statusRDD = statusRDDRaw

    statusRDD.saveAsTextFile("output/multiplerdd")

//    statusDf.printSchema()
//    statusDf.show(10)
//
//    statusDf
//      .write
//      .format("csv")
//      .mode(SaveMode.Append)
//      .save("output/multiple")
  }


  def main_xml_complex(args: Array[String]): Unit = {

  }

  def main(args: Array[String]): Unit = {
    transfile(args)
    //wholeTextFiles(args)
    //main_xml_complex(args)
  }

}
