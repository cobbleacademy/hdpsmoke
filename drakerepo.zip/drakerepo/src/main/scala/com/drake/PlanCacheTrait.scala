package com.drake

import com.drake.model.Model.PlanCache

/**
  * A trait with plan scope
  */
trait PlanCacheTrait extends Serializable {
  var planCache: PlanCache = _

  /**
    * Returns PlanCache with PlanScope
    * @return
    */
  def getPlanCache(): PlanCache = {
    planCache
  }

}
