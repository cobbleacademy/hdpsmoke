package com.drake.work

import org.apache.hadoop.io.{BytesWritable, LongWritable, Text}
import org.apache.hadoop.mapreduce.{InputSplit, RecordReader, TaskAttemptContext}
import org.apache.hadoop.mapreduce.lib.input.{FileInputFormat, FixedLengthInputFormat}


/**
  * A Charset Inputformat class to read as inputformat
  */
class CharsetInputFormat extends FileInputFormat[LongWritable, Text] {

  /**
    * Creates new RecordReader for given Charset
    * @param split
    * @param context
    * @return
    */
  override def createRecordReader(split: InputSplit, context: TaskAttemptContext): RecordReader[LongWritable, Text] = {
    //new CharsetReader()
    null
  }

}
