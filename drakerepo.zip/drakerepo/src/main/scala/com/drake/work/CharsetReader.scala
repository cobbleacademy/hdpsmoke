package com.drake.work

import java.io.IOException

import org.apache.hadoop.io.{BytesWritable, LongWritable, Text}
import org.apache.hadoop.mapreduce.{InputSplit, RecordReader, TaskAttemptContext}
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader

/**
  * A Charset Record Reader to read split and creates a line of data
  */
class CharsetReader() extends RecordReader[LongWritable, Text] {

  var start, end, position = 0L
  var lineRecordReader: LineRecordReader = null
  var key = new LongWritable
  var value = new Text


  @Override
  def initialize(inputSplit: InputSplit, context: TaskAttemptContext): Unit = {
    lineRecordReader = new LineRecordReader()
    lineRecordReader.initialize(inputSplit, context)
  }

  // It’s the method that will be used to transform the line into key value
  @Override
  def nextKeyValue: Boolean = {
    if (!lineRecordReader.nextKeyValue) return false
    key = lineRecordReader.getCurrentKey
    value = lineRecordReader.getCurrentValue
    true
  }

  @throws[IOException]
  @throws[InterruptedException]
  def getCurrentKey: LongWritable = key

  @throws[IOException]
  @throws[InterruptedException]
  def getCurrentValue: Text = value

  @throws[IOException]
  @throws[InterruptedException]
  def getProgress: Float = lineRecordReader.getProgress

  @throws[IOException]
  def close(): Unit = {
    lineRecordReader.close
  }
}
