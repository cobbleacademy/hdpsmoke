package com.drake

import java.io.IOException
import java.text.MessageFormat
import java.util

import org.junit.Assert._
import org.junit.Test
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory
import com.networknt.schema._
import scala.collection.mutable.ArrayBuffer

import collection.JavaConverters._

object CustomMetaMapper {

  class EnumNamesKeyword(keyword: String) extends AbstractKeyword(keyword) {

    //
    //
    //
    class Validator(inKeyword: String, inEnumValues: Array[String], inEnumNames: Array[String]) extends AbstractJsonValidator(inKeyword) {

      val keyword = inKeyword
      val enumValues: Array[String] = inEnumValues
      val enumNames: Array[String] = inEnumNames
      //if (enumNames.size != enumValues.size) throw new IllegalArgumentException("enum " + enumValues.size + " and enumNames " + enumNames.size + " need to be of same length")

      override def validate(node: JsonNode, root: JsonNode, at: String): util.Set[ValidationMessage] = {
        //
        println("*********class level**********")
        println("enumValues:" + enumValues.mkString("|"))
        println("enumNames:" + enumNames.mkString("|"))

        println("*********validate**********")
        println("node:" + node.asText)
        println("root:" + root.asText)
        println("at:" + at)
        val value = node.asText()
        val idx = enumValues.indexOf(value)
        if (idx < 0) throw new IllegalArgumentException("value not found in enum. value: " + value + " enum: " + enumValues.mkString(","))
        val valueName = enumNames(idx)
        fail(CustomErrorMessageType.of("tests.example.enumNames", new MessageFormat("{0}: enumName is {1}")), at, valueName)
      }

    }
    //  END OF Validator

    //
    //
    //
    //
    def readStringList(node: JsonNode): Array[String] = {
      val result = ArrayBuffer[String]()

      if (!node.isArray()) throw new JsonSchemaException("Keyword enum needs to receive an array")

      node.elements().asScala.foreach(child => result += child.asText())

      result.toArray[String]
    }

    //
    override def newValidator(schemaPath: String, schemaNode: JsonNode, parentSchema: JsonSchema, validationContext: ValidationContext): JsonValidator = {

      println("*********newValidator**********")
      println("schemaPath:" + schemaPath)
      println("schemaNode:" + schemaNode.isArray)
      println("parentSchema:" + parentSchema.toString)
      //You can access the schema node here to read data from your keyword
      if (!schemaNode.isArray()) throw new JsonSchemaException("Keyword enumNames needs to receive an array")

      val parentSchemaNode = parentSchema.getSchemaNode()

      if (!parentSchemaNode.has("enum")) throw new JsonSchemaException("Keyword enumNames needs to have a sibling enum keyword")

      val enumSchemaNode = parentSchemaNode.get("enum")
      println("siblingNode:" + enumSchemaNode.toString + " Array:? " + enumSchemaNode.isArray)

      new Validator(getValue(), readStringList(enumSchemaNode), readStringList(schemaNode))
    }

  }



  def main(args: Array[String]): Unit = {
    //
    println("BEGIN: CustomMetaMapper")

    val objectMapper = new ObjectMapper()

    println("*********step1**********")
    val defSchUri = "https://github.com/networknt/json-schema-validator/tests/schemas/example01#"
    val defAltSchUri = "https://github.com/drake/schemas/member#"

    val metaSchema = JsonMetaSchema
      .builder(defAltSchUri, JsonMetaSchema.getV4())
      // Generated UI uses enumNames to render Labels for enum values
      .addKeyword(new EnumNamesKeyword("enumNames"))
      .build()

    println("*********step2**********")
    val validatorFactory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4)).addMetaSchema(metaSchema).build()
    val schema = validatorFactory.getSchema("{\n" +
      "  \"$schema\":\n" +
      "    \"" + defAltSchUri + "\",\n" +
      "  \"enum\": [\"foo\", \"bar\", \"cone\"],\n" +
      "  \"enumNames\": [\"Foo !\", \"Bar !\", \"Cone !\"]\n" +
      "}")

    println("*********step3**********")
    val messages = schema.validate(objectMapper.readTree(" \"cone\" "))
    //assertEquals(1, messages.size())

    val message = messages.iterator().next()
    println(message.getMessage)
    assertEquals("$: enumName is Cone !", message.getMessage())


    //
    println("END: CustomMetaMapper")

    // based on the keyword (or key in the yaml) define validator metaschema
    // once keyword identified in yaml, constructs newValidator
    //   ((at that time it is possible to verify certain keys/types valid or not))
    // Validator constructor will be called once above newValidator is satisfied
    //   ((some value types can be validated as well as cross field value validation))
    // Once above validator is constructed without field value errors
    // validate method will be called
  }

}
