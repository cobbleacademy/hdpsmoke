package com.drake

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

/**
  * A Helper class to build required artifacts for Spark
  */
object SparkHelper {

  private var sparkSession: SparkSession = _

  /**
    * Returns SparkSession across packages
    *
    * @return
    */
  def buildSparkSession(): SparkSession = {
    //
    val sparkConf = new SparkConf()
    sparkConf.setAll(PropsUtil.getSparkParams)

    //
    sparkSession = SparkSession
      .builder()
      //.master("local")
      .config(sparkConf)
      .appName(PropsUtil.getWorkflow().process)
      .enableHiveSupport()
      .getOrCreate()

    sparkSession.sql("use default")
    sparkSession.sql("set hive.exec.dynamic.partition = true")
    sparkSession.sql("set hive.exec.dynamic.partition.mode = nonstrict ")

    sparkSession
  }


  /**
    * Returns SparkSession across packages
    * @param sparkSessn
    * @return
    */
  def buildSparkSession(sparkSess: SparkSession): SparkSession = {
    //
    sparkSession = sparkSess

    //
    sparkSession
  }

  /**
    * Returns the Spark Session
    *
    * @return
    */
  def getSparkSession(): SparkSession = {
    sparkSession
  }

}
