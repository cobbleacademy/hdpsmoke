package com.drake.model

import java.util.concurrent.Future
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord, RecordMetadata}

/**
  * An executor basis wrapper class to kafka producer to send messages to topic
  */
class KafkaWritable[K, V](buildProducer: () => KafkaProducer[K, V]) extends Serializable {

  // lazily constructed in lazy fashion on executor
  lazy val producer = buildProducer()

  def send(topic: String, key: K, value: V): Future[RecordMetadata] =
    producer.send(new ProducerRecord[K, V](topic, key, value))

  def send(topic: String, value: V): Future[RecordMetadata] =
    producer.send(new ProducerRecord[K, V](topic, value))

}


/**
  * An executor basis wrapper class to kafka producer to send messages to topic
  */
object KafkaWritable {

  import scala.collection.JavaConversions._

  /**
    * Instantiate the writer for kafka
    * @param config
    * @tparam K
    * @tparam V
    * @return
    */
  def apply[K, V](config: Map[String, Object]): KafkaWritable[K, V] = {
    val buildProducer = () => {
      val producer = new KafkaProducer[K, V](config)

      sys.addShutdownHook {
        // Ensure that, on executor JVM shutdown, the Kafka producer sends
        // any buffered messages to Kafka before shutting down.
        producer.close()
      }

      producer
    }
    new KafkaWritable(buildProducer)
  }

}
