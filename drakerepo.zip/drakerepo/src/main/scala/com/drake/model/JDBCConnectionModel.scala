package com.drake.model

import java.sql.{ResultSet, Statement}

import com.drake.{BaseTrait, PropsUtil}
import org.apache.commons.dbcp.BasicDataSource
import org.apache.spark.sql.Row

import scala.collection.mutable.ListBuffer

/**
  * A common model class for all functions required with JDBC Connection
  */
object JDBCConnectionModel {


  class BaseJDBCConnectionModel(handlername: String, forhandlername: String, handlerStartAttr: Map[String, String]) extends JDBCConnectionModel {

    //
    name = handlername
    forName = forhandlername
    startAttrs = handlerStartAttr
    val propsString = PropsUtil.getSparkJdbcPhoenixParamsString()


    /**
      * Creates a datasource of type BasicDataSource
      * @return
      */
    def createDataSource(): BasicDataSource = {
      //
      logger.info(s"printing connection param string: $propsString")
      val bds = new BasicDataSource()
      bds.setDriverClassName(startAttrs.getOrElse("driver", ""))
      bds.setDriverClassName(startAttrs.getOrElse("driver", ""))
      bds.setDefaultAutoCommit(startAttrs.getOrElse("applyAutoCommit", "false").toBoolean)
      bds.setMaxActive(startAttrs.getOrElse("maxSize", "2").toInt)
      bds.setMaxIdle(startAttrs.getOrElse("maxIdle", "2").toInt)
      bds.setMaxWait(startAttrs.getOrElse("maxWaitMs", "5000").toLong)
      bds.setInitialSize(startAttrs.getOrElse("initSize", "1").toInt)
      bds.setConnectionProperties(propsString)
      //
      bds
    }

    //
    lazy val datasource = createDataSource()

    @annotation.tailrec
    final def getResult(resultSet: ResultSet, colCountList: List[Int], rowList: List[Row]): List[Row] = {
      if (resultSet.next()) {
        val list = new ListBuffer[String]
        colCountList.foreach(f => list += resultSet.getString(f))
        getResult(resultSet, colCountList, rowList :+ Row.fromSeq(list.toSeq))
      } else {
        rowList
      }
    }


    /**
      * Executes given sql and returns Row objects
      * @param sql
      * @return
      */
    override def runSql(sql: String): List[Row] = {
      //
      val st: Statement = datasource.getConnection.createStatement()
      val rs: ResultSet = st.executeQuery(sql)
      var resultRows: List[Row] = List[Row]()
      try {
        resultRows = getResult(rs, (1 to rs.getMetaData.getColumnCount).toList, List[Row]())
      } catch {
        case e: Exception => { e.printStackTrace(); logger.equals(e.getMessage)}
      }
      st.close()

      //
      val rowList = resultRows

      //
      rowList
    }


    /**
      * Runs teh given update sql
      * @param sql
      */
    override def runEditSql(sql: String): Unit = {
      //
      val st: Statement = datasource.getConnection.createStatement()
      logger.info(s"Executing runEditSql: $sql")
      val result = st.executeUpdate(sql)
      logger.info(s"Executing runEditSql: $sql == $result")
      st.close()
    }


    /**
      * Runs given udpate query in loop over replace with strings
      * @param sql
      * @param sf search-for string
      * @param rf replace-for string
      * @param ri run iterator to replace with
      */
    override def runEditIterSql(sql: String, sf: String, rf: String, ri: String): Unit = {
      //
      var stmt: Statement = null

      /**
        * Returns Statement based on iteration limit
        * @param itr
        * @return
        */
      def createOrGetStatement(itr: Int): Statement = {
        //
        if (itr % 4 == 0) {
          //
          if (stmt != null) stmt.close()
          //
          stmt = datasource.getConnection.createStatement()
        }
        //
        val st = stmt

        //
        st
      }

      //
      val sfDefined = if (sql.indexOf(sf) > 0) true else false
      val rfDefined = if (sfDefined && sql.indexOf(rf) > 0) true else false
      val iterNeeded = if (sfDefined && rfDefined && ri.length > 0) true else false

      //
      if (iterNeeded) {
        (1 to ri.toInt).foreach(f => {
          val sfrepl = sf.replaceAll(rf, (f-1).toString)
          val iterSql = sql.replaceAll(sf, sfrepl)
          logger.info(s"printing executing runDriverEditLoopOverSql: $iterSql")
          val result = createOrGetStatement(f-1).executeLargeUpdate(iterSql)
        })
      }

      //

    }

  }


  /**
    * preferred factory method
    * @param s
    * @param fs
    * @param sa
    * @return
    */
  def apply(s: String, fs: String, sa: Map[String, String]): JDBCConnectionModel = {
    getJDBCConnectionModel(s, fs, sa)
  }


  /**
    * an alternative to factory method (use one or the other)
    * @param s
    * @param fs
    * @param sa
    * @return
    */
  def getJDBCConnectionModel(s: String, fs: String, sa: Map[String, String]): JDBCConnectionModel = {
    new BaseJDBCConnectionModel(s, fs, sa)
  }

}


/**
  * A common model class for all functions required with JDBC Connection
  */
trait JDBCConnectionModel extends BaseTrait {

  var name: String = _
  var forName: String = _
  var startAttrs: Map[String, String] = _


  /**
    * Executes given sql and returns list spark type Row objects
    * @param sql
    * @return
    */
  def runSql(sql: String): List[Row]


  /**
    * Executes given sql
    *
    * @param sql
    */
  def runEditSql(sql: String): Unit


  /**
    * Executes given sql in loop over replqce with strings
    *
    * @param sql
    * @param sf
    * @param rf
    * @param ri
    */
  def runEditIterSql(sql: String, sf: String, rf: String, ri: String): Unit

}
