package com.drake.model

import java.security.PrivilegedAction

import com.drake.PropsUtil
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{Connection, ConnectionFactory}
import org.apache.hadoop.security.UserGroupInformation

/**
  * A model to produce HBase Token connection
  */
object HBaseUGIModel {

  //
  var propsLoaded: Boolean = false
  var connectionReady: Boolean = false
  lazy val connection: Connection = createConnection()


  /**
    * Creates HBase Connection
    * @return
    */
  def createConnection(): Connection = {
    //
    var connVar: Connection = null
    if (!propsLoaded) {
      PropsUtil.initialize()
      propsLoaded = true
    }

    System.setProperty("java.security.krb5.conf", PropsUtil.propValue("localmode.java.security.krb5.conf", ""))
    System.setProperty("java.security.auth.useSubjectCredsOnly", PropsUtil.propValue("localmode.java.security.auth.useSubjectCredsOnly", "true"))
    System.setProperty("sun.security.krb5.debug", PropsUtil.propValue("localmode.sun.security.krb5.debug", "false"))
    val conf: Configuration = HBaseConfiguration.create()
    conf.addResource("core-site.xml")
    conf.addResource("hbase-site.xml")
    conf.set("hbase.client.keyvalue.maxsize", "0")
    conf.set("hbase.rpc.controllerfactory.class", "org.apache.hadoop.hbase.ipc.RpcControllerFactory")
    conf.set("hbase.security.authentication", "kerberos")
    println("principal:"+PropsUtil.propValue("localmode.login.user.principal") + " and keytab: " + PropsUtil.propValue("localmode.login.user.keytab"))
    UserGroupInformation.setConfiguration(conf)
    val ugi: UserGroupInformation = UserGroupInformation
        .loginUserFromKeytabAndReturnUGI(PropsUtil.propValue("localmode.login.user.principal"), PropsUtil.propValue("localmode.login.user.keytab"))
    ugi.doAs(new PrivilegedAction[Unit] {
      def run: Unit = {connVar = ConnectionFactory.createConnection(conf)}
    })

    //
    connectionReady = true

    //
    val conn = connVar

    //
    conn
  }


}
