package com.drake.model

import org.apache.spark.sql.DataFrame

import scala.collection.mutable

/**
  * A Model to define common case classes
  */
object Model {

  case class OffsetSuite(suite: Map[String, Map[String, Long]])

  case class Attribute(key: String, value: String)

  case class CachedDataFrame(label: String, dataFrame: DataFrame, freq: Long, cachedAt: Long)

  case class LabeledDataFrame(label: String, dataFrame: DataFrame)

  case class SplitDataFrame(label: String, dataFrame: DataFrame)

  case class Split(parts: Option[Map[String, String]], conversions: Array[Map[String, String]])

  case class Splitter(tempView: String, splits: Option[Seq[Map[String, String]]], splitConversions: Option[Seq[Split]])

  case class Step(name: String, model: String, from: Option[String], format: Option[String], command: Option[String], label: Option[String], priority: Option[String], options: Option[Map[String, String]], attributes: Option[Map[String, String]], conversions: Option[Array[Map[String, String]]], include: Option[Map[String, String]], post: Option[Map[String, String]], splitter: Option[Splitter])

  case class Workflow(process: String, version: Option[String] = Some("0.1"), mode: String, steps: Seq[Step], attributes: Option[Map[String, String]], sqlProps: Option[Seq[String]])

  case class Splitter0(tempView: String, splits: Seq[Map[String, String]])

  case class Step0(name: String, model: String, from: Option[String], format: Option[String], command: Option[String], label: Option[String], options: Option[Map[String, String]], attributes: Option[Map[String, String]], conversions: Option[Array[Map[String, String]]], include: Option[Map[String, String]], post: Option[Map[String, String]], splitter: Option[Splitter])

  case class Workflow0(process: String, mode: String, qualityConfig: Option[String], qualityStatus: Option[String], triggerProc: Option[String], triggerScript: Option[String], triggerScriptPath: Option[String], preTrigger: Option[String], onFailTrigger: Option[String], postTrigger: Option[String], steps: Seq[Step], attributes: Option[Seq[Attribute]])

  case class PlanCache(planData: mutable.Map[String, mutable.Map[String, String]], cachedDataFrames: mutable.ListBuffer[DataFrame], aliasDataFrames: mutable.Map[String, DataFrame])

  case class DFTransComp(name: String,label: String,currentTempView: String,tempView: String,cache: Boolean,forceCache: Boolean,cacheStorageLevel: String,dataCache: Boolean,cacheScope: String,frequencyCache: Boolean,frequencyCacheDuration: Long,removeCacheLabels: String,labelAliasEnabled: Boolean,labelAliasScope: String,aliasDataFrame: Option[DataFrame],replaceLabelEnabled: Boolean,replaceLabelWith: String,skipLabelEnabled: Boolean,skipLabelWith: String,skipLabelProcess: Boolean)

  case class Record()

  case class FlowLevel(name: String,
                       label: String,
                       var cacheNeeded: Boolean = false,
                       var displayName: String,
                       var leafLevel: Boolean = true,
                       minLevel: Int = 1,
                       var maxLevel: Int = 1,
                       var dataFrames: List[DataFrame]
                      )


  case class Audit(id: String, runId: String, path: String, numInputRows: Long, inputRowsRate: Double, processedRowsRate: Double, startOffset: String, endOffset: String)
}
