package com.drake.status

import java.text.SimpleDateFormat
import java.util.Calendar

import com.drake.model.Model.{PlanCache, Step}
import com.drake.storage.StorageHelper
import com.drake.{PropsUtil, SparkHelper}

import scala.collection.mutable

/**
  * A Helper to record status either begin or end of the workflow
  */
object StatusBuilderHelper {

  var pCache: PlanCache = _
  var statusMap: mutable.Map[String, String] = mutable.Map[String, String]()


  /**
    * Initialize StatusBuilder
    * @param planCache
    */
  def initialize(planCache: PlanCache): Unit = {
    //
    pCache = planCache
    val wfAttrs = PropsUtil.getWorkflow().attributes.getOrElse(Map[String, String]())

    //
    val nowStr = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SXXX").format(Calendar.getInstance().getTime())

    //
    statusMap = mutable.Map(
      "beginStatus" -> wfAttrs.getOrElse("beginStatus","false"),
      "endStatus" -> wfAttrs.getOrElse("endStatus","false"),
      "statusFormat" -> wfAttrs.getOrElse("statusFormat","csv"),
      "fileName" -> "",
      "fileDt" -> "",
      "count" -> "",
      "startTime" -> nowStr,
      "endTime" -> "",
      "fileName" -> "",
      "status" -> "Started",
      "statusComment" -> wfAttrs.getOrElse("beginStatusComment",""),
      "statusPartBy" -> wfAttrs.getOrElse("statusPartBy",""),
      "statusPartVal" -> keyPathValue("statusPartVal").getOrElse(""),
      "statusPath" -> keyPathValue("statusPath").getOrElse("status")
    )

  }


  /**
    * Filesystem path value
    * @param key
    * @return
    */
  def keyPathValue(key: String): Option[String] = {
    //
    val keyPathOpt = PropsUtil.getWorkflow().attributes.getOrElse(Map()).get(key)
    var pathOpt:Option[String] = None
    if (keyPathOpt.isDefined) {
      val path = StorageHelper.parentageLookup(keyPathOpt.get, pCache.planData)
      pathOpt = if (!path.isEmpty) Some(path) else None
    }

    //
    pathOpt
  }


  /**
    * Updates the status during process execution
    * @param comment
    * @return
    */
  def addStatusComment(comment: String): mutable.Map[String, String] = {
    //
    val currentComments = statusMap.getOrElse("statusComment", "")
    statusMap += (
      "statusComment" -> s"$currentComments $comment"
    )
  }


  /**
    * Store the status of read file
    *
    * @param step
    * @param stepMap
    * @param end
    */
  def logStatus(step: Step, stepMap: mutable.Map[String, String], end: Boolean): Unit = {
    //
    val sparkSession = SparkHelper.getSparkSession()
    var endTime: String = ""
    if (end) endTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SXXX").format(Calendar.getInstance().getTime())

    //
    import sparkSession.implicits._
    //
    val statusDf = Seq(
      (stepMap.get("fileName"), stepMap.get("fileDt"), stepMap.get("fileHr"), stepMap.get("count")
        , stepMap.get("startTime"), endTime, stepMap.get("status"), stepMap.get("statusComment"), stepMap.get("srcSystem")
      )
    ).toDF("file_name", "file_dt", "file_hr", "record_count", "start_time", "end_time", "status", "comment", "src_system")

    //
    StatusBuilder(step.name).statusSink(step, statusDf)

  }


  /**
    * Store the status of read file
    *
    * @param stepName
    * @param end
    */
  def logStatus(stepName: String, end: Boolean): Unit = {
    //
    val sparkSession = SparkHelper.getSparkSession()
    var endTime: String = ""
    if (end) endTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SXXX").format(Calendar.getInstance().getTime())

    //
    import sparkSession.implicits._
    //
    val statusDf =
      if (statusMap.get("statusPartBy").isDefined && statusMap.get("statusPartVal").isDefined)
        Seq(
          (statusMap.get("fileName"), statusMap.get("fileDt"), statusMap.get("fileHr"), statusMap.get("count")
            , statusMap.get("startTime"), endTime, statusMap.get("status"), statusMap.get("statusComment"), statusMap.get("statusPartVal")
          )
        ).toDF("file_name", "file_dt", "file_hr", "record_count",
          "start_time", "end_time", "status", "comment", statusMap.get("statusPartBy").get)
      else
        Seq(
          (statusMap.get("fileName"), statusMap.get("fileDt"), statusMap.get("fileHr"), statusMap.get("count")
            , statusMap.get("startTime"), endTime, statusMap.get("status"), statusMap.get("statusComment")
          )
        ).toDF("file_name", "file_dt", "file_hr", "record_count",
          "start_time", "end_time", "status", "comment")

    //
    StatusBuilder(stepName).statusSink(statusMap, statusDf)

  }


  /**
    * Logs the status of begin execution
    *
    * @param step
    */
  def beginLogStatus(step: Step): Unit = {
    //
    val sessDataMap = StorageHelper.getSessionData()
    logStatus(step, sessDataMap.getOrElse(step.name, mutable.Map[String, String]()), false)
  }


  /**
    * Logs the status of end execution
    *
    * @param step
    * @param statusFrom step name to retrieve session data
    */
  def endLogStatus(step: Step, fromStatusMap: mutable.Map[String, String]): Unit = {
    //
    logStatus(step, fromStatusMap, true)
  }


  /**
    * Logs the status of begin execution
    *
    */
  def beginLogStatus(): Unit = {
    //
    val sessDataMap = StorageHelper.getSessionData()
    if (statusMap.get("beginStatus").isDefined && statusMap.get("beginStatus").get.toBoolean)
      logStatus("beginStatus", false)
  }


  /**
    * Logs the status of end execution
    *
    */
  def endLogStatus(): Unit = {
    //
    if (statusMap.get("beginStatus").isDefined && statusMap.get("beginStatus").get.toBoolean) {
      //
      val wfAttrs = PropsUtil.getWorkflow().attributes.getOrElse(Map[String, String]())
      val currentStat = statusMap.getOrElse("statusComment", "")
      val endStat = wfAttrs.getOrElse("endStatusComment", "")

      //
      statusMap += (
        "status" -> "Completed",
        "statusComment" -> s"$currentStat $endStat"
      )

      //
      logStatus("endStatus", false)
    }
  }

}
