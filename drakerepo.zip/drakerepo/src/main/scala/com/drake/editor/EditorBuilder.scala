package com.drake.editor

import com.drake.{BaseTrait, PlanCacheTrait}
import com.drake.model.Model.{PlanCache, SplitDataFrame, Step}
import org.apache.spark.sql.DataFrame

/**
  * A Builder interface for all the transformations
  */
object EditorBuilder {

  //
  final val DEFAULT_EDITOR_BUILDER: String = getClass.getPackage.getName+".DefaultEditorBuilder"

  /**
    * preferred factory method
    *
    * @param s
    * @param p
    * @return
    */
  def apply(s: String, p: PlanCache): EditorBuilder = {
    getEditorBuilder(s, p)
  }

  // an alternative factory method (use one or the other)
  def getEditorBuilder(s: String, p: PlanCache): EditorBuilder = {
    new DefaultEditorBuilder(s, p)
  }
}

/**
  * A Builder interface for all the transformations
  */
trait EditorBuilder extends BaseTrait with PlanCacheTrait {

  var name: String = _

  /**
    * Returns the transformed DataFrame
    *
    * @param step
    * @return
    */
  def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame]

}


