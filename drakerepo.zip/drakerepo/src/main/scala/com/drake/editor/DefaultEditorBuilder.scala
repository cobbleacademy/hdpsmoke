package com.drake.editor

import com.drake.builder.BuilderHelper
import com.drake.{PropsUtil, SessionDataHelper}
import com.drake.model.Model._
import com.drake.reader.StaticSourceReader
import com.drake.storage.StorageHelper
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions.{col, from_json, lit, udf}
import org.apache.spark.sql.types.StructType

import scala.collection.mutable
import scala.reflect.runtime.universe.{Quasiquote, runtimeMirror}
import scala.reflect.runtime.currentMirror
import scala.tools.reflect.ToolBox

/**
  * A Default Editor Builder for CSV File
  */
class DefaultEditorBuilder(handlername: String, handlerPlanCache: PlanCache) extends EditorBuilder {

  name = handlername
  planCache = handlerPlanCache


  /**
    * //
    * //val multiplyDf = inclDf.withColumn("amountPaid", input("amountPaid") * 2)
    * //def rowHasNull = udf((row: Row) => row.anyNull)
    * //val multiplyDf = input.withColumn("status", rowHasNull(struct(input.columns.map(col): _*)))
    * //multiplyDf
    *
    * @param step
    * @param input
    * @return Returns the transformed input DataFrame
    */
  override def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame] = {
    logger.debug("DefaultEditorBuilder:buildEditor")
    logger.info(s"Step $step.name in progress")

    //
    //
    //
    val ss = input.sparkSession
    val stepAttrs = StorageHelper.mapValuesTransform(step.attributes.getOrElse(Map()),planCache.planData)
    val convAttrs = step.conversions.getOrElse(Array[Map[String, String]]())
    val inclAttrs = step.include.getOrElse(Map())
    val postAttrs = step.post.getOrElse(Map())
    val splitter = step.splitter.getOrElse(Splitter("", Some(Seq[Map[String, String]]()), None))
    //
    val transComp = BuilderHelper.convertToDFTransOpt(step.name, step.label.getOrElse(""), stepAttrs, planCache)

    //
    var mutSplitSeqDfVar: Seq[SplitDataFrame] = Seq(SplitDataFrame(step.label.getOrElse(""), input))

    //
    // Skip label to process
    //
    if (!transComp.skipLabelProcess) {

      var postDfVar: DataFrame = input
      //
      // Replaceable DataFrame not found so run the process
      //
      if (transComp.aliasDataFrame.isDefined) {
        //
        postDfVar = transComp.aliasDataFrame.get
      } else {

        //
        // pre process before include and post
        //
        var preDfVar: DataFrame = input
        // custom transformations either sql or schema
        if (!stepAttrs.isEmpty) preDfVar = BuilderHelper.categoryTransform(name, 0, stepAttrs, input, planCache)
        //
        val preDf = preDfVar

        //
        // Convert individual column level stats into single stat column
        //
        var statDfVar: DataFrame = preDf
        if (!stepAttrs.isEmpty && "true".equals(stepAttrs.getOrElse("invalidCheck",""))) {
          // load invalid config for given src_system and table
          StaticSourceReader.initializeStaticSources(stepAttrs)
          statDfVar = BuilderHelper.invalidConfigTransform(stepAttrs, preDf, planCache)
        }
        val statDf = statDfVar


        //
        // pre process before include and post
        //
        var convDfVar: DataFrame = statDf
        //
        if (!convAttrs.isEmpty) convDfVar = BuilderHelper.recursiveCategoryTransform(name, 1, convAttrs, statDf, planCache)
        //
        val convDf = convDfVar


        //
        // include process
        //
        var inclDfVar: DataFrame = convDf
        //
        if (!inclAttrs.isEmpty) inclDfVar = BuilderHelper.includeAttributeTransform(inclAttrs, convDf, planCache)
        //
        val inclDf = inclDfVar


        //
        // post sql execution
        //
        var postDfVarLast: DataFrame = inclDf
        // custom transformations either sql or schema
        if (!postAttrs.isEmpty) postDfVarLast = BuilderHelper.categoryTransform(name, 0, postAttrs, inclDf, planCache)
        //
        postDfVar = postDfVarLast

      }

      //
      val postDf = BuilderHelper.applyCacheAfter(transComp, postDfVar, planCache)

      //
      mutSplitSeqDfVar = Seq(SplitDataFrame(step.label.getOrElse(""), postDf))

      //
      if (!splitter.tempView.isEmpty) {
        // register tempView as
        postDf.createOrReplaceTempView(splitter.tempView)
        var occurrence = 0

        if (!splitter.splits.isEmpty) {
          //
          splitter.splits.getOrElse(Seq[Map[String, String]]()).foreach(f => {
            //
            val splitAttrs = StorageHelper.mapValuesTransform(f, planCache.planData)
            val splitTransComp = BuilderHelper.convertToDFTransOpt(step.name, "", splitAttrs, planCache)
            var splitDfVar: DataFrame = null

            if (!splitTransComp.skipLabelProcess) {
              //
              splitDfVar =
                if (splitTransComp.replaceLabelEnabled && splitTransComp.aliasDataFrame.isDefined)
                  splitTransComp.aliasDataFrame.get
                else
                  BuilderHelper.categoryTransform(name, occurrence, splitAttrs, postDf, planCache)

              val currDf = splitDfVar
              val currSplitDf = SplitDataFrame(splitTransComp.label, currDf)

              //
              mutSplitSeqDfVar = mutSplitSeqDfVar :+ currSplitDf
            }

            //
            occurrence += 1
          })

        } else {
          println(s"printing DefaultEditorBuilder $name ${step.name} ${splitter.splitConversions.size}")
          //
          splitter.splitConversions.getOrElse(Seq[Split]()).foreach(f => {
            //
            val convPartsCurr: Map[String, String] = StorageHelper.mapValuesTransform(f.parts.getOrElse(Map[String, String]()), planCache.planData)
            val convPartsCurrTransComp = BuilderHelper.convertToDFTransOpt(name, "", convPartsCurr, planCache)
            if (!convPartsCurrTransComp.skipLabelProcess) {
              //
              val (splitAdd, splitLabel, splitDf) = BuilderHelper.recursiveSplitCategoryTransform(name, occurrence, f.conversions, postDf, planCache)
              //
              if (splitAdd) {
                val currSplitDf = SplitDataFrame(splitLabel, splitDf)
                //
                mutSplitSeqDfVar = mutSplitSeqDfVar :+ currSplitDf
              }
            }

            //
            occurrence += 1
          })

        }


      }


    }
    //
    val mutSplitSeqDf = mutSplitSeqDfVar

    //
    mutSplitSeqDf
  }


}
