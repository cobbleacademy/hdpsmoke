package com.drake.fs

import java.time.Instant

import com.drake.model.Model.PlanCache
import com.drake.storage.StorageHelper
import com.drake.{BaseTrait, PropsUtil, SparkHelper}
import org.apache.hadoop.conf
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}

import scala.collection.mutable

/**
  * A File System Helper which implements delete/create file/directory functions
  */
object FSHelper extends BaseTrait {

  var fs: FileSystem = _
  var lfs: FileSystem = _
  var pCache: PlanCache = _

  /**
    * FileSystem initialization process
    *
    * @param planCache
    */
  def initialize(planCache: PlanCache): Unit = {
    //
    val lclConf: Configuration = new conf.Configuration()
    fs = FileSystem.get(SparkHelper.getSparkSession().sparkContext.hadoopConfiguration)
    import collection.JavaConverters._
    val confS = SparkHelper.getSparkSession().sparkContext.hadoopConfiguration.asScala
    confS.map(f => lclConf.set(f.getKey, f.getValue))
    val fsname = fs.getConf.get("fs.defaultFS")
    println(s"printing FileSystem: ${fs.getClass} ${fs.getScheme} ${fs.getHomeDirectory.getName} $fsname ")
    //
    lclConf.set("fs.defaultFS", "file:///")
    lfs = FileSystem.getLocal(lclConf)
    val lfsname = lfs.getConf.get("fs.defaultFS")
    println(s"printing FileSystem: ${lfs.getClass} ${lfs.getScheme} ${lfs.getHomeDirectory.getName} $lfsname ")
    //
    pCache = planCache
  }


  /**
    * FileSystem path value
    * @param key
    * @return
    */
  def fsPathValue(key: String): Option[String] = {
    //
    val keyPathOpt = PropsUtil.getWorkflow.attributes.getOrElse(Map()).get(key)
    var pathOpt: Option[String] = None
    if (keyPathOpt.isDefined) {
      val keyPaths = keyPathOpt.get.split(",")
      //
      val paths = keyPaths.flatMap(t => {
        val path = StorageHelper.parentageLookup(t, pCache.planData)
        pathOpt = if (!path.isEmpty) Some(path) else None
        pathOpt
      })
      //
      pathOpt = Some(paths.mkString(","))
    }
    //
    pathOpt
  }


  /**
    * Delete configured paths from FileSystem in Workflow
    * @param key
    * @param recursive
    */
  def deletePath(key: String, recursive: Boolean = false): Unit = {
    //
    val pathOpt = fsPathValue(key)
    if (pathOpt.isDefined) {
      val paths = pathOpt.get.split(",")
      paths.map(t => if (t.startsWith("file:/")) lfs.delete(new Path(t), recursive) else fs.delete(new Path(t), recursive))
    }
  }

  /**
    * Creates configured path from FileSystem in Workflow
    * @param key
    */
  def createDirPath(key: String): Unit = {
    //
    val pathOpt = fsPathValue(key)
    if (pathOpt.isDefined) {
      val paths = pathOpt.get.split(",")
      paths.map(t => if (t.startsWith("file:/")) lfs.mkdirs(new Path(t)) else fs.mkdirs(new Path(t)))
    }
  }


  /**
    * Creates configured path from FileSystem in Workflow
    * @param key
    */
  def createPath(key: String): Unit = {
    //
    val pathOpt = fsPathValue(key)
    if (pathOpt.isDefined) {
      val paths = pathOpt.get.split(",")
      paths.map(t => if (t.startsWith("file:/")) lfs.create(new Path(t)) else fs.create(new Path(t)))
    }
  }

  /**
    * Cleanup Work Directory
    * @param recursive
    */
  def cleanupWorkPath(recursive: Boolean = false): Unit = {
    //
    val pathOpt = fsPathValue("workPathPrefix")
    //
    if (pathOpt.isDefined) {
      //
      val partKeyOpt = fsPathValue("workPartBy")
      val partValOpt = fsPathValue("workPartVal")
      //
      val paths = pathOpt.get.split(",")
      paths.map(telem => {
        var t = telem
        //
        if (partKeyOpt.isDefined && partValOpt.isDefined) {
          val plnProcEpoch = StorageHelper.parentageLookup("$plan#processEpochSec", pCache.planData)
          t = t + "/" + partKeyOpt.getOrElse("") + "=" + partValOpt.getOrElse("") + "/" + plnProcEpoch
          //
          logger.info(s"printing delete work path recursively: $t")
          if (t.startsWith("file:/")) lfs.delete(new Path(t), recursive) else fs.delete(new Path(t), recursive)
        }

      })

    }
  }


  /**
    * Setup Work Directory
    * @param recursive
    */
  def setupWorkPath(recursive: Boolean = false): Unit = {
    //
    val pathOpt = fsPathValue("workPathPrefix")
    //
    if (pathOpt.isDefined) {
      logger.info(s"printing work prefix path: ${pathOpt.get}")
      //
      val partKeyOpt = fsPathValue("workPartBy")
      val partValOpt = fsPathValue("workPartVal")
      //
      val paths = pathOpt.get.split(",")
      paths.map(telem => {
        var t = telem
        //
        if (partKeyOpt.isDefined && partValOpt.isDefined) {
          val plnProcEpoch = StorageHelper.parentageLookup("$plan#processEpochSec", pCache.planData)
          t = t + "/" + partKeyOpt.getOrElse("") + "=" + partValOpt.getOrElse("")
          //
          logger.info(s"printing delete work path recursively: $t")
          val currTime = Instant.now.toEpochMilli
          val purgeTime = PropsUtil.getSparkHdfsWorkPugeTime()
          if (t.startsWith("file:/")) {
            lfs.listStatus(new Path(t)).foreach(f => {
              if ((currTime - f.getModificationTime) > purgeTime) {
                lfs.delete(f.getPath, recursive)
                logger.info(s"printing delete work path on time basis recursively: ${f.getPath}")
              }
            })
          } else {
            fs.listStatus(new Path(t)).foreach(f => {
              if ((currTime - f.getModificationTime) > purgeTime) {
                fs.delete(f.getPath, recursive)
                logger.info(s"printing delete work path on time basis recursively: ${f.getPath}")
              }
            })
          }
          if (t.startsWith("file:/")) lfs.delete(new Path(t), recursive) else fs.delete(new Path(t), recursive)
        }

      })


      PropsUtil.getWorkflow.attributes.getOrElse(Map())
        .filter(p => p._1.startsWith("workPathSaveAs"))
        .map(p => {
          val pathSaveAs = Some(p._2)
          val paths = pathOpt.get.split(",")
          paths.map(telem => {
            //
            var t = telem
            //
            if (partKeyOpt.isDefined && partValOpt.isDefined) {
              val plnProcEpoch = StorageHelper.parentageLookup("$plan#processEpochSec", pCache.planData)
              t = t + "/" + partKeyOpt.getOrElse("") + "=" + partValOpt.getOrElse("") + "/" + plnProcEpoch + Instant.now.toEpochMilli.toString
            }

            //
            logger.info(s"printing work path: $t")

            //
            if (pathSaveAs.isDefined) {
              val keySplit = pathSaveAs.get.split("#")
              StorageHelper.mutateSessionStorage(keySplit(0), mutable.Map(keySplit(1) -> t))
            }

            //
            if (t.startsWith("file:/")) {
              lfs.delete(new Path(t), recursive)
              lfs.mkdirs(new Path(t))
            } else {
              fs.delete(new Path(t), recursive)
              fs.mkdirs(new Path(t))
            }

          })
        })

    } //if
  }


  /**
    * Begin Process in FileSystem before workflow execution
    */
  def beginProcess(): Unit = {
    //
    deletePath("deleteDirPath", true)
    deletePath("deletePath")
    createDirPath("createDirPath")
    createDirPath("createPath")
    setupWorkPath(true)
  }


  /**
    * End Process in FileSystem after workflow execution
    */
  def endProcess(): Unit = {
    //
    createPath("onCompleteCreatePath")
    cleanupWorkPath(true)
  }

}
