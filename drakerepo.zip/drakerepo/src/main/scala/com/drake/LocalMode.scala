package com.drake

object LocalMode {

  def secureLocalLogin(): Unit = {

  }

  def secureLogin(): Unit = {

  }

}
