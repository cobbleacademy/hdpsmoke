package com.drake

object SEvalWork {

//  val answer = lengths.indices.foldLeft(fields) { case (result, idx) =>
//    result.withColumn(s"col_$idx", $"fields".getItem(idx))
//  }

  def parseLinePerFixedLengths(line: String, lengths: Seq[Int]): Seq[String] = {
    lengths.indices.foldLeft((line, Array.empty[String])) { case ((rem, fields), idx) =>
      val len = lengths(idx)
      val fld = rem.take(len)
      (rem.drop(len), fields :+ fld)
    }._2
  }

  def main1(args: Array[String]): Unit = {

    val arr = parseLinePerFixedLengths("11 apple     TRUE 0.56", Seq(3,10,5,4))

    println(arr.size)
    arr.foreach(println)

  }

  def main2(args: Array[String]): Unit = {

  }

  def main(args: Array[String]): Unit = {
    main2(args)
  }

}
