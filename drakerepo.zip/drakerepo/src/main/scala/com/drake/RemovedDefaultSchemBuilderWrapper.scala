package com.drake

trait RemovedDefaultSchemBuilderWrapper {


  /**
    * Returns whether record conforms or not
    * @param record
    * @return
    */
  def containsSchema(record: String): Boolean = {
    true
  }

}
