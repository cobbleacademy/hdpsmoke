package com.drake

import java.io.{File, FileInputStream, InputStreamReader}
import java.util.Properties

import com.drake.model.Model.Workflow
import com.drake.offset.OffsetStore
import org.apache.kafka.common.serialization.StringDeserializer
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse
import io.circe.yaml.parser
import org.apache.hadoop.conf
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.security.alias.CredentialProviderFactory
import org.apache.spark.SparkFiles

import scala.collection.JavaConversions._
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.Try


/**
  * Reads property file to provide key based values
  */
object PropsUtil {

  private val props = new Properties()
  private var workflow: Workflow = _

  implicit val formats = DefaultFormats

  /**
    * Load properties using property file
    */
  def loadProperties(): Unit = {
    if (props.size() == 0) {
      val path = System.getProperty("propertyFile")
      //val path = "/Users/nnagaraju/IDEAWorkspace/drake/src/main/resources/sparkpipeline.properties"
      println("loading properties file from " + path)
      val bufferedFile = Source.fromFile(path)
      props.load(bufferedFile.reader())
      bufferedFile.close()
      println("logging all kehy values from properties file " + props.entrySet())
    }
  }

  /**
    * Load json based pipeline from file
    */
  def loadWorkflow(): Unit = {
    //
    val path = System.getProperty("workflowFile")
    //val path = "/Users/nnagaraju/IDEAWorkspace/drake/src/main/resources/workflow.json"
    val bufferedFile = Source.fromFile(path)
    println("printing json contents")
    val json = parse(bufferedFile.getLines.mkString)
    println(json)
    workflow = json.extract[Workflow]
    println(workflow)
    bufferedFile.close()
  }


  /**
    * Load json based pipeline from file
    */
  def loadWorkflowYaml(): Unit = {
    //
    val path = System.getProperty("workflowFileYaml")
    //val path = "/Users/nnagaraju/IDEAWorkspace/drake/src/main/resources/workflow_standalone.yml"
    //val bufferedFile = Source.fromFile(path)
    //val json = parser.parse(bufferedFile.getLines.mkString("\n"))
    //bufferedFile.close()
    println("printing yaml contents")
    val fstream = new FileInputStream(new File(path))
    val jsonObj = io.circe.yaml.parser.parse(new InputStreamReader(fstream))
    println(jsonObj)
    val json = parse(jsonObj.right.get.toString)
    workflow = json.extract[Workflow]
    println(workflow)
    fstream.close()
  }


  /**
    * initialize with properties and workflow
    */
  def initialize(): Unit = {
    loadProperties()
    //loadWorkflow()
    loadWorkflowYaml()
  }


  /**
    * Returns workflow of events
    * @return
    */
  def getWorkflow(): Workflow = {
    workflow
  }


  /**
    * Returns properties as map
    * @return
    */
  def getPropertiesAsMap(): mutable.Map[String, String] = {
    import scala.collection.JavaConverters._
    props.asScala
  }



  /**
    * Returns scala code from path file to create schema
    * @param path
    * @return
    */
  def loadSchemaCode(path: String): String = {
    println("SparkFiles rootdir: " + SparkFiles.getRootDirectory() + " " + new File("").getAbsolutePath)
    val pathStr = SparkFiles.get(path)
    println("File Location: " + pathStr)
    val bufferedFile = Source.fromFile(path)
    //println("printing SchemaCode contents")
    val code = bufferedFile.getLines.mkString("\n")
    //println(code)
    code
  }

  /**
    * Returns scala code from path file to create schema
    * @param path
    * @return
    */
  def loadContainsSchemaCode(path: String): String = {
    val bufferedFile = Source.fromFile(path)
    var code = ""
    var startAdd = false
    var stopAdd = false
    var codeArray: ListBuffer[String] = ListBuffer[String]()
    bufferedFile.getLines.foreach(f => {
      var clf = f
      if(startAdd && f.contains("containsSchemaVal")) clf = f.split(" = ")(1)
      if (f.contains("END")) stopAdd = true
      if (startAdd && !stopAdd) codeArray += clf
      if (f.contains("BEGIN")) startAdd = true
    })
    code = codeArray.mkString("\n")
    //println(code)
    code
  }

  /**
    * Returns file content from path
    * @param path
    * @return
    */
  def loadFileContent(path: String): String = {
    println("SparkFiles rootdir: " + SparkFiles.getRootDirectory() + " " + new File("").getAbsolutePath)
    val pathStr = SparkFiles.get(path)
    println("File Location: " + pathStr)
    val bufferedFile = Source.fromFile(path)
    val content = bufferedFile.getLines.mkString("\n")
    content
  }

  /**
    * Get DStream based Kafka Parameters
    *
    * @return
    */
  def getKafkaParams(): Map[String, Object] = {
    val kafkaParams = Map("group.id" -> propValue("kafka.group.id"),
      "security.protocol" -> propValue("kafka.security.protocol"),
      "bootstrap.servers" -> propValue("kafka.metadata.broker.list"),
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "auto.offset.reset" -> "none",
      "heartbeat.interval.ms" -> (100000: java.lang.Integer),
      "session.timeout.ms" -> (300000: java.lang.Integer),
      "fetch.max.wait.ms" -> (100000: java.lang.Integer),
      "request.timeout.ms" -> (400000: java.lang.Integer),
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )

    kafkaParams
  }

  /**
    * Returns Regex for Query substitution
    * @return
    */
  def getQuerySubstRegex(): String = {
    propValue("spark.query.subst.regex", """(?<!\\)\$([0-9a-zA-z\._\#-]+)""")
  }

  /**
    * Returns escape string for Query substitution
    * @return
    */
  def getQuerySubstEscapeString(): String = {
    propValue("spark.query.subst.escape.string", """\$""")
  }

  /**
    * Returns escape string for Query substitution
    * @return
    */
  def getQuerySubstEscapeReplace(): String = {
    propValue("spark.query.subst.escape.replace", """$""")
  }

  /**
    * Get Kafka Source Connection parameters
    *
    * @return
    */
  def getKafkaConsumerParams(stepOpts: Map[String, String]): Map[String, String] = {
    //
    val removePrefix = props.getProperty("kafka.nonprefixkeys","").split(",")

    // return map of spark params
    props.entrySet().filter(x => x.getKey.toString.startsWith("kafka.")).map(x => {
      var key = x.getKey.toString
      var value = x.getValue.toString
      if (removePrefix.contains(key.split("\\.")(1))) key = key.split("\\.")(1)
      if (key.equals("startingOffsets")) {
        val topicStr =  stepOpts.getOrElse("subscribe", propValue("kafka.subscribe"))
        val groupStr =  stepOpts.getOrElse("groupId", propValue("kafka.group-id"))
        val currVal = OffsetStore.getOffsetStore.readOffsets(topicStr.split(","),groupStr,value)
        println("Current Offsets for : " + currVal)
        if (!currVal.isEmpty) value = currVal
      }

      (key -> value)
    }).toMap
  }

  /**
    * Get Kafka Source Connection parameters
    *
    * @return
    */
  def getKafkaProducerParams(stepOpts: Map[String, String]): Map[String, String] = {
    //
    val removePrefix = props.getProperty("kafka.nonprefixkeys","").split(",")

    // return map of spark params
    props.entrySet().filter(x => x.getKey.toString.startsWith("kafka.")).map(x => {
      var key = x.getKey.toString
      var value = x.getValue.toString
      if (removePrefix.contains(key.split("\\.")(1))) key = key.split("\\.")(1)

      (key -> value)
    }).toMap
  }

  /**
    * Get map of spark parameters
    *
    * @return
    */
  def getSparkParams(): Map[String, String] = {

    //return map of spark params
    props.entrySet().filter(x => x.getKey.toString.startsWith("spark.")).map(x => {
      (x.getKey.toString -> x.getValue.toString)
    }).toMap
  }

  /**
    * Get list of phoenix jdbc parameters string
    *
    * @return
    */
  def getSparkJdbcPhoenixParamsString(): String = {

    //return map of spark params
    val pfx = "spark.jdbc.phx."
    val propMap = props.entrySet().filter(x => x.getKey.toString.startsWith(pfx)).map(x => {
      (x.getKey.toString.replaceAll(pfx, "") -> x.getValue.toString)
    }).toMap.map(_.productIterator.mkString("=")).mkString(";")

    val propStr = if (propMap.size > 0) propMap + ";" else propMap

    //
    propStr
  }

  /**
    * Get list of phoenix jdbc parameter Properties
    *
    * @return
    */
  def getSparkJdbcPhoenixParamProperties(): Properties = {

    //return map of spark params
    val pfx = "spark.jdbc.phx."
    val propsPhx = new Properties()
    val propscl = props.entrySet().filter(x => x.getKey.toString.startsWith(pfx)).map(x => {
      (x.getKey.toString.replaceAll(pfx, "") -> x.getValue.toString)
    })

    propscl.foreach { case (key, value) => propsPhx.setProperty(key, value.toString) }

    //
    propsPhx
  }

  /**
    * Get purge time in millisecs on work directory cleanup
    *
    * @return
    */
  def getSparkHdfsWorkPugeTime(): Long = {
    Try(props.getProperty("spark.accel.hdfs.path.phx.work.purge.millisec").toLong).getOrElse(604800000)
  }

  /**
    * Get the Long value for given key
    *
    * @param key
    * @return
    */
  def propLong(key: String) = {
    props.getProperty(key).toLong
  }

  /**
    * Get the Boolean value for given key
    *
    * @param key
    * @return
    */
  def propBoolean(key: String) = {
    Try(props.getProperty(key).toLowerCase.toBoolean).getOrElse(false)
  }


  /**
    * Get the value for given key
    *
    * @param key
    * @return
    */
  def propValue(key: String) = {
    props.getProperty(key)
  }

  /**
    * Get the value for given key
    *
    * @param key
    * @param deflt
    * @return
    */
  def propValue(key: String, deflt: String) = {
    props.getProperty(key, deflt)
  }

  /**
    * Get the system value for given key
    *
    * @param key
    * @param deflt
    * @return
    */
  def propSystem(key: String, deflt: String) = {
    System.getProperty(key, deflt)
  }


  /**
    * Returns boolean value
    * @return
    */
  def printSchema(): Boolean = {
    workflow.attributes.getOrElse(Map()).getOrElse("printSchema", "false").toBoolean
  }

  /**
    * Returns boolean value
    * @return
    */
  def showData(): Boolean = {
    workflow.attributes.getOrElse(Map()).getOrElse("showData", "false").toBoolean
  }

  /**
    * Returns boolean value
    * @return
    */
  def cacheByPlan(): Boolean = {
    workflow.attributes.getOrElse(Map()).getOrElse("cacheByPlan", "true").toBoolean
  }

  /**
    * Returns value
    * @return
    */
  def singleRow(): String = {
    workflow.attributes.getOrElse(Map()).getOrElse("singleRow", "singlerow")
  }

  /**
    * Returns password for given alias using credential provider
    * @param alias
    * @param provider
    * @return
    */
  def getPasswordFromCredentialProvider(alias: String, provider: String): String = {
    var pss: Array[Char] = null

    try {
      val conf: Configuration = new Configuration()

      conf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, provider)
      pss = conf.getPassword(alias)

    } catch {
      case e: Exception => {
        e.printStackTrace()
      }
    }

    //
    pss.mkString
  }

  /**
    * Returns update options with password from jceks config provider
    * @param opts
    * @param attrs
    * @return
    */
  def getPassowrdOptions(opts: Map[String, String], attrs: Map[String, String]): Map[String, String] = {

    var outOpts: Map[String, String] = opts

    try {
      //
      val pwaOpt = opts.get("passwordAlias")
      val propOpt = attrs.get("provider")
      var pw = ""
      if (pwaOpt.isDefined && propOpt.isDefined) {
        val conf: Configuration = new Configuration()
        conf.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, propOpt.get)
        pw = conf.getPassword(pwaOpt.get).mkString
      } else {
        pw = ""
      }
      outOpts = opts + ("password" -> pw)
    } catch {
      case e: Exception => {
        e.printStackTrace()
      }
    }


    //
    outOpts
  }

}
