package com.drake.broadcast

import com.drake.{BaseTrait, PropsUtil, SparkHelper}
import com.drake.model.{HBaseUGIModel, JDBCConnectionModel, KafkaWritable}
import org.apache.hadoop.hbase.client.Connection
import org.apache.spark.broadcast.Broadcast

/**
  * A wrapper class to broadcast different variables across cluster
  */
object BroadcastWrapper extends BaseTrait {

  //
  var hbaseBCVar: Broadcast[String] = null
  var jdbcBCMap: Map[String, Broadcast[JDBCConnectionModel]] = Map[String, Broadcast[JDBCConnectionModel]]()
  var kafkaProducerBC: Broadcast[KafkaWritable[Array[Byte], String]] = _

  def broadcastHBaseUGI(name: String): Broadcast[String] = {
    if (hbaseBCVar == null) {
      val connection: Connection = HBaseUGIModel.createConnection()
      hbaseBCVar = SparkHelper.getSparkSession().sparkContext.broadcast("HBase")
    }
    //
    hbaseBCVar
  }


  /**
    * Broadcast JDBCConnection
    * @param bcName
    * @param name
    * @param forName
    * @param startAttrs
    * @return
    */
  def broadcastJDBCConnection(bcName: String, name: String, forName: String, startAttrs: Map[String, String]): Broadcast[JDBCConnectionModel] = {
    //
    var jdbcConnVar: Broadcast[JDBCConnectionModel] = null
    if (!jdbcBCMap.isDefinedAt(bcName)) {
      val lcl = SparkHelper.getSparkSession().sparkContext.broadcast(JDBCConnectionModel(name, forName, startAttrs))
    }
    val jdbcConn = jdbcBCMap.getOrElse(bcName,jdbcConnVar)

    //
    jdbcConn
  }


  /**
    * Returns Broadcast JDBC Connection
    * @param bcName
    * @param name
    * @param forName
    * @param startAttrs
    * @return
    */
  def getJDBCConnectionBroadBroadcast(bcName: String, name: String, forName: String, startAttrs: Map[String, String]): JDBCConnectionModel = {
    broadcastJDBCConnection(bcName, name, forName, startAttrs).value
  }


  /**
    * Creates Kafka Writer broadcast variable
    * @param startOpts
    * @return
    */
  def createKafkaWritableBroadcast(startOpts: Map[String, String]): Broadcast[KafkaWritable[Array[Byte], String]] = {

    // create broadcast variable
    kafkaProducerBC = SparkHelper
      .getSparkSession()
      .sparkContext
      .broadcast(KafkaWritable[Array[Byte], String](PropsUtil.getKafkaConsumerParams(startOpts)))

    //
    kafkaProducerBC
  }


  /**
    * Returns KafkaWritable Broadcast wrapper
    * @return
    */
  def getKafkaWritableBroadcast: Broadcast[KafkaWritable[Array[Byte], String]] = {
    //
    kafkaProducerBC
  }


  /**
    * Initialize broadcast references
    */
  def initialize() = {

  }



}
