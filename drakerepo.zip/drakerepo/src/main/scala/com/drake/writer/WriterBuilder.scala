package com.drake.writer

import java.util.UUID

import com.drake._
import com.drake.builder.{BuilderHelper, ReadEditWriteHelper}
import com.drake.model.Model.{PlanCache, Step}
import com.drake.storage.StorageHelper
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.udf

import scala.collection.mutable

/**
  * A Builder class for Writer for output content
  */
object WriterBuilder {

  /**
    * Builds specific Writer
    */
  class BaseWriter(handlername: String, handlerPlanCache: PlanCache) extends WriterBuilder {

    //
    name = handlername
    planCache = handlerPlanCache

    val generateUUID = udf(() => UUID.randomUUID().toString)

    /**
      * Attributes from local step or from step
      * @param stepAttrs
      * @return
      */
    def getFromLogAttrs(stepAttrs: Map[String, String]): mutable.Map[String, String] = {
      //
      val sessDataMap = StorageHelper.getSessionData()
      val fromSessMap = sessDataMap.getOrElse(stepAttrs.getOrElse("logStatusFrom", ""), mutable.Map[String, String]())
      val logAttrMap = fromSessMap.clone()

      //
      logAttrMap += (
        "status" -> stepAttrs.getOrElse("status", fromSessMap.getOrElse("status", "")),
        "statusComment" -> stepAttrs.getOrElse("statusComment", fromSessMap.getOrElse("statusComment", "")),
        "count" -> stepAttrs.getOrElse("count", fromSessMap.getOrElse("count", ""))
      )

      //
      logAttrMap
    }

    /**
      * Writes DataFrame content to Sink
      *
      * @param step
      * @param outputFrame
      * @return
      */
    override def writeSink(step: Step, outputFrame: DataFrame): Unit = {
      logger.debug("BaseWriter:writerSink")

      //
      val sinkOpts = StorageHelper.mapValuesTransform(step.options.getOrElse(Map()),planCache.planData)
      val sinkAttrs = StorageHelper.mapValuesTransform(step.attributes.getOrElse(Map()),planCache.planData)
      val postAttrs = step.post.getOrElse(Map())

      //
      val sparkSession = SparkHelper.getSparkSession()


      //
      if ("stream".equals(PropsUtil.getWorkflow().mode)) {

        //
        ReadEditWriteHelper.streamingWriter(step.format.getOrElse(""), sinkAttrs, sinkOpts, outputFrame)

      } else {

        if (ReadEditWriteHelper.isMultiWriterEnabled(sinkAttrs)) {
          //
          ReadEditWriteHelper.multiWriter(step.format.getOrElse(""), sinkAttrs, sinkOpts, outputFrame, planCache)
        } else {
          //
          ReadEditWriteHelper.batchWriter(step.format.getOrElse(""), sinkAttrs, sinkOpts, outputFrame, planCache)
        }

      } // mode


      //
      // post cleanup execution
      //
      if(!postAttrs.isEmpty) BuilderHelper.categoryTransform(name, 0, postAttrs, outputFrame, planCache)


    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String, p: PlanCache): WriterBuilder = {
    getWriterBuilder(s, p)
  }

  // an alternative factory method (use one or the other)
  def getWriterBuilder(s: String, p: PlanCache): WriterBuilder = {
    new BaseWriter(s, p)
  }

}

/**
  * A Builder interface for all the Sink Writer
  */
trait WriterBuilder extends BaseTrait with PlanCacheTrait {

  var name: String = _


  /**
    * Writes DataFrame content to Sink
    *
    * @param step
    * @return
    */
  def writeSink(step: Step, output: DataFrame): Unit

}
