package com.drake

import com.networknt.schema.{JsonMetaSchema, JsonSchemaFactory, SpecVersion}
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory
import com.fasterxml.jackson.databind.ObjectMapper
import java.util

import com.drake.WorkflowConfigValidator.ProcessKeyword
import org.junit.Assert.assertEquals

import collection.JavaConverters._


object NNTValidator {


  def main_default(args: Array[String]): Unit = {
    val mapper = new ObjectMapper(new YAMLFactory)

    //
    val factory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7)).objectMapper(mapper).build
    /* Using draft-07. You can choose anyother draft.*/
    val schema = factory.getSchema(getClass.getClassLoader.getResourceAsStream("fstab-schema.json"))

    //
    val goodNode = mapper.readTree(getClass.getClassLoader.getResourceAsStream("fstab-good.yaml"))
    val validateGoodMsg = schema.validate(goodNode).asScala
    println("Good Node Details.....")
    println(goodNode)
    println(goodNode.findValues("device"))
    println("Good Messages size: " + validateGoodMsg.size)

    //
    val badNode = mapper.readTree(getClass.getClassLoader.getResourceAsStream("fstab-bad.yaml"))
    val validateBadMsg = schema.validate(badNode).asScala
    validateBadMsg.foreach(println)
    println("Bad Messages size: " + validateBadMsg.size)

    //
    val bad2Node = mapper.readTree(getClass.getClassLoader.getResourceAsStream("fstab-bad2.yaml"))
    val validateBad2Msg = schema.validate(bad2Node).asScala
    validateBad2Msg.foreach(println)
    println("Bad2 Messages size: " + validateBad2Msg.size)
  }



  def main_mbr(args: Array[String]): Unit = {
    val mapper = new ObjectMapper(new YAMLFactory)

    //
    val defAltSchUri = "https://github.com/drake/schemas/member#"

    val metaSchema = JsonMetaSchema
      .builder(defAltSchUri, JsonMetaSchema.getV7())
      // Generated UI uses enumNames to render Labels for enum values
      .addKeyword(new WorkflowConfigValidator.ProcessKeyword("accel"))
      .build()

    println("metaSchema is built: " + metaSchema)

    //
    //val factory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7)).addMetaSchema(metaSchema).objectMapper(mapper).build
    val factory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7)).addMetaSchema(metaSchema).build()
    /* Using draft-07. You can choose anyother draft.*/
    val schema = factory.getSchema(getClass.getClassLoader.getResourceAsStream("mbr-schema.json"))

    println("Good Node Details.....")
    val goodNode = mapper.readTree(getClass.getClassLoader.getResourceAsStream("mbr-sales.yaml"))
    val validateGoodMsg = schema.validate(goodNode).asScala
    //val validateGoodMsg = schema.validate(mapper.readTree(" {\"cone\"} ")).asScala
    println(validateGoodMsg.size)
    validateGoodMsg.foreach(println)

    //println(goodNode)
    //validateGoodMsg.foreach(println)
    //println("Good Messages size: " + validateGoodMsg.size)
  }


  def main_custom(args: Array[String]): Unit = {
    //
    println("BEGIN: WorkflowConfigValidator")

    //val objectMapper = new ObjectMapper()
    val objectMapper = new ObjectMapper(new YAMLFactory)

    println("*********step1**********")
    val defSchUri = "https://github.com/networknt/json-schema-validator/tests/schemas/example01#"
    val defAltSchUri = "https://github.com/drake/schemas/member#"

    val metaSchema = JsonMetaSchema
      .builder(defAltSchUri, JsonMetaSchema.getV4())
      // Generated UI uses enumNames to render Labels for enum values
      .addKeyword(new ProcessKeyword("process"))
      .build()

    println("*********step2**********")
    val validatorFactory = JsonSchemaFactory.builder(JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V4)).addMetaSchema(metaSchema).build()
//    val schema = validatorFactory.getSchema("{\n" +
//      "  \"$schema\":\n" +
//      "    \"" + defAltSchUri + "\",\n" +
//      "  \"process\": \"mbr\",\n" +
//      "  \"accel\": [\"foo\", \"bar\", \"cone\"],\n" +
//      "  \"enum\": [\"foo\", \"bar\", \"cone\"],\n" +
//      "  \"enumNames\": [\"Foo !\", \"Bar !\", \"Cone !\"]\n" +
//      "}")
    val schema = validatorFactory.getSchema(getClass.getClassLoader.getResourceAsStream("wflowcfg-schema.json"))

    println("*********step3**********")
    val messages = schema.validate(objectMapper.readTree(" \"cone\" "))
    //assertEquals(1, messages.size())

    val message = messages.iterator().next()
    println(message.getMessage)
    assertEquals("$: enumName is Cone !", message.getMessage())


    //
    println("END: WorkflowConfigValidator")

    // based on the keyword (or key in the yaml) define validator metaschema
    // once keyword identified in yaml, constructs newValidator
    //   ((at that time it is possible to verify certain keys/types valid or not))
    // Validator constructor will be called once above newValidator is satisfied
    //   ((some value types can be validated as well as cross field value validation))
    // Once above validator is constructed without field value errors
    // validate method will be called
  }


  def main(args: Array[String]): Unit = {
    //main_default(args)
    main_mbr(args)
    //main_custom(args)
  }


}
