package com.drake

import javax.script.{Compilable, CompiledScript}

import scala.tools.nsc.Settings
import scala.tools.nsc.interpreter.{IMain, JPrintWriter}

import org.apache.spark.sql.types.{StringType, StructField, StructType}


class Evaluator {

  // Create IMain instance when created
  val settings = new Settings()
  settings.usejavacp.value = true
  val writer = new JPrintWriter(Console.out, true)
  val engine = new IMain(settings, writer)
  val compiler = engine.asInstanceOf[Compilable]

  var inputVal : Int = _
  var compiledObj : CompiledScript = _

  // compile given script
  def compileScript(givenCode : String) {
    compiledObj = compiler.compile(givenCode)
  }

  // evaluate
  def evalCompiled(): Unit = {
    compiledObj.eval()
  }

  // evaluate
  def evalCompiledSchema(): AnyRef = {
    compiledObj.eval()
  }

  // set input value
  def setInput(givenInput:Int) {
    inputVal = givenInput
  }

  // bind input variable
  def bindInput() {
    engine.bind("inputVal", "Int", inputVal)
  }

}

object IMainTest {

  def prepareClass(): String = {
    s"""
       |import org.apache.spark.sql.types.{StringType, StructField, StructType}
       |
       |def getSchema(): StructType = {
       |  val schema = StructType(
       |    Array(StructField("transactionId", StringType),
       |      StructField("customerId", StringType),
       |      StructField("itemId", StringType),
       |      StructField("amountPaid", StringType)))
       |
       |  schema
       |}
       |
       |getSchema()
       |
       |""".stripMargin
  }

  def main(args:Array[String]): Unit = {
    // create an instance
    val evaluator = new Evaluator()

    // first set input value to 3 and do evaluation
    evaluator.setInput(3)
    evaluator.bindInput()
    evaluator.compileScript("def f(x:Int):Int=x+1; println(f(inputVal))")
    evaluator.evalCompiled()

    // let's change input value and re-evaluate
    evaluator.setInput(5)
    evaluator.bindInput()
    evaluator.evalCompiled()


    evaluator.compileScript(prepareClass)
    val xref = evaluator.evalCompiledSchema()
    println(xref)

    val schema = StructType(
      Array(StructField("transactionId", StringType),
        StructField("customerId", StringType),
        StructField("itemId", StringType),
        StructField("amountPaid", StringType)))

    //println(schema)

  }
}