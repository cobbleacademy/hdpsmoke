package com.drake.builder

import com.drake.function.Func.{liststring, uuid}
import com.drake.{BaseTrait, PropsUtil, QueryParserHelper, SparkHelper}
import com.drake.model.Model.{LabeledDataFrame, PlanCache, Step}
import com.drake.offset.OffsetStore
import com.drake.reader.WholeFileXMLReaderHelper
import com.drake.schema.SchemaBuilderHelper
import com.drake.status.StatusBuilderHelper
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.execution.datasources.hbase.HBaseTableCatalog
import org.apache.spark.sql.streaming.{OutputMode, ProcessingTime, Trigger}
import org.apache.spark.sql.types.StructType

/**
  * A Builder class for Reader Editor and Write for DAG
  */
object ReadEditWriteHelper extends BaseTrait {


  /**
    * Persists results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param schema
    * @param filter
    * @param as
    * @param startDataFrame
    * @return
    */
  def reader(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], schema: Option[StructType], filter: String, as: String, startDataFrame: DataFrame): DataFrame = {
    //
    val ss = startDataFrame.sparkSession
    var readerDfVar: DataFrame = startDataFrame

    //
    val formatDf = ss
      .read
      .format(format)
    //
    val schemaDf = if (schema.isDefined) formatDf.schema(schema.get) else formatDf
    //
    val inStreamDf = schemaDf
      .options(startOpts)
      .load()

    //
    val filterDf = if (!filter.isEmpty) inStreamDf.filter(filter) else inStreamDf
    //
    val asDf = if (!as.isEmpty) filterDf.as(as) else filterDf
    //
    readerDfVar = asDf

    //
    val readerDf = readerDfVar

    //
    readerDf
  }


  /**
    * Read source in streaming fashion
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param planCache
    * @return
    */
  def streamingReader(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], planCache: PlanCache): DataFrame = {
    //
    val sparkSession = SparkHelper.getSparkSession()
    var streamDf: DataFrame = null

    //
    //
    streamDf =
      if ("kafka".equals(format)) {

        // merge bot main and workflow options
        // which includes offsets store
        val mergedOpts = PropsUtil.getKafkaConsumerParams(startOpts) ++ startOpts

        //
        sparkSession
          .readStream
          .options(mergedOpts)
          .format(format)
          .load()
          .selectExpr(startAttrs.getOrElse("kafkaSelectExpr", "*"))
      } else {

        //
        sparkSession
          .readStream
          .options(startOpts)
          .format(format)
          .schema(SchemaBuilderHelper.createSchema(startAttrs)) // create schema
          .load()
      }

    //
    streamDf
  }



  /**
    * Read source in batch fashion
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param planCache
    * @return
    */
  def batchReader(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], planCache: PlanCache): DataFrame = {
    //
    val sparkSession = SparkHelper.getSparkSession()
    var streamDf: DataFrame = null

    //
    //
    if ("wholefile".equals(format)) {

      // get wholefile format
      val wholeFilePath = startOpts.getOrElse("path", "")
      val wholeFileFormat = startOpts.getOrElse("fileFormat", "text")
      val wholeFileContent = startOpts.getOrElse("contentType", "xml")
      val xmlRootTag = startOpts.getOrElse("xmlRootTag", "root")
      val xmlElementTag = startOpts.getOrElse("xmlElementTag", "")
      val xmlArrayTransformTags = startOpts.getOrElse("xmlArrayTransformTags", "")

      //
      if ("text".equals(wholeFileFormat)) {

        //
        val wholeFileRDD = sparkSession
          .sparkContext
          .wholeTextFiles(wholeFilePath)

        //
        streamDf = WholeFileXMLReaderHelper.createWholeFileXMLDataFrame(wholeFileRDD, startOpts).withColumn("input_file_name", input_file_name())

      } else if ("sequence".equals(wholeFileFormat)) {

      }

    } else if ("hive".equals(format)) {
      //
      val sqlVal = BuilderHelper.loadSqlString(startAttrs, planCache, true)
      val parSql = QueryParserHelper.replaceSessionArgs(sqlVal, planCache.planData)
      println("before sql: " + sqlVal)
      println("after sql: " + parSql)
      streamDf = sparkSession.sql(parSql)

    } else if ("fixedwidth".equals(format)) {

      //
      // read fixedwidth files
      //
      val fixedRawDf = sparkSession.read
        .options(startOpts)
        .text()
        .filter(r => !r.getAs[String](0).trim.isEmpty)

      // return
      streamDf = fixedRawDf

    } else if ("hbase".equals(format)) {

      //
      val hbaseDf = sparkSession
        .read
        .format("org.apache.spark.sql.execution.datasources.hbase")
        .option(HBaseTableCatalog.tableCatalog, SchemaBuilderHelper.createCatalog(startAttrs))
        //.option("partitionColumn", "owner_id")
        //.option("lowerBound", 1)
        //.option("upperBound", 10000)
        .load()

      //hbaseDf.printSchema()
      //hbaseDf.show(false)

      // return
      streamDf = hbaseDf

    } else if ("phoenix".equals(format)) {

      //
      val phoenixDf = sparkSession
        .read
        .format("org.apache.phoenix.spark")
        .options(startOpts)
        .load()

      // return
      streamDf = phoenixDf

    } else if ("jdbc".equals(format)) {

      //
      val jdbcDf = sparkSession
        .read
        .format(format)
        .options(startOpts)
        .load()

      // return
      streamDf = jdbcDf

    } else if ("kafka".equals(format)) {

      //
      val groupId = startOpts.getOrElse("groupId", PropsUtil.propValue("kafka.group-id"))

      //
      val offsetStore = OffsetStore
        .builder()
        .config("zkHosts", PropsUtil.propValue("zookeeper.hosts"))
        .config("zkBasePath", PropsUtil.propValue("zookeeper.base.path") + "/" + groupId
          + "/offsets/" + startOpts.getOrElse("subscribe", PropsUtil.propValue("kafka.subscribe")))

      // merge both main and workflow options
      val mergedOpts = PropsUtil.getKafkaConsumerParams(startOpts) ++ startOpts

      //
      val kafkaRawDf = sparkSession
        .read
        .format(format)
        .options(mergedOpts)
        .load()

      val kgrpDf = kafkaRawDf.groupBy("topic", "partition")
          .agg((max("offset") + 1) as "maxoffset")

      //
      val kkvDf = kgrpDf.select(col("topic"), concat(lit("\""), col("partition"), lit("\":"), col("maxoffset")) as "kv")

      //
      val klistDf = kkvDf.groupBy("topic").agg(liststring(collect_list("kv")) as "list")

      //
      val koffsetDf = klistDf.select(col("topic") as "topic", concat(lit("{\""), col("topic"), lit("\":{"), col("list"), lit("}}") as "offset" ))
      if (PropsUtil.showData()) koffsetDf.show(false)

      koffsetDf
          .collect
          .map(f => (f.getAs[String]("topic"), f.getAs[String]("offset")))
          .foreach(f => OffsetStore.getOffsetStore.appendOffsetGroup(f._2, groupId))

      //
      val kafkaDf = kafkaRawDf.selectExpr(startAttrs.getOrElse("kafkaSelectExpr", "*"))

      // return
      streamDf = kafkaDf

    } else {

      //
      val fileFormatDf = sparkSession.read
        .options(startOpts)
        .format(format) //"org.apache.spark.sql.execution.datasources.csv.CSVFileFormat")
      //.schema(SchemaBuilderHelper.createSchema(stepAttrs)) // create schema
      //.load()
      //.csv(stepAttrs.getOrElse("path", ""))

      //
      val fileSchemaDf =
        if (!startAttrs.getOrElse("schemaCommand", "").isEmpty)
          fileFormatDf.schema(SchemaBuilderHelper.createSchema(startAttrs))
        else
          fileFormatDf

      //
      val fileStreamDf = fileSchemaDf
        .load()

      //
      fileStreamDf.printSchema()
      fileStreamDf.show(2, false)

      // return
      streamDf = fileStreamDf
    }

    //
    streamDf
  }


  /**
    * Returns whether multi reader enabled or not
    * @param startAttrs
    * @return
    */
  def isMultiReadEnabled(startAttrs: Map[String, String]): Boolean = {
    (startAttrs.isDefinedAt("multiAttrsRefTempView") || startAttrs.isDefinedAt("multiOptsRefTempView"))
  }


  /**
    * Read source in batch fashion
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param planCache
    * @return
    */
  def multiReader(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], planCache: PlanCache): Seq[LabeledDataFrame] = {
    //
    val ss = SparkHelper.getSparkSession()
    var lblDfSeqDfVar: Seq[LabeledDataFrame] = Seq[LabeledDataFrame]()

    //
    val multiOptsRefTempView = startAttrs.getOrElse("multiOptsRefTempView","")
    val multiAttrsRefTempView = startAttrs.getOrElse("multiAttrsRefTempView","")
    val multiAttrsAsOpts = startAttrs.getOrElse("multiAttrsAsOpts","false").toBoolean

    //
    if (!multiAttrsRefTempView.isEmpty) {
      //
      val attrDf = ss.sql(s"select * from $multiAttrsRefTempView")
      val attrArray = attrDf
        .rdd
        .collect()
        .map(row => Map(attrDf.columns.zip(row.toSeq.map(a => a.toString)): _*))

      attrArray.foreach(a => {
        //
        val tempvw = a.getOrElse("tempView", "")
        val mergedAttrs = startAttrs ++ a
        val mergeOpts = if (multiAttrsAsOpts) mergedAttrs else startOpts
        val singleDf = batchReader(format, mergedAttrs, mergeOpts, planCache)
        singleDf.createOrReplaceTempView(tempvw)
        lblDfSeqDfVar = lblDfSeqDfVar :+ LabeledDataFrame(tempvw, singleDf)
      })

    }

    //
    if (!multiOptsRefTempView.isEmpty) {
      //
      val optDf = ss.sql(s"select * from $multiOptsRefTempView")
      val optArray = optDf
        .rdd
        .collect()
        .map(row => Map(optDf.columns.zip(row.toSeq.map(a => a.toString)): _*))

      optArray.foreach(o => {
        //
        val tempvw = o.getOrElse("tempView", "")
        val mergedOpts = startOpts ++ o
        val singleDf = batchReader(format, startAttrs, mergedOpts, planCache)
        singleDf.createOrReplaceTempView(tempvw)
        lblDfSeqDfVar = lblDfSeqDfVar :+ LabeledDataFrame(tempvw, singleDf)
      })

    }


    //
    lblDfSeqDfVar
  }


  /**
    * Persists the results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param outputFrame
    */
  def streamingWriter(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], outputFrame: DataFrame): Unit = {

    //
    if (startAttrs.get("partitionBy").isDefined) {

      val partCols = startAttrs.getOrElse("partitionBy", "").split(",")
      //
      val outQuery = outputFrame
        .withColumn("uuid", uuid())
        .writeStream
        .format(format)
        .options(startOpts)
        .partitionBy(partCols: _*)
        .trigger(ProcessingTime(startAttrs.getOrElse("trigger", "")))
        .start()

    } else {
      //
      val outQuery = outputFrame
        .withColumn("uuid", uuid())
        .writeStream
        .format(format)
        .options(startOpts)
        .trigger(ProcessingTime(startAttrs.getOrElse("trigger", "")))
        .start()
    }

  }


  /**
    * Persists the results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param outputFrame
    */
  def streamingWriter1(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], outputFrame: DataFrame): Unit = {

    //
    val outputModeEval = startAttrs.getOrElse("outputMode", "append")
    val outputMode: OutputMode =
      outputModeEval match {
        case "complete" => OutputMode.Complete()
        case "update" => OutputMode.Update()
        case _ => OutputMode.Append()
      }
    //
    val triggerModeEval = startAttrs.getOrElse("triggerMode", "time")
    //
    val triggerDefined = startAttrs.get("trigger").isDefined
    val triggerEval = startAttrs.getOrElse("trigger", "")
    //
    val numCoalesceEval = startAttrs.getOrElse("numCoalesce", "0").toInt
    val numRepartsEval = startAttrs.getOrElse("numRepartitions", "0").toInt
    val repartsByEval = startAttrs.get("repartitionBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val bucketNumEval = startAttrs.getOrElse("numBuckets", "0").toInt
    //
    val bucketByEval = startAttrs.get("bucketBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val sortByEval = startAttrs.get("sortBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val partColsEval = startAttrs.get("partitionBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    logger.info("numCoalesceEval: " + numCoalesceEval)
    logger.info("numRepartsEval: " + numRepartsEval)
    logger.info("repartsByEval: " + repartsByEval + " size: " + repartsByEval.size)
    logger.info("bucketNumEval: " + bucketNumEval)
    logger.info("bucketByEval: " + bucketByEval + " size: " + bucketByEval.size)
    logger.info("sortByEval: " + sortByEval + " size: " + sortByEval.size)
    logger.info("partColsEval: " + partColsEval + " size: " + partColsEval.size)

    //
    val repartsFrame =
      if (numRepartsEval > 0)
        if (repartsByEval.size > 0) outputFrame.repartition(numRepartsEval, repartsByEval.map(col): _*) else outputFrame.repartition(numCoalesceEval)
      else
        if (repartsByEval.size > 0) outputFrame.repartition(repartsByEval.map(col): _*) else outputFrame

    //
    val coalesceFrame = if (numCoalesceEval > 0) repartsFrame.coalesce(numCoalesceEval) else repartsFrame

    //
    val mergedOpts = PropsUtil.getKafkaProducerParams(startOpts) ++ startOpts

    //
    val formatStream = coalesceFrame
      .writeStream
      .outputMode(outputMode)
      .format(format)
      .options(mergedOpts)

    //
    val partStream =
      if (partColsEval.size > 0)
        formatStream.partitionBy(partColsEval: _*)
      else
        formatStream

    //
    val triggerStream =
      if (triggerDefined) {
        triggerEval match {
          case "once" => partStream.trigger(Trigger.Once())
          case "" => partStream
          case _ => {
            if ("checkpoint".equalsIgnoreCase(triggerModeEval))
              partStream.trigger(Trigger.Continuous(triggerEval))
            else
              partStream.trigger(Trigger.ProcessingTime(triggerEval))
          }
        }

      } else {
        partStream
      }

    triggerStream.start()

  }


  /**
    * Persists the results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param outputFrame
    */
  def pathWriter(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], outputFrame: DataFrame): Unit = {
    //
    val saveModeEval = startAttrs.getOrElse("saveMode", "Append")
    val editMode: SaveMode = SaveMode.valueOf(saveModeEval)
    //
    val numCoalesceEval = startAttrs.getOrElse("numCoalesce", "0").toInt
    val numRepartsEval = startAttrs.getOrElse("numRepartitions", "0").toInt
    val repartsByEval = startAttrs.get("repartitionBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val bucketNumEval = startAttrs.getOrElse("numBuckets", "0").toInt
    //
    val bucketByEval = startAttrs.get("bucketBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val sortByEval = startAttrs.get("sortBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val partColsEval = startAttrs.get("partitionBy").fold(Array[String]()) {
      _.split(",")
    }
    //
    val saveAsTable = startAttrs.getOrElse("saveAsTable", "")
    //
    logger.info("numCoalesceEval: " + numCoalesceEval)
    logger.info("numRepartsEval: " + numRepartsEval)
    logger.info("repartsByEval: " + repartsByEval + " size: " + repartsByEval.size)
    logger.info("bucketNumEval: " + bucketNumEval)
    logger.info("bucketByEval: " + bucketByEval + " size: " + bucketByEval.size)
    logger.info("sortByEval: " + sortByEval + " size: " + sortByEval.size)
    logger.info("partColsEval: " + partColsEval + " size: " + partColsEval.size)
    logger.info("saveAsTable: " + saveAsTable)

    //
    val repartsFrame =
      if (numRepartsEval > 0)
        if (repartsByEval.size > 0) outputFrame.repartition(numRepartsEval, repartsByEval.map(col): _*) else outputFrame.repartition(numCoalesceEval)
      else if (repartsByEval.size > 0) outputFrame.repartition(repartsByEval.map(col): _*) else outputFrame

    //
    val coalesceFrame = if (numCoalesceEval > 0) repartsFrame.coalesce(numCoalesceEval) else repartsFrame

    //
    val formatWriter = coalesceFrame
      .write
      .options(startOpts)
      .format(format)

    //
    val bucketWriter =
      if (bucketNumEval > 0)
        if (bucketByEval.size == 1)
          formatWriter.bucketBy(bucketNumEval, bucketByEval(0))
        else
          formatWriter.bucketBy(bucketNumEval, bucketByEval(0), bucketByEval.drop(1): _*)
      else
        formatWriter

    //
    val sortWriter =
      if (sortByEval.size > 0)
        if (sortByEval.size == 1)
          bucketWriter.sortBy(sortByEval(0))
        else
          bucketWriter.sortBy(sortByEval(0), sortByEval.drop(1): _*)
      else
        bucketWriter

    //
    val partWriter =
      if (partColsEval.size > 0)
        sortWriter.partitionBy(partColsEval: _*)
      else
        sortWriter

    //
    val modeWriter = partWriter.mode(editMode)

    //
    if (!saveAsTable.isEmpty)
      modeWriter.insertInto(saveAsTable)
    else
      modeWriter.save()

  }


  /**
    * Persists the results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param outputFrame
    * @param planCache
    */
  def batchWriter(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], outputFrame: DataFrame, planCache: PlanCache): Unit = {
    //
    val saveModeEval = startAttrs.getOrElse("saveMode", "Append")
    val saveMode: SaveMode = SaveMode.valueOf(saveModeEval)
    val ss: SparkSession = outputFrame.sparkSession

    //
    val sqlHive = BuilderHelper.loadSqlString(startAttrs, planCache, true).trim

    //
    if (PropsUtil.printSchema()) outputFrame.printSchema()
    if (PropsUtil.showData()) outputFrame.show(false)


    if ("hbase".equals(format)) {

      //
      val outQuery = outputFrame
        .write
        .format("org.apache.spark.sql.execution.datasources.hbase")
        .option(HBaseTableCatalog.tableCatalog, SchemaBuilderHelper.createCatalog(startAttrs))
        .option(HBaseTableCatalog.newTable, "5")
        .save()

    } else if ("hive".equals(format) && sqlHive.length > 0) {
      //
      if (startAttrs.get("currentTempView").isDefined)
        outputFrame.createOrReplaceTempView(startAttrs.getOrElse("currentTempView", ""))
      ss.sql(sqlHive)

    } else if ("jdbc".equals(format)) {

      //
      val outQuery = outputFrame
        .write
        .format(format)
        .options(PropsUtil.getPassowrdOptions(startOpts, startAttrs))
        .mode(saveMode)
        .save()

    } else {
      //
      pathWriter(format, startAttrs, startOpts, outputFrame)
    }

    // Refresh hive meta info
    if ("true".equals(startAttrs.getOrElse("hiveMetaRepair", "false"))) {
      //
      ss.sql("msck repair table " + startAttrs.getOrElse("db", "") + "." + startAttrs.getOrElse("table", "."))
    }


  }



  /**
    * Returns whether multi writer enabled or not
    *
    * @param startAttrs
    * @return
    */
  def isMultiWriterEnabled(startAttrs: Map[String, String]): Boolean = {
    (startAttrs.isDefinedAt("multiAttrsRefTempView") || startAttrs.isDefinedAt("multiOptsRefTempView"))
  }



  /**
    * Persists the results generated during DAG execution
    *
    * @param format
    * @param startAttrs
    * @param startOpts
    * @param outputFrame
    * @param planCache
    */
  def multiWriter(format: String, startAttrs: Map[String, String], startOpts: Map[String, String], outputFrame: DataFrame, planCache: PlanCache): Unit = {
    //
    val ss = outputFrame.sparkSession

    //
    val multiOptsRefTempView = startAttrs.getOrElse("multiOptsRefTempView","")
    val multiAttrsRefTempView = startAttrs.getOrElse("multiAttrsRefTempView","")
    val multiAttrsAsOpts = startAttrs.getOrElse("multiAttrsAsOpts","false").toBoolean
    val multiPathRefKeyCol = startAttrs.getOrElse("multiPathRefKeyCol","key")
    val multiPathSqlKeyCol = startAttrs.getOrElse("multiPathSqlKeyCol","key")

    //
    if (!multiAttrsRefTempView.isEmpty) {
      //
      val attrDf = ss.sql(s"select * from $multiAttrsRefTempView")
      val attrArray = attrDf
        .rdd
        .collect()
        .map(row => Map(attrDf.columns.zip(row.toSeq.map(a => a.toString)): _*))

      attrArray.foreach(a => {
        //
        val tempvw = a.getOrElse("tempView", "")
        val mergedAttrs = startAttrs ++ a
        val mergedOpts = if (multiAttrsAsOpts) mergedAttrs else startOpts
        val singleDf = ss.sql(s"select * from $tempvw")
        batchWriter(format, startAttrs, mergedOpts, singleDf, planCache)
      })

    }

    //
    if (!multiOptsRefTempView.isEmpty) {
      //
      val optDf = ss.sql(s"select * from $multiOptsRefTempView")
      val optArray = optDf
        .rdd
        .collect()
        .map(row => Map(optDf.columns.zip(row.toSeq.map(a => a.toString)): _*))

      optArray.foreach(o => {
        //
        val tempvw = o.getOrElse("tempView", "")
        val mergedOpts = startOpts ++ o

        //
        var partDf: DataFrame = null
        if (startAttrs.isDefinedAt("multiPathRefKeyCol"))
          partDf = outputFrame.filter(col(multiPathSqlKeyCol) === o.getOrElse(multiPathRefKeyCol, "")).drop(col(multiPathSqlKeyCol))
        else
          partDf = ss.sql(s"select * from $tempvw")

        //
        batchWriter(format, startAttrs, mergedOpts, partDf, planCache)
      })

    }


  }



}
