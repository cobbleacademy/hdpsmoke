package com.drake.builder

import java.util.Properties

import com.drake._
import com.drake.broadcast.BroadcastWrapper
import com.drake.function.Func
import com.drake.function.Func.{jsonxml, uuid, xmltojson}
import com.drake.model.Model.{DFTransComp, PlanCache}
import com.drake.reader.StaticSourceReader
import com.drake.schema.SchemaBuilder.{DEFAULT_SCHEMA_BUILDER, FIXED_WIDTH_SCHEMA_BUILDER}
import com.drake.storage.{PlanStorage, SessionStorage, StorageHelper}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
  * A common helper class for all functions needed by any Builder - Reader/Editor/Writer
  */
object BuilderHelper extends BaseTrait {


  /**
    * Executes the trigger and saves the corresponding output in session map under triggerStep group
    *
    * @param triggerStep
    * @param commandPath
    * @param commandName
    * @param funcName
    * @param procName
    */
  def executeTriggerCondition(triggerStep: String, commandPath: String, commandName: String, funcName: String, procName: String): Unit = {

    //
    val sessDataMap = SessionDataHelper.getSessionData()
    val stepMap: mutable.Map[String, String] = mutable.Map("success" -> "false")
    sessDataMap += (triggerStep -> stepMap)


    // Run post process scripts
    import sys.process._
    val cmd = commandPath + "/" + commandName
    logger.info("running trigger " + triggerStep + " and script: " + cmd)
    val pseq = Seq(cmd, funcName, procName)
    val shellResult = Process(pseq).lineStream //cmd.!!;val arr = shellResult.split("\\n")
    shellResult.foreach(x => {
      logger.debug(x)
      val arr = x.split("=")
      stepMap += (arr(0) -> arr(1))
    })
    logger.info("Trigger status.." + triggerStep)
    stepMap.foreach(println)

  }


  /**
    * Builds the schema from the given code from file
    *
    * @param forName
    * @param schemaAttrs
    * @return
    */
  def createSchema(forName: String, schemaAttrs: Map[String, String]): StructType = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", DEFAULT_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(forName.getClass).newInstance(forName).asInstanceOf[ {def buildSchema(schemaAttrs: Map[String, String]): StructType}]

    // Default Schema Build
    val schema = schemaKlass.buildSchema(schemaAttrs)
    logger.debug(schema)

    //
    schema
  }


  /**
    * Builds the FixedWidths from the given code from file
    *
    * @param forName
    * @param schemaAttrs
    * @return
    */
  def createFixedWidths(forName: String, schemaAttrs: Map[String, String]): Seq[Int] = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", FIXED_WIDTH_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(forName.getClass).newInstance(forName).asInstanceOf[ {def buildFixedWidths(schemaAttrs: Map[String, String]): Seq[Int]}]

    // Default Schema Build
    val fixedLengths = schemaKlass.buildFixedWidths(schemaAttrs)
    logger.debug("createFixedWidths" + fixedLengths)

    //
    fixedLengths
  }


  /**
    * Returns Function from the schema configuration file, this returned function is ready to be executed on data
    *
    * @param forName
    * @param schemaAttrs
    * @return
    */
  def createContainsSchemaFunction(forName: String, schemaAttrs: Map[String, String]): (String => Boolean) = {

    // instantiate and delegate to Schema class
    val klassName = schemaAttrs.getOrElse("schemaCommand", FIXED_WIDTH_SCHEMA_BUILDER)
    val schemaKlass = Class.forName(klassName).getConstructor(forName.getClass).newInstance(forName).asInstanceOf[ {def buildSchemaConformanceFunc(schemaAttrs: Map[String, String]): (String => Boolean)}]

    // Default Schema Build
    val funcContainsSchema = schemaKlass.buildSchemaConformanceFunc(schemaAttrs)
    logger.debug("createContainsSchemaFunction" + funcContainsSchema)

    //
    funcContainsSchema
  }


  /**
    * Parses the input data into multiple string based on sequence of fixed widths
    *
    * @param line
    * @param lengths
    * @return
    */
  def parseFixedWidths(line: String, lengths: Seq[Int]): Seq[String] = {
    lengths.indices.foldLeft((line, Array.empty[String])) { case ((rem, fields), idx) =>
      val len = lengths(idx)
      val fld = rem.take(len).trim
      (rem.drop(len), fields :+ fld)
    }._2
  }


  /**
    * Returns DataFrame after processing category
    *
    * @param startDF
    * @param inclAttrs
    * @return
    */
  def includeAttributeTransform(inclAttrs: Map[String, String], startDF: DataFrame, planCache: PlanCache): DataFrame = {
    //
    //val sessDataMap = SessionDataHelper.getSessionData()
    val inclColsMap: mutable.Map[String, String] = mutable.Map[String, String]()

    //
    // include process
    //
    inclAttrs.map(x => {
      val key = x._1
      var value = x._2
      value = StorageHelper.parentageLookup(value, planCache.planData)
      inclColsMap += (key -> value)
    })
    //
    val inclDf = inclColsMap.foldLeft(startDF)((df, c) =>
      df.withColumn(c._1, lit(c._2))
    )

    //
    if (PropsUtil.printSchema()) inclDf.printSchema()
    if (PropsUtil.showData()) inclDf.show(false)
    inclDf
  }


  /**
    * Returns DataFrame transform options model object
    * @param stepName
    * @param stepLabel
    * @param startAttrs
    * @param planCache
    * @return
    */
  def convertToDFTransOpt(stepName: String, stepLabel: String, startAttrs: Map[String, String], planCache: PlanCache): DFTransComp = {
    //
    var reslt: DFTransComp = null

    val name = stepName
    val label = if (!stepLabel.isEmpty) stepLabel else startAttrs.getOrElse("label", "")
    val currentTempView = startAttrs.getOrElse("currentTempView", "")
    val tempView = startAttrs.getOrElse("tempView", "")
    val cache = startAttrs.getOrElse("cache", "false").toBoolean
    val forceCache = startAttrs.getOrElse("forceCache", "false").toBoolean
    val cacheStorageLevel = startAttrs.getOrElse("cacheStorageLevel", "MEMORY_ONLY")
    val dataCache = startAttrs.getOrElse("dataCache", "false").toBoolean
    val cacheScope = startAttrs.getOrElse("cacheScope", "session")
    val frequencyCache = startAttrs.getOrElse("frequencyCache", "false").toBoolean
    val frequencyDuration = startAttrs.getOrElse("frequencyDuration", "-1").toLong
    val removeCacheLabels = startAttrs.getOrElse("removeCacheLabels", "")
    val labelAliasEnabled = startAttrs.getOrElse("labelAliasEnabled", "false").toBoolean
    val labelAliasScope = startAttrs.getOrElse("labelAliasScope", "session")
    val replaceLabelEnabled = startAttrs.getOrElse("replaceLabelEnabled", "false").toBoolean
    val replaceLabelWith = startAttrs.getOrElse("replaceLabelWith", "")
    val skipLabelEnabled = startAttrs.getOrElse("skipLabelEnabled", "false").toBoolean
    val skipLabelWith = startAttrs.getOrElse("skipLabelWith", "")
    val skipLabelProcess = if (skipLabelEnabled && !skipLabelWith.isEmpty) true else false
    val aliasLabelWith = if (skipLabelProcess) skipLabelWith else replaceLabelWith
    var aliasDataFrame: Option[DataFrame] = None
    if (!aliasLabelWith.isEmpty) aliasDataFrame = StorageHelper.getAliasDataFrame(aliasLabelWith, planCache.aliasDataFrames)
    logger.info(s"printed skipLabelProcess: $skipLabelProcess skipLabelEnabled: $skipLabelEnabled skipLabelWith: $skipLabelWith replaceLabelEnabled: $replaceLabelEnabled replaceLabelWith: $replaceLabelWith aliasLabelWith: $aliasLabelWith")

    reslt = DFTransComp(name, label, currentTempView, tempView, cache, forceCache, cacheStorageLevel, dataCache, cacheScope, frequencyCache, frequencyDuration, removeCacheLabels, labelAliasEnabled, labelAliasScope, aliasDataFrame, replaceLabelEnabled, replaceLabelWith, skipLabelEnabled, skipLabelWith, skipLabelProcess)


    //
    reslt
  }


  /**
    * Apply current temp view
    * @param startAttrs
    * @param startDF
    */
  def applyCurrentTempView(startAttrs: Map[String, String], startDF: DataFrame): Unit = {
    if (startAttrs.get("currentTempView").isDefined) startDF.createOrReplaceTempView(startAttrs.getOrElse("currentTempView",""))
  }

  /**
    * Apply temp view
    * @param startAttrs
    * @param startDF
    */
  def applyTempView(startAttrs: Map[String, String], startDF: DataFrame): Unit = {
    if (startAttrs.get("tempView").isDefined) startDF.createOrReplaceTempView(startAttrs.getOrElse("tempView",""))
  }

  /**
    * set cache on post dataframe generation
    * @param transComp
    * @param dataFrame
    * @param planCache
    * @return
    */
  def applyCacheAfter(transComp: DFTransComp, dataFrame: DataFrame, planCache: PlanCache): DataFrame = {
    //
    var resultDF: DataFrame = dataFrame
    val isStreaming = dataFrame.isStreaming

    //
    val postDf =
      if (isStreaming) {
        dataFrame
      } else {
        if (transComp.cache || transComp.forceCache || (transComp.frequencyCache && transComp.frequencyCacheDuration > 0))
          dataFrame.persist(StorageLevel.fromString(transComp.cacheStorageLevel))
        else
          dataFrame
      }

    //
    if (!isStreaming) {
      if (transComp.cache || transComp.forceCache || (transComp.frequencyCache && transComp.frequencyCacheDuration > 0)) {
        //
        if (transComp.forceCache) {
          logger.info(s"printed forceCache: cacheStorageLevel: ${transComp.cacheStorageLevel} in scope: ${transComp.cacheScope}")
          if ("session".equalsIgnoreCase(transComp.cacheScope)) SessionStorage.addCache(transComp.name, transComp.label, postDf)
          else if ("plan".equalsIgnoreCase(transComp.cacheScope)) PlanStorage.addStepPlanCache(transComp.name, postDf, planCache)
        }
        //
        if (transComp.frequencyCache && transComp.frequencyCacheDuration > 0)
          SessionStorage.addFrequencyCache(transComp.name, transComp.label, postDf, transComp.frequencyCacheDuration)
      }
    }

    if (!transComp.removeCacheLabels.isEmpty) transComp.removeCacheLabels.split(",").map(SessionStorage.removeCache(_))
    //
    if (!transComp.tempView.isEmpty) postDf.createOrReplaceTempView(transComp.tempView)
    //
    if (transComp.labelAliasEnabled)
      if ("session".equalsIgnoreCase(transComp.labelAliasScope)) SessionStorage.addStepSessionData(transComp.name, postDf)
      else if ("plan".equalsIgnoreCase(transComp.labelAliasScope)) PlanStorage.addStepPlanCache(transComp.name, postDf, planCache)
    //
    if (transComp.dataCache)
      if ("session".equalsIgnoreCase(transComp.cacheScope)) SessionStorage.addStepSessionData(transComp.name, postDf)
      else if ("plan".equalsIgnoreCase(transComp.cacheScope)) PlanStorage.addStepPlanCache(transComp.name, postDf, planCache)


    //
    resultDF = postDf

    //
    resultDF
  }

  /**
    * Returns String after loadeding either from raw or file path
    * @param startAttrs
    * @param planCache
    * @param repl
    * @return
    */
  def loadSqlString(startAttrs: Map[String, String], planCache: PlanCache, repl: Boolean = false): String = {
    //
    var sqlStr = ""

    //
    if (startAttrs.isDefinedAt("sqlPath")) {
      val path = startAttrs.getOrElse("sqlPath", "")
      val replPath = QueryParserHelper.replaceSessionArgs(path, planCache.planData)
      //
      if (!replPath.isEmpty) sqlStr = PropsUtil.loadFileContent(replPath)
    } else {
      sqlStr = startAttrs.getOrElse("sql", "")
    }

    //
    if (repl)
      sqlStr = QueryParserHelper.replaceSessionArgs(sqlStr, planCache.planData)

    logger.info(s"loadSqlString: $sqlStr")

    //
    sqlStr
  }


  /**
    * Returns DataFrame after processing category
    * @param forName
    * @param occurrence
    * @param startAttrs
    * @param startDF
    * @param planCache
    * @return
    */
  def categoryTransform(forName: String, occurrence: Int = 0, startAttrs: Map[String, String], startDF: DataFrame, planCache: PlanCache): DataFrame = {
    //
    val ss = startDF.sparkSession
    var categoryDfVar: DataFrame = startDF
    import ss.implicits._

    //
    Func.registerUUID(startDF)

    //
    val currCategory = startAttrs.getOrElse("category", "")
    val currCategoryKey = forName + "_" + currCategory + "_" + occurrence

    //
    if (!currCategory.isEmpty) {
      //
      var categoryDfCurrVar: DataFrame = startDF

      val repartBy = startAttrs.getOrElse("repartitionBy", "")

      if ("sql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, false))
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("replsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("replemptysql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        if (startDF.head(1).isEmpty) categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("createbroadcastjdbc".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        val bcName = startAttrs.getOrElse("broadcastName", "")
        BroadcastWrapper.broadcastJDBCConnection(bcName, forName, (forName + occurrence), startAttrs)
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("createbroadcastjdbcreplsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        val bcName = startAttrs.getOrElse("broadcastName", "")
        BroadcastWrapper.broadcastJDBCConnection(bcName, forName, (forName + occurrence), startAttrs)
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("readbroadcastjdbcreplsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val schema = startDF.schema
        val replSql = loadSqlString(startAttrs, planCache, true)
        val bcName = startAttrs.getOrElse("broadcastName", "")
        val bcJDBCConn = BroadcastWrapper.getJDBCConnectionBroadBroadcast(bcName, forName, (forName + occurrence), startAttrs)
        val rowList = bcJDBCConn.runSql(replSql)
        val spk = startDF.sparkSession
        categoryDfCurrVar = spk.createDataFrame(spk.sparkContext.parallelize(rowList),schema)
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("readjdbcsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val schema = startDF.schema
        val replSql = loadSqlString(startAttrs, planCache, false)
        val driver = startAttrs.getOrElse("driver", "")
        val url = startAttrs.getOrElse("url", "")
        val applyCommit = startAttrs.getOrElse("applyAutoCommit", "true").toBoolean
        val jdbchelper = JDBCManagerHelper(forName, "base", driver, url, applyCommit, new Properties())
        categoryDfCurrVar = jdbchelper.runSql(startDF, replSql)
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("readjdbcreplsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val schema = startDF.schema
        val replSql = loadSqlString(startAttrs, planCache, true)
        val driver = startAttrs.getOrElse("driver", "")
        val url = startAttrs.getOrElse("url", "")
        val applyCommit = startAttrs.getOrElse("applyAutoCommit", "true").toBoolean
        val jdbchelper = JDBCManagerHelper(forName, "base", driver, url, applyCommit, new Properties())
        categoryDfCurrVar = jdbchelper.runSql(startDF, replSql)
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("driverjdbcsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val driver = startAttrs.getOrElse("driver", "")
        val url = startAttrs.getOrElse("url", "")
        val applyCommit = startAttrs.getOrElse("applyAutoCommit", "true").toBoolean
        val jdbchelper = JDBCManagerHelper(forName, "base", driver, url, applyCommit, new Properties())
        //
        val replSql = loadSqlString(startAttrs, planCache, false)
        println(s"printing driverjdbcsql: $replSql")
        jdbchelper.runDriverEditSql(replSql)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("driverjdbcloopoverreplsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val driver = startAttrs.getOrElse("driver", "")
        val url = startAttrs.getOrElse("url", "")
        val applyCommit = startAttrs.getOrElse("applyAutoCommit", "true").toBoolean
        val searchFor = startAttrs.getOrElse("searchFor", "")
        val replaceFor = startAttrs.getOrElse("replaceFor", "")
        val replaceIter = startAttrs.getOrElse("replaceIter", "")
        val jdbchelper = JDBCManagerHelper(forName, "base", driver, url, applyCommit, new Properties())
        //
        val replSql = loadSqlString(startAttrs, planCache, true)
        println(s"printing driverjdbcloopoverreplsql: $replSql")
        jdbchelper.runDriverEditIterSql(replSql, searchFor, replaceFor, replaceIter)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("writebroadcastjdbcloopoverreplsql".equals(currCategory)) {
        applyCurrentTempView(startAttrs, startDF)
        //
        val bcName = startAttrs.getOrElse("broadcastName", "")
        val bcWaveVol = startAttrs.getOrElse("broadcastWaveVol", "")
        val searchFor = startAttrs.getOrElse("searchFor", "")
        val replaceFor = startAttrs.getOrElse("replaceFor", "")
        val replaceIter = startAttrs.getOrElse("replaceIter", "")
        //
        val replSql = loadSqlString(startAttrs, planCache, true)
        //
        val bcJDBCConn = BroadcastWrapper.getJDBCConnectionBroadBroadcast(bcName, forName, (forName + occurrence), startAttrs)
        val repartNum = if ((replaceIter.toInt/bcWaveVol.toInt).toInt > 0) (replaceIter.toInt/bcWaveVol.toInt).toInt else 1
        logger.info(s"printing writebroadcastjdbcloopoverreplsql $replSql == $replaceIter == $repartNum")
        val iterDf = ss.sparkContext.parallelize((1 to replaceIter.toInt).toSeq, repartNum).toDF("iter")

        //
        iterDf.foreachPartition(f => {
          //
          f.foreach(r => {
            val row = r.getInt(0)-1
            val sfrepl = searchFor.replaceAll(replaceFor, row.toString)
            val iterSql = replSql.replace(searchFor, sfrepl)
            logger.info(s"printing calling for $row == $iterSql")
            bcJDBCConn.runEditSql(iterSql)
          })
        })

        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("checkpointreader".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val schema = startDF.schema
        val format = startAttrs.getOrElse("format", "")
        val as = startAttrs.getOrElse("as", "")
        val filter = QueryParserHelper.replaceSessionArgs(startAttrs.getOrElse("filter", ""), planCache.planData)
        ReadEditWriteHelper.pathWriter(format, startAttrs, startAttrs, startDF)
        //
        categoryDfCurrVar = ReadEditWriteHelper.reader(format, startAttrs, startAttrs, Some(schema), filter, as, startDF)

        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("writerreplsql".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val format = startAttrs.getOrElse("format", "")
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        ReadEditWriteHelper.pathWriter(format, startAttrs, startAttrs, categoryDfCurrVar)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("readerreplsql".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val format = startAttrs.getOrElse("format", "")
        val as = startAttrs.getOrElse("as", "")
        val filter = QueryParserHelper.replaceSessionArgs(startAttrs.getOrElse("filter", ""), planCache.planData)
        categoryDfCurrVar = ReadEditWriteHelper.reader(format, startAttrs, startAttrs, None, filter, as, startDF)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("joindataframes".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val lrDefined = if (startAttrs.get("leftFormat").isDefined && startAttrs.get("rightFormat").isDefined) true else false
        if (lrDefined) {
          //
          val leftFormat = startAttrs.getOrElse("leftFormat", "")
          val leftAs = startAttrs.getOrElse("leftAs", "")
          val leftFilter = QueryParserHelper.replaceSessionArgs(startAttrs.getOrElse("leftFilter", ""), planCache.planData)
          val leftStartOpts = startAttrs ++ Map(
            "table" -> startAttrs.getOrElse("leftTable", "")
          )
          val leftDf = ReadEditWriteHelper.reader(leftFormat, startAttrs, startAttrs, None, leftFilter, leftAs, startDF)

          //
          val rightFormat = startAttrs.getOrElse("rightFormat", "")
          val rightAs = startAttrs.getOrElse("rightAs", "")
          val rightFilter = QueryParserHelper.replaceSessionArgs(startAttrs.getOrElse("rightFilter", ""), planCache.planData)
          val rightStartOpts = startAttrs ++ Map(
            "table" -> startAttrs.getOrElse("rightTable", "")
          )
          val rightDf = ReadEditWriteHelper.reader(rightFormat, startAttrs, startAttrs, None, rightFilter, rightAs, startDF)

          //
          val joinCols = startAttrs.getOrElse("joinCols", "").split(",")
          val joinSelCols = startAttrs.getOrElse("joinSelCols", "").split(",")
          categoryDfCurrVar = leftDf.join(rightDf, joinCols).selectExpr(joinSelCols: _*)
        }

        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("multipathwriterreplsql".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val format = startAttrs.getOrElse("format", "")
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        ReadEditWriteHelper.multiWriter(format, startAttrs, startAttrs, categoryDfCurrVar, planCache)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("multireaderreplsql".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val format = startAttrs.getOrElse("format", "")
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        ReadEditWriteHelper.multiReader(format, startAttrs, startAttrs, planCache)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("multiwriterreplsql".equals(currCategory)) {
        //
        applyCurrentTempView(startAttrs, startDF)
        //
        val format = startAttrs.getOrElse("format", "")
        categoryDfCurrVar = ss.sql(loadSqlString(startAttrs, planCache, true))
        ReadEditWriteHelper.multiWriter(format, startAttrs, startAttrs, categoryDfCurrVar, planCache)
        //
        applyTempView(startAttrs, categoryDfCurrVar)

      } else if ("jsonschema".equals(currCategory)) {
        // create schema
        val readerSchema = createSchema(forName, startAttrs)

        //
        val jsonColumn = startAttrs.getOrElse("fromColumn", "")
        val jsonAlias = startAttrs.getOrElse("toAlias", "")

        if ("" != jsonAlias) {
          categoryDfCurrVar = startDF
            .select(from_json(col(jsonColumn), readerSchema).alias(jsonAlias))
            .select(jsonAlias + ".*")
        }

        //
      } else if ("xmlschema".equals(currCategory)) {
        // create schema
        val readerSchema = createSchema(forName, startAttrs)

        //
        val valColumn = startAttrs.getOrElse("fromColumn", "")
        val valAlias = startAttrs.getOrElse("toAlias", "")

        if ("" != valAlias) {
          categoryDfCurrVar = startDF
            .select(from_json(xmltojson(startAttrs)(col(valColumn)), readerSchema).alias(valAlias))
            .select(valAlias + ".*")
        }

        //
      } else if ("fixedwidthschema".equals(currCategory)) {
        // create schema
        StaticSourceReader.broadcastReference(currCategoryKey + "_schema", createSchema(forName, startAttrs))
        //val readerSchema = createSchema(forName, startAttrs)
        val readerSchema: StructType = StaticSourceReader.getBroadcastReferenceData(currCategoryKey + "_schema").asInstanceOf[StructType]
        StaticSourceReader.broadcastReference(currCategoryKey + "_lengths", createFixedWidths(forName, startAttrs))
        //val lengths = createFixedWidths(forName, startAttrs)
        val lengths: List[Int] = StaticSourceReader.getBroadcastReferenceData(currCategoryKey + "_lengths").asInstanceOf[List[Int]]


        // containsFunc takes string(input) and determines whether schema confirms or not
        ///
        ///
        ///
        ///
        val containsFunc = udf {
          new Function1[String, Boolean] with Serializable {

            import scala.reflect.runtime.currentMirror
            import scala.tools.reflect.ToolBox

            lazy val toolbox = currentMirror.mkToolBox()
            lazy val func = {
              println("reflected function") // triggered at every worker
              val schemaCode = PropsUtil.loadContainsSchemaCode(startAttrs.getOrElse("schemaPath", ""))
              toolbox.eval(toolbox.parse(schemaCode)).asInstanceOf[String => Boolean]
            }

            def apply(s: String): Boolean = func(s)
          }
        }
        ///
        ///
        ///
        ///
        val colNames = readerSchema.fieldNames
        val colTypes = readerSchema.fields.map(f => f.dataType)
        val fixedwidthsize = startAttrs.getOrElse("fixedwidthsize", "0").toInt
        logger.warn("Fixed schema requested Columns are " + colNames.size + " and lengths are " + lengths.size)


        /*
         * parse incoming string into array of fields
         */
        def parseFixedWidthsUdf = udf((line: String, lengthStr: String) => {
          val localLens = lengthStr.split(",")
          localLens.indices.foldLeft((line, Array.empty[String])) {
            case ((rem, fields), idx) => {
              val len = localLens(idx).toInt
              val fld = rem.take(len).trim
              (rem.drop(len), fields :+ fld)
            }
          }._2
        })

        //
        //val fwMapDf = startDF
        //  .filter(containsFunc(col("value")))
        //  .map(r => parseFixedWidths(r.getAs[String](0), lengths))
        //  .toDF()
        //
        val filteredFwMapDf = startDF
          .filter(containsFunc(col("value")))
        //
        val fwMapDf = filteredFwMapDf
          .withColumn("value", parseFixedWidthsUdf(col("value"), lit(lengths.mkString(","))))

        //
        val fwAllColsDf = lengths.indices.foldLeft(fwMapDf) { case (result, idx) =>
          result.withColumn(colNames(idx), $"value".getItem(idx).cast(colTypes(idx)))
        }
        //
        categoryDfCurrVar = fwAllColsDf.drop("value")

      } else if ("tojson".equals(currCategory)) {
        //
        val jsonAlias = startAttrs.getOrElse("toAlias", "")

        if ("" != jsonAlias) categoryDfCurrVar = startDF.toJSON.toDF

      } else if ("addjson".equals(currCategory)) {
        //
        val jsonAlias = startAttrs.getOrElse("toAlias", "")

        if ("" != jsonAlias) {
          categoryDfCurrVar = startDF
            .withColumn(jsonAlias, to_json(struct(startDF.columns.head, startDF.columns.tail: _*)))
            .select("*")
        }

      } else if ("tojsonxml".equals(currCategory)) {
        //
        val valColumn = startAttrs.getOrElse("fromColumn", "")
        val jsonAlias = startAttrs.getOrElse("toAlias", "")

        if ("" != jsonAlias) {
          categoryDfCurrVar = startDF
            .select(jsonxml(col(valColumn))).alias(jsonAlias)
            .select(jsonAlias + ".*")
            .toDF(jsonAlias)
        }

      } else if ("tofixedwidths".equals(currCategory)) {
        // create schema
        StaticSourceReader.broadcastReference(currCategoryKey + "_schema", createSchema(forName, startAttrs))
        val readerSchema: StructType = StaticSourceReader.getBroadcastReferenceData(currCategoryKey + "_schema").asInstanceOf[StructType]
        StaticSourceReader.broadcastReference(currCategoryKey + "_lengths", createFixedWidths(forName, startAttrs))
        val lengths: List[Int] = StaticSourceReader.getBroadcastReferenceData(currCategoryKey + "_lengths").asInstanceOf[List[Int]]

        //
        val colNames = readerSchema.fieldNames
        logger.warn("printing fixedschema requested columns: " + colNames.size + " and lengths are: " + lengths.size)

        //
        def parseFixedWidthsUdf = udf((colvals: mutable.WrappedArray[String], lengthStr: String) => {
          val lents = lengthStr.split(",")
          val fields: Array[String] = lents.indices.foldLeft(Array.empty[String]) { case(flds, idx) =>
            val fld = Option(colvals(idx)).getOrElse("").padTo(lents(idx).toInt, ' ').take(lents(idx).toInt)
              flds :+ fld
          }
          fields.mkString
        })

        //
        val fwMapDf = startDF
          .withColumn("value", parseFixedWidthsUdf(array(startDF.columns.map(c => col(c).cast(StringType)): _*), lit(lengths.mkString(","))))
          .select("value")

        //
        categoryDfCurrVar = fwMapDf

      } else if ("sh".equals(currCategory)) {
        //
        val sessDataMap = StorageHelper.getSessionData()
        if (!sessDataMap.get(forName).isDefined) sessDataMap += (forName -> mutable.Map[String, String]())
        val stepMap: mutable.Map[String, String] = sessDataMap.get(forName).get

        // Run post process scripts
        import sys.process._
        val argv = if (startAttrs.get("arguments").isDefined) " " + QueryParserHelper.replaceSessionArgs(startAttrs.get("arguments").get, planCache.planData) else ""
        val cmd = startAttrs.getOrElse("path", "") + "/" + startAttrs.getOrElse("name", "") + argv
        val shellResult = Process(cmd).lineStream //cmd.!!;val arr = shellResult.split("\\n")
        println(s"printing shellResult for command.... $cmd")
        shellResult.foreach(x => {
          println(s"printing shellResult: $x")
          val arr = x.split("=")
          if (!arr.isEmpty && arr.size > 1) {
            println(x + " ++ " + arr(0) + " = " + arr(1))
          }
          stepMap += (arr(0) -> arr(1))
        })

      }

      // repartition for performance
      categoryDfVar = categoryDfCurrVar
      if (!repartBy.isEmpty) categoryDfVar = categoryDfCurrVar.repartition(repartBy.split(",").map(col(_)): _*)

      //
    }


    //
    if (PropsUtil.printSchema()) categoryDfVar.printSchema()
    if (PropsUtil.showData()) categoryDfVar.show(false)


    //
    categoryDfVar
  }

  /**
    * Recursive transform on Category
    * @param forName
    * @param begin
    * @param convArrary
    * @param iterDf
    * @param planCache
    * @return
    */
  def recursiveCategoryTransform(forName: String, begin: Int, convArrary: Array[Map[String, String]], iterDf: DataFrame, planCache: PlanCache): DataFrame = {
    //
    var iterCurrDfVar: DataFrame = iterDf
    val ss: SparkSession = iterDf.sparkSession

    //
    val iterConvAttrGroup = convArrary.filter(x => begin == x.getOrElse("seq", "-1").toInt)
    //
    if (!iterConvAttrGroup.isEmpty) {
      //
      val iterConvAttrCurr: Map[String, String] = StorageHelper.mapValuesTransform(iterConvAttrGroup(0), planCache.planData)
      val nextIterCurrDf: DataFrame = categoryTransform(forName, begin, iterConvAttrCurr, iterDf, planCache)

      //
      iterCurrDfVar = recursiveCategoryTransform(forName, (begin + 1), convArrary, nextIterCurrDf, planCache)
    }

    //
    iterCurrDfVar
  }


  /**
    * Recursive and Split Transform on Category
    * @param name
    * @param include
    * @param convLabel
    * @param occurrence
    * @param begin
    * @param convArrary
    * @param iterDf
    * @param planCache
    * @return
    */
  def recursiveSplitConvCategoryTransform(name: String, include: Boolean, convLabel: String, occurrence: Int, begin: Int, convArrary: Array[Map[String, String]], iterDf: DataFrame, planCache: PlanCache): (Boolean, String, DataFrame) = {

    println(s"printing BuilderHelper ${name} recursiveSplitConvCategoryTransform $include $convLabel")
    //
    var iterCurrDfVar: DataFrame = iterDf
    val ss: SparkSession = iterDf.sparkSession

    //
    var decsn: Boolean = include
    var label = convLabel
    var currInclude: Boolean = false
    var currLabel = ""

    //
    val iterConvAttrGroup = convArrary.filter(x => begin == x.getOrElse("seq", "-1").toInt)
    //
    if (!iterConvAttrGroup.isEmpty) {

      //
      val iterConvAttrCurr: Map[String, String] = StorageHelper.mapValuesTransform(iterConvAttrGroup(0), planCache.planData)
      val iterConvCurrTransComp = BuilderHelper.convertToDFTransOpt(name, "", iterConvAttrCurr, planCache)
      var nextIterCurrDfVar: DataFrame = iterDf
      if (!iterConvCurrTransComp.skipLabelProcess) {
        //
        currInclude = true
        currLabel = iterConvAttrCurr.getOrElse("label", "")
        //
        if (!iterConvCurrTransComp.replaceLabelEnabled && iterConvCurrTransComp.aliasDataFrame.isDefined) {
          nextIterCurrDfVar = iterConvCurrTransComp.aliasDataFrame.get
        } else {
          iterCurrDfVar = BuilderHelper.categoryTransform(name, (occurrence + begin), iterConvAttrCurr, iterDf, planCache)
          // apply cache
          val iterCacheDf = BuilderHelper.applyCacheAfter(iterConvCurrTransComp, iterCurrDfVar, planCache)

          nextIterCurrDfVar = iterCurrDfVar
          //
        }
        //
      }
      //
      if (!decsn && currInclude) decsn = true
      if (!currLabel.isEmpty) label = currLabel

      //
      val (retdecsn, retLabel, retIterCurrDfVar) = recursiveSplitConvCategoryTransform(name, decsn, label, occurrence, (begin + 1), convArrary, nextIterCurrDfVar, planCache)

      //
      decsn = retdecsn
      label = retLabel
      iterCurrDfVar = retIterCurrDfVar
    }

    //
    (decsn, label, iterCurrDfVar)
  }


  def recursiveSplitCategoryTransform(name: String, occurrence: Int, convArrary: Array[Map[String, String]], iterDf: DataFrame, planCache: PlanCache): (Boolean, String, DataFrame) = {
    //
    val (decsn, label, splitDf) = recursiveSplitConvCategoryTransform(name, false, "", (occurrence * 1000), 1, convArrary, iterDf, planCache)

    //
    (decsn, label, splitDf)
  }



  /**
    * Adds Stats column for each type of invalid configuration
    *
    * @param stepAttrs
    * @param input
    * @return
    */
  def addColumnValidationStats(stepAttrs: Map[String, String], input: DataFrame): DataFrame = {

    //
    var addColStatDfVar: DataFrame = input

    // load invalid config for given src_system and table
    val configArr = StaticSourceReader.getInvCfgData()

    // RUN ALL INVALID FUNCTIONS IN SEQUENCE

    //
    def rowDataTypeChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("data_type_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        val dataTypeName = chkCol.getAs[String]("data_type")
        try {
          //row.getAs(colName).getClass
          dataTypeName match {
            case "Int" => if (row.getAs(colName).toString.equals(row.getAs[Int](colName).toString.toInt)) row.getAs[Double](colName).getClass
            case "Long" => if (row.getAs(colName).toString.equals(row.getAs[Long](colName).toString.toLong)) row.getAs[Double](colName).getClass //if (!row.getAs(colName).isInstanceOf[Long]) row.getAs(colName).getClass //println("Verifying Long :" + row.getAs(colName).getClass+ " " + row.getAs(colName).isInstanceOf[Long] + " "+colName)
            case "String" => if (row.getAs(colName).toString.equals(row.getAs[String](colName).toString)) row.getAs[Double](colName).getClass
            case "Float" => if (row.getAs(colName).toString.equals(row.getAs[Float](colName).toString.toFloat)) row.getAs[Double](colName).getClass
            case "Double" => if (row.getAs(colName).toString.equals(row.getAs[Double](colName).toString.toDouble)) row.getAs[Double](colName).getClass
            case _ => ""
          }
        } catch {
          case x: Throwable => if (colList.length > 0) colList += "~" + colName else colList += colName
        }
      })
      colList
    })

    //
    def rowNullChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("null_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == null) {
          if (colList.length > 0) colList += "~" + colName else colList += colName
        }
      })
      colList
    })

    //
    def rowEmptyChk = udf((row: Row) => {

      val chkCols = configArr.filter(p => p.getAs[Int]("empty_check") == 1)
      var colList = ""

      chkCols.map(chkCol => {
        val colName = chkCol.getAs[String]("col_name")
        if (row.getAs[String](colName) == "") {
          if (colList.length > 0) colList += "~" + colName else colList += colName
        }
      })
      colList
    })


    //
    addColStatDfVar = input
      .withColumn("datatypechkstat", rowDataTypeChk(struct(input.columns.map(col): _*)))
      .withColumn("nullchkstat", rowNullChk(struct(input.columns.map(col): _*)))
      .withColumn("emptychkstat", rowEmptyChk(struct(input.columns.map(col): _*)))


    //
    addColStatDfVar
  }


  /**
    * Saved the summation of each column stat on validation
    *
    * @param stepAttrs
    * @param statDf
    * @param input
    * @param planCache
    */
  def saveColStatValidationSummations(stepAttrs: Map[String, String], statDf: DataFrame, input: DataFrame, planCache: PlanCache): Unit = {

    // RUN SUMMATATIONs on ABOVE FUNCTIONS

    //
    val configArr = StaticSourceReader.getInvCfgData()

    //
    val totalRecCount = input.count
    var mutColChkMap = mutable.Map[String, mutable.Map[String, Long]]()
    val colDupChkStat = "sum_dup_chk_cnt"
    configArr.foreach(chkCol => {
      val colName = chkCol.getAs[String]("col_name")
      val cnt = input.groupBy(colName).count.filter("count = 1").count
      var innrMap = mutColChkMap.getOrElse(colDupChkStat, mutable.Map[String, Long]())
      innrMap += colName -> (totalRecCount - cnt)
      mutColChkMap += colDupChkStat -> innrMap
    })



    //
    List("sum_range_chk_cnt", "sum_const_chk_cnt")
      .foreach(sumCol => {
        configArr.foreach(chkCol => {
          val colName = chkCol.getAs[String]("col_name").toString
          var innrMap = mutColChkMap.getOrElse(sumCol, mutable.Map[String, Long]())
          innrMap += colName -> 0
          mutColChkMap += sumCol -> innrMap
        })
      })
    //
    val sumColMap = Map(
      "sum_dtype_chk_cnt" -> "datatypechkstat",
      "sum_null_chk_cnt" -> "nullchkstat",
      "sum_empty_chk_cnt" -> "emptychkstat"
    )
    sumColMap.foreach(sumCol => {
      configArr.foreach(chkCol => {
        val colName = chkCol.getAs[String]("col_name").toString
        val cnt = statDf.filter(col(sumCol._2).contains(colName)).count
        var innrMap = mutColChkMap.getOrElse(sumCol._1, mutable.Map[String, Long]())
        innrMap += colName -> cnt
        mutColChkMap += sumCol._1 -> innrMap
      })
    })


    //
    StaticSourceReader.broadcastSumChkColReference(mutColChkMap.map(f => f._1 -> f._2.toMap).toMap)
    var immutColChkMap = StaticSourceReader.getSumChkColData()

    //
    val sumChkStatRawDF = StaticSourceReader.getSampleSumChkColDataFrame(stepAttrs)
    val sumChkStatInitDF = immutColChkMap.keys.foldLeft(sumChkStatRawDF)((sumChkStatRawDF, colNm) => sumChkStatRawDF.withColumn(colNm, lit("0")))

    //
    //
    def rowReplaceChkVal = udf((colNm: String, colGrp: String) => {
      val ret: Long = immutColChkMap.getOrElse(colGrp, mutable.Map[String, Long]()).getOrElse(colNm, 0)
      ret
    })

    //
    val sumChkStatDF = immutColChkMap.keys.foldLeft(sumChkStatInitDF)((sumChkStatInitDF, colNm) => sumChkStatInitDF.withColumn(colNm, rowReplaceChkVal(col("col_name"), lit(colNm))))


    // additional columns event/process timestamps
    val sumChkHistMap = Map(
      "src_system" -> "$args#0",
      "event_dt" -> "$args#1",
      "event_hr" -> "$args#2",
      "process_epoch" -> "$sys#processEpochSec",
      "process_dt" -> "$sys#processDt",
      "process_hr" -> "$sys#processHr"
    )
    // Final sumchkstat with additional columns
    val sumChkStatFnlDF = includeAttributeTransform(sumChkHistMap, sumChkStatDF, planCache) //includeAttributeTransform(sumChkStatDF, sumChkHistMap)
    sumChkStatFnlDF.createOrReplaceTempView("sumChkStatFnlDF")
    val qualStatTbl = PropsUtil.getWorkflow().attributes.getOrElse(Map()).getOrElse("qualityStatus", "")
    val iostatqry =
      s"""
         |insert into table $qualStatTbl partition(src_system,event_dt)
         |select table_name,col_name,sum_dtype_chk_cnt,sum_null_chk_cnt,
         |sum_empty_chk_cnt,sum_dup_chk_cnt,sum_range_chk_cnt,sum_const_chk_cnt,
         |event_hr,process_epoch,process_dt,process_hr,src_system,event_dt
         | from sumChkStatFnlDF
      """.stripMargin
    SparkHelper.getSparkSession().sql(iostatqry)

    //sumChkStatFnlDF.show(false)
    //sess.sql("select * from invalid_col_stats").show(false)

  }


  /**
    * Adds Stat column for every event in the dataframe by comibining invalid status for all the columns in a row
    *
    * @param statDf
    * @return
    */
  def addInvalidColStat(statDf: DataFrame): DataFrame = {

    //
    var invColStDfVar: DataFrame = statDf


    //
    def concatColChkPrefix = udf((pfx: String, colVal: String) => {
      if (!colVal.isEmpty) pfx + colVal else ""
    })


    // create stat column to capture combined invalid reason
    val preStatChkStatDF = statDf
      .withColumn("uuid", uuid())
      .withColumn("stat", concat_ws(" ", concatColChkPrefix(lit("DataTypeCheck:"), col("datatypechkstat")), concatColChkPrefix(lit("NullCheck:"), col("nullchkstat")), concatColChkPrefix(lit("EmptyCheck:"), col("emptychkstat"))))
    invColStDfVar = preStatChkStatDF.withColumn("stat", trim(col("stat")))


    //
    invColStDfVar
  }


  /**
    * Returns Dataframe by including stat column from all invalid checks
    *
    * @param stepAttrs
    * @param input
    * @param planCache
    * @return
    */
  def invalidConfigTransform(stepAttrs: Map[String, String], input: DataFrame, planCache: PlanCache): DataFrame = {

    //
    // Add Column Stat on validation
    //
    var colStatDfVar: DataFrame = input
    colStatDfVar = addColumnValidationStats(stepAttrs, input)
    val colStatDf = colStatDfVar



    //
    // Add Summ of Column Stat on validation
    //
    saveColStatValidationSummations(stepAttrs, colStatDf, input, planCache)


    //
    // Convert individual column level stats into single stat column
    //
    var statDfVar: DataFrame = colStatDf
    statDfVar = addInvalidColStat(colStatDf)
    val statDf = statDfVar


    //
    statDf
  }


  /**
    * Builds specific BuilderHelper
    * @param handlername
    * @param forhandlername
    */
  class BaseBuilderHelper(handlername: String, forhandlername: String) extends BuilderHelper {

    //
    name = handlername
    forname = forhandlername

  }

  /**
    * preferred factory method
    *
    * @param s
    * @param p
    * @return
    */
  def apply(s: String, fs: String): BuilderHelper = {
    getBaseBuilderHelper(s, fs)
  }

  // an alternative factory method (use one or the other)
  def getBaseBuilderHelper(s: String, fs: String): BuilderHelper = {
    new BaseBuilderHelper(s, fs)
  }



}


/**
  * A common helper class for all functions needed in any Builder reader/editor/writer
  */
trait  BuilderHelper extends BaseTrait {

  var name: String = _
  var forname: String = _
}