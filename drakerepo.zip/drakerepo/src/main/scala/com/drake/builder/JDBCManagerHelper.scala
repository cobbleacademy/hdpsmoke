package com.drake.builder

import java.sql.{Connection, DriverManager, Statement}
import java.util.Properties

import com.drake.BaseTrait
import org.apache.spark.sql.DataFrame

/**
  * A common model class for all functions required with JDBC Connection
  */
object JDBCManagerHelper extends BaseTrait {


  /**
    * Builds specif BuilderHelper
    * @param handlername
    * @param forhandlername
    * @param drivername
    * @param jdbcurl
    * @param applycommit
    * @param connectionprops
    */
  class BaseJDBCManagerHelper(handlername: String, forhandlername: String, drivername: String, jdbcurl: String, applycommit: Boolean, connectionprops: Properties) extends JDBCManagerHelper {

    //
    name = handlername
    forName = forhandlername
    driverName = drivername
    jdbcUrl = jdbcurl
    applyAutoCommit = applycommit
    connProps = connectionprops

    //
    if (connectionprops == null) connProps = new Properties()
    Class.forName(drivername)

    //
    connProps.setProperty("Driver", driverName)

    @annotation.tailrec
    final def retryConn[T](jUrls: Array[String], n: Int)(fn: String => T): T = {
      try {

      } catch {
        case e if n> 1 => // ignore
      }
      retryConn(jUrls, n - 1)(fn)
    }


    /**
      * Runs given udpate query in loop over replace with strings
      * @param sql
      * @param sf search-for string
      * @param rf replace-for string
      * @param ri run iterator to replace with
      */
    override def runDriverEditIterSql(sql: String, sf: String, rf: String, ri: String): Unit = {
      //
      val jUrls = jdbcUrl.split("::")
      val sz = jUrls.size
      val cfn = (url: String) => DriverManager.getConnection(url, connProps)

      //
      var conns: Connection = null
      var stmt: Statement = null


      /**
        * Returns connection based on the iteration limit
        * @param itr
        * @return
        */
      def createOrGetConnection(itr: Int): Connection = {
        //
        if (itr % 10 == 0) {
          //
          if (conns != null) conns.close()
          //
          conns = retryConn(jUrls, sz) {
            cfn
          }
          //
          if (applyAutoCommit) conns.setAutoCommit(true)
        }
        //
        val c = conns

        //
        c
      }


      /**
        * Returns Statement based on iteration limit
        * @param itr
        * @return
        */
      def createOrGetStatement(itr: Int): Statement = {
        //
        if (itr % 2 == 0) {
          //
          if (stmt != null) stmt.close()
          //
          stmt = createOrGetConnection(itr).createStatement()
        }
        //
        val st = stmt

        //
        st
      }

      //
      val sfDefined = if (sql.indexOf(sf) > 0) true else false
      val rfDefined = if (sfDefined && sql.indexOf(rf) > 0) true else false
      val iterNeeded = if (sfDefined && rfDefined && ri.length > 0) true else false

      //
      if (iterNeeded) {
        (1 to ri.toInt).foreach(f => {
          val sfrepl = sf.replaceAll(rf, (f-1).toString)
          val iterSql = sql.replaceAll(sf, sfrepl)
          logger.info(s"printing executing runDriverEditLoopOverSql: $iterSql")
          val result = createOrGetStatement(f-1).executeLargeUpdate(iterSql)
          logger.info(s"printing done executing query: $result")
        })
      }

      //
      if (conns != null) conns.close()
      //
    }


    /**
      * Runs teh given update sql
      * @param sql
      */
    override def runDriverEditSql(sql: String): Unit = {
      //
      val jUrls = jdbcUrl.split("::")
      val sz = jUrls.size
      val cfn = (url: String) => DriverManager.getConnection(url, connProps)
      val conn = retryConn(jUrls, sz) {
        cfn
      }
      val st: Statement = conn.createStatement()
      if (applyAutoCommit) conn.setAutoCommit(true)
      logger.info(s"Executing runEditSql: $sql")
      val result = st.executeUpdate(sql)
      logger.info(s"Executing runEditSql: $sql == $result")
      conn.close()
    }



    /**
      * Executes given sql and returns Row objects
      * @param dataFrame
      * @param sql
      * @return
      */
    override def runSql(dataFrame: DataFrame, sql: String): DataFrame = {
      //
      val ss = dataFrame.sparkSession

      //
      val opts: Map[String, String] = Map(
        "Driver" -> driverName,
        "url" -> jdbcUrl,
        "dbtable" -> sql
      )

      //
      val df = ss
        .read
        .format("jdbc")
        .options(opts)
        .load()

      //
      df
    }




  }


  /**
    * preferred factory method
    * @param s
    * @param fs
    * @param sa
    * @return
    */
  def apply(s: String, fs: String, dn: String, ju: String, aac: Boolean, cp: Properties): JDBCManagerHelper = {
    getJDBCManagerHelper(s, fs, dn, ju, aac, cp)
  }


  /**
    * an alternative to factory method (use one or the other)
    * @param s
    * @param fs
    * @param sa
    * @return
    */
  def getJDBCManagerHelper(s: String, fs: String, dn: String, ju: String, aac: Boolean, cp: Properties): JDBCManagerHelper = {
    new BaseJDBCManagerHelper(s, fs, dn, ju, aac, cp)
  }

}


/**
  * A common model class for all functions required with JDBC Connection
  */
trait JDBCManagerHelper extends BaseTrait {

  var name: String = _
  var forName: String = _
  var driverName: String = _
  var jdbcUrl: String = _
  var applyAutoCommit: Boolean = true
  var connProps: Properties = _


  /**
    * Executes given sql in loop over replqce with strings
    *
    * @param sql
    * @param sf
    * @param rf
    * @param ri
    */
  def runDriverEditIterSql(sql: String, sf: String, rf: String, ri: String): Unit


  /**
    * Executes given sql
    *
    * @param sql
    */
  def runDriverEditSql(sql: String): Unit


  /**
    * Executes given sql and returns list spark type Row objects
    * @param dataFrame
    * @param sql
    * @return
    */
  def runSql(dataFrame: DataFrame, sql: String): DataFrame


}

