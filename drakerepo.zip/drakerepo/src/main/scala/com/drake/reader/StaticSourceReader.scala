package com.drake.reader

import com.drake.{BaseTrait, PropsUtil, SparkHelper}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, Row}



object StaticSourceReader extends BaseTrait {

  private var invCfgData:Array[Row]=null
  private var invCfgDataBC:Broadcast[Array[Row]]=null
  private var sumChkColDataBC:Broadcast[Map[String, Map[String, Long]]]=null
  private var fixedLengthsDataBC: Broadcast[List[Int]] = null
  private var broadcastHolder: Map[String, Broadcast[Any]] = Map[String, Broadcast[Any]]()


  /**
    * Initialize Invalid Config Data
    * @param config
    * @return
    */
  def initInvalidConfigReference(configAttrs: Map[String, String]): Unit = {
    //
    logger.info("StaticSourceReader: Creating Invalid Config references")
    val sess =  SparkHelper.getSparkSession()

    //
    val qualCfgTbl = PropsUtil.getWorkflow().attributes.getOrElse(Map()).getOrElse("qualityConfig", "")
    sess.sql(s"msck repair table $qualCfgTbl")
    val invCfgDF = sess.sql(s"select * from $qualCfgTbl where src_system='" + configAttrs.getOrElse("invalidSrcSystem","") + "' and table_name='" + configAttrs.getOrElse("invalidTable","") + "'")
    //println("invCfgDF show")
    //invCfgDF.show(false)

    //
    val invCfgData = invCfgDF.rdd.collect()
    invCfgDataBC=sess.sparkContext.broadcast(invCfgData)
  }


  /**
    * Returns InvalidConfig Broadcast
    * @return
    */
  def getInvCfgDataBroadcast(): Broadcast[Array[Row]] = {
    invCfgDataBC
  }


  /**
    * Returns broadcasted InvalidConfig data
    * @return
    */
  def getInvCfgData(): Array[Row] = {
    invCfgDataBC.value
  }


  /**
    * Returns Broadcast reference of SumChkCol data
    * @param sumChkColMap
    * @return
    */
  def broadcastSumChkColReference(sumChkColMap: Map[String, Map[String, Long]]): Broadcast[Map[String, Map[String, Long]]] = {
    sumChkColDataBC=SparkHelper.getSparkSession.sparkContext.broadcast(sumChkColMap)
    sumChkColDataBC
  }


  /**
    * Returns broadcasted SumChkCol data
    * @return
    */
  def getSumChkColData(): Map[String, Map[String, Long]] = {
    sumChkColDataBC.value
  }


  /**
    * Initialize Invalid Config Data
    * @param config
    * @return
    */
  def getSampleSumChkColDataFrame(configAttrs: Map[String, String]): DataFrame = {
    SparkHelper.getSparkSession.sql("select table_name,col_name from " + PropsUtil.getWorkflow().attributes.getOrElse(Map()).getOrElse("qualityConfig", "") + " where src_system='" + configAttrs.getOrElse("invalidSrcSystem","") + "' and table_name='" + configAttrs.getOrElse("invalidTable","") + "'")
  }



  /**
    * Returns Broadcast reference of fixedLengths data
    * @param fixedLengths
    * @return
    */
  def broadcastFixedLengthReference(fixedLengths: List[Int]): Broadcast[List[Int]] = {
    fixedLengthsDataBC=SparkHelper.getSparkSession.sparkContext.broadcast(fixedLengths)
    fixedLengthsDataBC
  }


  /**
    * Returns broadcasted fixedLengths data
    * @return
    */
  def getFixedLengthData(): List[Int] = {
    fixedLengthsDataBC.value
  }



  /**
    * Returns Broadcast reference of any given data
    * @param fixedLengths
    * @return
    */
  def broadcastReference(key: String, reference: Any): Broadcast[Any] = {
    val referenceBC = SparkHelper.getSparkSession.sparkContext.broadcast(reference)
    broadcastHolder += (key -> referenceBC)
    referenceBC
  }


  /**
    * Returns broadcasted any given data
    * @return
    */
  def getBroadcastReferenceData(key: String): Any = {
    broadcastHolder.get(key).get.value
  }




  /**
    * Initialize all static sources
    * @param configAttrs
    */
  def initializeStaticSources(configAttrs: Map[String, String]): Unit = {
    initInvalidConfigReference(configAttrs)
  }


}
