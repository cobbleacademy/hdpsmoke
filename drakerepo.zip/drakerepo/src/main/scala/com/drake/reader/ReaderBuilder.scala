package com.drake.reader

import java.text.SimpleDateFormat
import java.util.Calendar

import com.drake._
import com.drake.builder.{BuilderHelper, ReadEditWriteHelper}
import com.drake.model.Model.{PlanCache, Step}
import com.drake.status.StatusBuilderHelper
import com.drake.storage.StorageHelper
import org.apache.spark.sql.DataFrame

import scala.collection.mutable

/**
  * A Builder interface for all the Source Readers
  */
object ReaderBuilder {

  /**
    * Builds specific Reader
    */
  class BaseReader(handlername: String, handlerPlanCache: PlanCache) extends ReaderBuilder {

    name = handlername
    planCache = handlerPlanCache

    /**
      * Save data in session
      * @param step
      * @param readFrame
      */
    def savePreSessionData(step: Step, readFrame: DataFrame): Unit = {
      //
      val stepAttrs = StorageHelper.mapValuesTransform(step.attributes.getOrElse(Map()), planCache.planData)
      //
      val cnt = -100
      val fileNames = if (readFrame.isStreaming) "" else readFrame.inputFiles.map(_.split("/").last).mkString("|")
      val now = Calendar.getInstance().getTime()
      val nowFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SXXX")
      val nowStr = nowFormat.format(now)
      val status = stepAttrs.getOrElse("status", step.name)
      val statusComment = stepAttrs.getOrElse("statusComment", "")
      val fnames = stepAttrs.getOrElse("fileName", fileNames)
      val fileDt = stepAttrs.getOrElse("fileDt", "")
      val fileHr = stepAttrs.getOrElse("fileHr", "")
      val srcSystem = stepAttrs.getOrElse("srcSystem", "")
      //
      val sessDataMap = StorageHelper.getSessionData()
      val stepMap: mutable.Map[String, String] =
        mutable.Map("fileName" -> fnames,
          "fileDt" -> fileDt,
          "fileHr" -> fileHr,
          "count" -> cnt.toString,
          "startTime" -> nowStr,
          "endTime" -> "",
          "status" -> status,
          "comment" -> statusComment,
          "srcSystem" -> srcSystem
          )
      sessDataMap += (name -> stepMap)

    }

    /**
      * Saves Properties in SessionData
      *
      * @param step
      * @param readFile
      */
    def savePostSessionData(step: Step, readFrame: DataFrame): Unit = {
      //
      val stepAttrs = step.attributes.getOrElse(Map())
      val postAttrs = step.post.getOrElse(Map())
      //
      val sessDataMap = StorageHelper.getSessionData()
      if (!sessDataMap.get(name).isDefined) sessDataMap += (name -> mutable.Map[String, String]())
      val stepMap: mutable.Map[String, String] = sessDataMap.get(name).get

      println("printing shellResult....")
      // Run post process scripts
      if (!postAttrs.isEmpty) {
        import sys.process._
        val argv = if (postAttrs.get("arguments").isDefined) " " + QueryParserHelper.replaceSessionArgs(postAttrs.get("arguments").get, planCache.planData) else ""
        val cmd = postAttrs.getOrElse("path", "") + "/" + postAttrs.getOrElse("name", "") + argv
        val shellResult = Process(cmd).lineStream //cmd.!!;val arr = shellResult.split("\\n")
        println(s"printing shellResult for command $cmd")
        shellResult.foreach(x => {
          println(s"printing shellResult: $x")
          val arr = x.split("=")
          if (!arr.isEmpty && arr.size > 1) {
            println(x + " ++ " + arr(0) + " = " + arr(1))
            stepMap += (arr(0) -> arr(1))
          }
        })
      }

    }

    /**
      * Returns DataFrame by reading data from source with defined type
      *
      * @param step
      * @param inDataFrame
      * @return
      */
    override def readSource(step: Step, inDataFrame: Option[DataFrame] = None): DataFrame = {
      logger.debug("BaseReader:readSource")

      //
      val sparkSession = SparkHelper.getSparkSession()

      //
      //val stepOpts = step.options.getOrElse(Seq(Attribute("", ""))) val stepOptsMap = Map(stepOpts map { a => a.key -> a.value }: _*)
      //
      val stepOpts = StorageHelper.mapValuesTransform(step.options.getOrElse(Map()),planCache.planData)
      val stepAttrs = StorageHelper.mapValuesTransform(step.attributes.getOrElse(Map()),planCache.planData)
      val postAttrs = step.post.getOrElse(Map())

      //
      // local mode debug and steps
      //
      val localMode = PropsUtil.propSystem("localMode", "false").toBoolean
      if (localMode) {
        // not needed when running on cluster but stanalone mode
        //val localPrefix = "/Users/nnagaraju/IDEAWorkspace/drake/"
        val localPrefix = ""

        //val ldstDrTbl = "drop table if exists load_status"
        //val ldstCrTbl = s"create table if not exists load_status(file_name string,file_dt string,file_hr string,record_count string,start_time string,end_time string,comment string) partitioned by (src_system string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/load_status'"
        //val stgPartDrTbl = "drop table if exists sales_part_stg"
        //val stgPartCrTbl = "create external table if not exists sales_part_stg(transactionId int,customerId int,itemId int,amountPaid double) partitioned by (src_system string,event_dt string) row format delimited fields terminated by ',' stored as textfile location 'input/sales_part_stg'"
        //val stgDrTbl = "drop table if exists sales_stg"
        //val stgCrTbl = "create external table if not exists sales_stg(transactionId int,customerId int,itemId int,amountPaid double) row format delimited fields terminated by ',' stored as textfile location 'input/sales'"
        //val domDrTbl = "drop table if exists sales"
        //val domCrTbl = "create table if not exists sales(transactionId int,customerId int,itemId int,amountPaid double) partitioned by (process_dt string, process_hr int) row format delimited fields terminated by ',' stored as textfile location 'output/sales'"
        //val salesInvDrTbl = "drop table if exists sales_invalid"
        //val salesInvCrTbl = s"create table if not exists sales_invalid(transactionId int,customerId int,itemId int,amountPaid double,invalid_reason string,uuid string,process_epoch bigint,process_dt string,process_hr string) partitioned by (event_dt string, event_hr int) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/sales_invalid'"
        //CLUSTERED BY(customerId) INTO 2 BUCKETS
        val domDrTbl = "drop table if exists sales_dom"
        val domCrTbl = s"create table if not exists sales_dom(transactionId int,customerId int,itemId int,amountPaid double,uuid string,process_epoch bigint,process_dt string,process_hr string) partitioned by (event_dt string, event_hr string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/sales_dom'"
        //val domCrTbl1 = s"create table if not exists sales_dom(transactionId int,customerId int,itemId int,amountPaid double,uuid string,process_epoch bigint,process_dt string,process_hr string) partitioned by (event_dt string, event_hr string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/sales_dom'"
        //val invColCfgDrTbl = "drop table if exists invalid_col_config"
        //val invColCfgCrTbl = s"create table if not exists invalid_col_config(table_name string,col_name string,data_type string,data_type_check int,null_check int,empty_check int,dup_check int,range_check int,range_check_values string,const_check int,const_check_values string) partitioned by (src_system string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}input/config/invalid_col_config'"
        //val invColStDrTbl = "drop table if exists invalid_col_stats"
        //val invColStCrTbl = s"create table if not exists invalid_col_stats(table_name string,col_name string,sum_dtype_chk_cnt bigint,sum_null_chk_cnt bigint,sum_empty_chk_cnt bigint,sum_dup_chk_cnt bigint,sum_range_chk_cnt bigint,sum_const_chk_cnt bigint,event_hr int,process_epoch bigint,process_dt string,process_hr string) partitioned by (src_system string, event_dt string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/invalid_col_stats'"
        //val partIncrDrTbl = "drop table if exists part_incr"
        //val partIncrCrTbl = s"create table if not exists part_incr(partid bigint,partname string,cost double,updated string) partitioned by (event_dt string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/part_incr'"
        //val partDrTbl = "drop table if exists part"
        //val partCrTbl = s"create table if not exists part(partid bigint,partname string,cost double,updated string) partitioned by (event_dt string) row format delimited fields terminated by ',' stored as textfile location '${localPrefix}output/part'"
        //sparkSession.sql(ldstDrTbl)
        //sparkSession.sql(ldstCrTbl)
        //sparkSession.sql(stgPartDrTbl)
        //sparkSession.sql(stgPartCrTbl)
        //sparkSession.sql("msck repair table sales_part_stg")
        //sparkSession.sql(stgDrTbl)
        //sparkSession.sql(stgCrTbl)
        //sparkSession.sql(salesInvDrTbl)
        //sparkSession.sql(salesInvCrTbl)
        sparkSession.sql(domDrTbl)
        sparkSession.sql(domCrTbl)
        //sparkSession.sql(invColCfgDrTbl)
        //sparkSession.sql(invColCfgCrTbl)
        //sparkSession.sql(invColStDrTbl)
        //sparkSession.sql(invColStCrTbl)
        //sparkSession.sql(partIncrDrTbl)
        //sparkSession.sql(partIncrCrTbl)
        //sparkSession.sql(partDrTbl)
        //sparkSession.sql(partCrTbl)

        //
        sparkSession.sql("show databases").show(false)
        sparkSession.sql("show tables").show(false)
        //sparkSession.sql("select * from sales_stg").show(false)
        //sparkSession.sql("show partitions sales").show(false)
        sparkSession.sql("show partitions sales_dom").show(false)
        //sparkSession.sql("alter table sales_dom drop if exists partition (process_dt = '2018-12-22')")
        //sparkSession.sql("show partitions sales_dom").show(false)
        //sparkSession.sql("select * from sales").show(false)
        //sparkSession.sql("select * from sales_dom").show(false)
        //sparkSession.sql("show partitions load_status").show(false)

      }


      //
      var inStreamDf: DataFrame = if (inDataFrame.isDefined) inDataFrame.get else null

      //
      if ("stream".equals(PropsUtil.getWorkflow().mode)) {

        //
        val streamDf: DataFrame = ReadEditWriteHelper.streamingReader(step.format.getOrElse(""), stepAttrs, stepOpts, planCache)

        //
        inStreamDf = streamDf

      } else { // all batch steps

        //
        // A pre construction dataframe or dataframe from step
        //
        if (inStreamDf == null) {

          if (ReadEditWriteHelper.isMultiReadEnabled(stepAttrs)) {
            //
            val inDfSeq = ReadEditWriteHelper.multiReader(step.format.getOrElse(""), stepAttrs, stepOpts, planCache)
            if (!inDfSeq.isEmpty && inDfSeq.size > 0) inStreamDf = inDfSeq(0).dataFrame

          } else {
            //
            inStreamDf = ReadEditWriteHelper.batchReader(step.format.getOrElse(""), stepAttrs, stepOpts, planCache)
          }

        } // pre or step

        //
        savePreSessionData(step, inStreamDf)

        //
        val transComp = BuilderHelper.convertToDFTransOpt(step.name, step.label.getOrElse(""), stepAttrs, planCache)

        // apply cache after instream generated
        inStreamDf = BuilderHelper.applyCacheAfter(transComp, inStreamDf, planCache)

        //
        if (PropsUtil.printSchema()) inStreamDf.printSchema()
        if (PropsUtil.showData()) inStreamDf.show(false)

        // save properties in session
        savePostSessionData(step, inStreamDf)

        // Run post process scripts
        if ("true".equals(stepAttrs.getOrElse("logStatus", "false"))) StatusBuilderHelper.beginLogStatus(step)

      }

      //
      inStreamDf
    }


  }

  /**
    * preferred factory method
    *
    * @param s
    * @param p
    * @return
    */
  def apply(s: String, p: PlanCache): ReaderBuilder = {
    getReaderBuilder(s, p)
  }

  // an alternative factory method (use one or the other)
  def getReaderBuilder(s: String, p: PlanCache): ReaderBuilder = {
    new BaseReader(s, p)
  }

}

/**
  * A Builder interface for all the Source Readers
  */
trait ReaderBuilder extends BaseTrait with PlanCacheTrait {

  var name: String = _

  /**
    * Returns DataFrame by reading data from source with defined type
    *
    * @param step
    * @param inDataFrame
    * @return
    */
  def readSource(step: Step, inDataFrame: Option[DataFrame] = None): DataFrame

}
