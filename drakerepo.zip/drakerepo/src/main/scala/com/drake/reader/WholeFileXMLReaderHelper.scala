package com.drake.reader

import com.drake.function.Func.xmltojsonfunc
import com.drake.schema.SchemaBuilderHelper
import com.drake.{BaseTrait, SparkHelper}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable.ListBuffer

/**
  * A Helper class to facilitate reading XML multiline tags
  */
object WholeFileXMLReaderHelper extends BaseTrait {


  /**
    * Creates a DataFrame from incoming multi line XML documents
    *
    * @param inputRDD
    * @param startAttrs
    * @return
    */
  def createWholeFileXMLDataFrame(inputRDD: RDD[(String, String)], startAttrs: Map[String, String]): DataFrame = {

    /**
      * Returns elements array for given element name
      *
      * @param content
      * @param inputAttrs
      * @return
      */
    def extractElements(content: String, inputAttrs: Map[String, String]): List[String] = {
      //
      val splitTag = "</" + inputAttrs.getOrElse("xmlRootTag", "") + ">"
      val elemArray = ListBuffer[String]()


      /**
        *
        * @param anInputAttrs
        * @param aList
        * @param aContent
        * @param aTag
        * @return
        */
      def extractByElementTag(anInputAttrs: Map[String, String], aList: ListBuffer[String], aContent: String, aTag: String): ListBuffer[String] = {
        //
        val endTag = "</" + aTag + ">"

        //
        aContent.split(endTag).foldLeft(aList) { (acc, aElem) =>
          acc += xmltojsonfunc(if (aElem.replaceAll(" ", "").replaceAll("\\n","").trim.length > 0) aElem + endTag else "", anInputAttrs)

        }
      }

      /**
        *
        * @param anInputAttrs
        * @param rootList
        * @param rootContent
        * @param rootTag
        * @param elemTag
        * @return
        */
      def extractByRootTag(anInputAttrs: Map[String, String], rootList: ListBuffer[String], rootContent: String, rootTag: String, elemTag: String): ListBuffer[String] = {
        //
        val endRootTag = "</" + rootTag + ">"

        val beginElementTag = "<" + elemTag

        //
        rootContent.split(endRootTag).foldLeft(rootList) { (acc, rootElem) =>

          if (rootElem.replaceAll(" ","").replaceAll("\\n","").trim.length > 0)

            if (!rootTag.isEmpty && !elemTag.isEmpty && rootTag != elemTag) {

              acc ++= extractByElementTag(anInputAttrs, ListBuffer[String](),
                rootElem.substring(
                  if (rootElem.indexOf(beginElementTag+">") != -1) rootElem.indexOf(beginElementTag+">")
                  else rootElem.indexOf(beginElementTag + " ")
                ),
                elemTag
              )

            }
            else
              acc += xmltojsonfunc(if (rootElem.replaceAll(" ","").replaceAll("\\n","").trim.length > 0) rootElem + endRootTag else "", anInputAttrs)

          else
            acc

        }
      }

      //
      val elems = extractByRootTag(inputAttrs, elemArray, content, inputAttrs.getOrElse("xmlRootTag", ""), inputAttrs.getOrElse("xmlElementTag",""))

      //
      elems.toList

    }

    //
    SparkHelper
      .getSparkSession()
      .createDataFrame(
        inputRDD.flatMap(item => extractElements(item._2, startAttrs)).filter(_.length > 0).map(item => Row(item)),
        SchemaBuilderHelper.createWholeFileTextSchema()
      )
  }


}
