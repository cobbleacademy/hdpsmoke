package com.drake.crypto

import java.nio.charset.StandardCharsets
import java.security.Key
import java.util.Base64

import com.drake.PropsUtil
import javax.crypto.{Cipher, SecretKey}
import javax.crypto.spec.SecretKeySpec

/**
  * A Builder class to perform cryptography operations
  */
object CryptoBuilder {


  /**
    * Returns Alogrithm for crypto
    * @return
    */
  def getAlgorithm(): String = {
    PropsUtil.propValue("spark.crypto.spec.alog", "AES")
  }


  /**
    * Returns SecretKeySpec
    * @return
    */
  def getSecretKeySpec(): Key = {
    //
    val key = PropsUtil.propValue("spark.crypto.spec.key", "@#$%%$#@!^%$#%$#")
    new SecretKeySpec(key.getBytes(), getAlgorithm())
  }

  /**
    * Encrypt given string data
    * @param data
    * @return
    */
  def encrypt(data: String): String = {
    //
    val key = getSecretKeySpec()
    val c = Cipher.getInstance(getAlgorithm())
    c.init(Cipher.ENCRYPT_MODE, key)
    val cBytes = c.doFinal(data.getBytes(StandardCharsets.UTF_8))
    //
    Base64.getEncoder().encodeToString(cBytes)
  }

  /**
    * Decrypt given encrypted string
    * @param data
    * @return
    */
  def decrypt(data: String): String = {
    //
    val key = getSecretKeySpec()
    val c = Cipher.getInstance(getAlgorithm())
    c.init(Cipher.DECRYPT_MODE, key)
    val decoded = Base64.getDecoder().decode(data.getBytes(StandardCharsets.UTF_8))
    val cBytes = c.doFinal(decoded)

    //
    new String(cBytes)
  }

  /**
    * Main entry to class
    * @param args
    */
  def main(args: Array[String]): Unit = {
    //
    val key = new SecretKeySpec("DA4968CD3565CEAL".getBytes(), "AES")
    val data = "This is a text"

    val c1 = Cipher.getInstance("AES")
    c1.init(Cipher.ENCRYPT_MODE, key)
    val cBytes1 = c1.doFinal(data.getBytes(StandardCharsets.UTF_8))
    //
    val encodedStr = Base64.getEncoder.encodeToString(cBytes1)
    println("Encoded: " + encodedStr)

    val c2 = Cipher.getInstance("AES")
    c2.init(Cipher.DECRYPT_MODE, key)
    val decoded = Base64.getDecoder().decode(encodedStr.getBytes(StandardCharsets.UTF_8))
    val cBytes2 = c2.doFinal(decoded)
    //
    val decodedStr = new String(cBytes2)
    println("Decoded: " + decodedStr)
  }

}

/**
  * Option 1: Hadoop credential provider API
  * The CredentialProvider API in Hadoop allows for the separation of applications and how they store their required passwords/secrets. With Sqoop 1.4.5, the credential API keystore is supported by Sqoop.
  * hadoop credential create db2.testDB.alias -provider jceks://hdfs/tmp/db2test.password.jceks
  * Enter alias password:
  * Enter alias password again:
  * db2.testDB has been successfully created.
  * Provider jceks://hdfs/tmp/db2test.password.jceks has been updated.
  * sqoop import -Dhadoop.security.credential.provider.path=jceks://hdfs/tmp/db2test.password.jceks \
  * — driver com.ibm.db2.jcc.DB2Driver \
  * — connection-manager “org.apache.sqoop.manager.GenericJdbcManager” \
  * — connect jdbc:db2://<ServerIP>:50001/testDB \
  * — username testUser \
  * — password-alias db2.testDB.alias \
  * — table “default.Employee” \
  * — target-dir /tmp/Employee/
  * Option 2: org.apache.sqoop.util.password.CryptoFileLoader Class
  * The below class can be used to generate encrypted password file
  * import javax.crypto.Cipher;
  * import javax.crypto.SecretKey;
  * import javax.crypto.SecretKeyFactory;
  * import javax.crypto.spec.PBEKeySpec;
  * import javax.crypto.spec.SecretKeySpec;
  * public class Pass_Encrypt {
  * private byte[] encryptPassword(String password, String passPhrase, String alg, int iterations, int keySize)
  * throws Exception {
  * String algOnly = alg.split(“/”)[0];
  * SecretKeyFactory factory = SecretKeyFactory.getInstance(“PBKDF2WithHmacSHA1”);
  * SecretKey secKey = factory
  * .generateSecret(new PBEKeySpec(passPhrase.toCharArray(), “SALT”.getBytes(), iterations, keySize));
  * SecretKeySpec key = new SecretKeySpec(secKey.getEncoded(), algOnly);
  * Cipher crypto = Cipher.getInstance(alg);
  * crypto.init(Cipher.ENCRYPT_MODE, key);
  * return crypto.doFinal(password.getBytes());
  * }
  * public static void main(String[] args) throws Exception {
  * Pass_Encrypt enc = new Pass_Encrypt();
  * String encPass = new String(enc .encryptPassword(“password”,”sqooptest”,”AES/ECB/PKCS5Padding” ,10000, 128)); }
  * }
  * Sqoop command example:
  * sqoop import -Dorg.apache.sqoop.credentials.loader.class=org.apache.sqoop.util.password.CryptoFileLoader \
  * -Dorg.apache.sqoop.credentials.loader.crypto.passphrase=sqooptest \
  * — connection-manager “org.apache.sqoop.manager.GenericJdbcManager” \
  * — connect jdbc:db2://<ServerIP>:50001/testDB \
  * — username testUser \
  * — password-file file:///tmp/pass.enc \
  * — table “default.Employee” \
  * — target-dir /tmp/Employee/
  */
