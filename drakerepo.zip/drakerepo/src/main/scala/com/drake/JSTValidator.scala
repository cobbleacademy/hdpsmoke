package com.drake

import com.fasterxml.jackson.databind.JsonNode
import com.github.fge.jsonschema.core.exceptions.ProcessingException
import com.github.fge.jsonschema.core.report.ProcessingReport
import com.github.fge.jsonschema.main.JsonSchema
import com.github.fge.jsonschema.main.JsonSchemaFactory
import com.github.fge.jackson.JsonLoader

import java.io.IOException


object JSTValidator {

  private val PKGBASE = "/" + JSTValidator.getClass.getPackage.getName.replaceAll(".", "/")

  def fromResource(name: String): JsonNode = {
    JsonLoader.fromResource(PKGBASE + name)
  }

  def main(args: Array[String]): Unit = {

    val fstabSchema = fromResource("/fstab.json")
    val good = fromResource("/fstab-good.json")
    val bad = fromResource("/fstab-bad.json")
    val bad2 = fromResource("/fstab-bad2.json")

    val factory = JsonSchemaFactory.byDefault()

    val schema = factory.getJsonSchema(fstabSchema)

    var report: ProcessingReport = null

    report = schema.validate(good)
    println(report)

    report = schema.validate(bad)
    println(report)

    report = schema.validate(bad2)
    println(report)

  }


}
