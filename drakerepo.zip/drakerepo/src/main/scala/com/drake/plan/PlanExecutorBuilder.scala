package com.drake.plan

import com.drake.editor.EditorBuilder
import com.drake.fs.FSHelper
import com.drake.function.Func
import com.drake.model.Model._
import com.drake.offset.OffsetStore
import com.drake.reader.ReaderBuilder
import com.drake.status.StatusBuilderHelper
import com.drake.storage.StorageHelper
import com.drake.writer.WriterBuilder
import com.drake.{BaseTrait, PropsUtil, SparkHelper}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable.MutableList

/**
  * A Builder class for plan exeuctor
  */
object PlanExecutorBuilder {

  /**
    * Builds specific Plan Executor
    */
  class BasePlanExecutorBuilder(handlername: String) extends PlanExecutorBuilder {

    name = handlername
    planCache = StorageHelper.buildPlanStorage(Array[String]())

    //
    private var flowLevels = MutableList[FlowLevel]()


    private def createSingleRow(): Unit = {
      //
      val spark = SparkHelper.getSparkSession()
      //
      if (!spark.catalog.tableExists(PropsUtil.singleRow())) {
        //
        import spark.implicits._
        //
        val values = Seq("value")
        val df = values.toDF("value")
        //
        Func.registerFunctions(df)
        //
        df.createOrReplaceTempView(PropsUtil.singleRow())
      }
    }


    /**
      * Process Spouts to build Flow
      *
      * @param inDataFrames
      */
    private def createSpoutsLevel(inDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()): Unit = {

      //
      // A convenient single row cell dataframe
      //
      createSingleRow()

      //
      // Handle High Priority Streams
      //
      PropsUtil.getWorkflow().steps.filter(x => {
        val defined = x.from.isDefined
        val priority = if (x.priority.isDefined) x.priority.get.toBoolean else false
        (!defined && priority)
      }).map { ispout =>

        //
        val inputDataFrame: Option[DataFrame] = if (!inDataFrames.isEmpty) inDataFrames.get(ispout.name) else None

        println("Creating Priority Stream......")

        // connect and build input stream as spark stream
        // for each spout id load corresponding stream
        val dataFrame = ReaderBuilder(ispout.name, planCache).readSource(ispout, inputDataFrame)

        // Named json stream
        var dataFrameList = List[DataFrame]()
        dataFrameList = dataFrameList ++ List(dataFrame)
        flowLevels += new FlowLevel(ispout.name, ispout.label.get, false, ispout.name, true, 1, 1, dataFrameList)

      }

      //
      // FileSystem Begin process (delete/create - file/dir)
      //
      FSHelper.beginProcess()


      //
      // Handle Incoming Streams
      //
      PropsUtil.getWorkflow().steps.filter(x => {
        val defined = x.from.isDefined
        val priority = if (x.priority.isDefined) x.priority.get.toBoolean else false
        (!defined && !priority)
      }).map { ispout =>

        //
        val inputDataFrame: Option[DataFrame] = if (!inDataFrames.isEmpty) inDataFrames.get(ispout.name) else None

        println("Creating Stream......")

        // connect and build input stream as spark stream
        // for each spout id load corresponding stream
        val dataFrame = ReaderBuilder(ispout.name, planCache).readSource(ispout, inputDataFrame)

        // Named json stream
        var dataFrameList = List[DataFrame]()
        dataFrameList = dataFrameList ++ List(dataFrame)
        flowLevels += new FlowLevel(ispout.name, ispout.label.get, false, ispout.name, true, 1, 1, dataFrameList)

      }

    }


    /**
      * Find Targets based on the Source
      *
      * @param iSourceLabel
      * @return
      */
    private def getSourceBasedBolts(iSourceLabel: String): List[Step] = {
      // load all bolts belong to refSpout Name
      PropsUtil.getWorkflow().steps.filter(x => x.from.isDefined).filter(ibolt => {
        !ibolt.from.get.split(",").filter(grp => iSourceLabel.split(",").contains(grp)).isEmpty
      }).toList
    }


    /**
      * Create Target Levels for Sources at level
      *
      * @param sourceLevel
      * @return
      */
    private def createBoltsLevel(sourceLevel: Int = 1): String = {

      // process bolts for sourceLevel
      val iFlowLevels = flowLevels.filter(_.maxLevel.equals(sourceLevel))
      var contWithNextLevel = false

      //
      // Find Bolts connected to sources
      //
      iFlowLevels.map { iflowLevel =>

        var sourceBolts = getSourceBasedBolts(iflowLevel.label)

        // cache needed when targets are multiple
        if (sourceLevel > 2 && sourceBolts.size > 1) iflowLevel.cacheNeeded = PropsUtil.cacheByPlan()

        // each bolt under source
        sourceBolts.map { isourceBolt =>

          var iflowLevelList = flowLevels.filter { flowlevel => flowlevel.name.equals(isourceBolt.name) }
          iflowLevel.leafLevel = false

          // create level
          if (iflowLevelList.isEmpty) {
            var dataFrameList = List[DataFrame]()
            // define label or concatenated splitter labels
            if (!iflowLevel.dataFrames.isEmpty && iflowLevel.dataFrames.isDefinedAt(0) && sourceLevel == 1) dataFrameList = iflowLevel.dataFrames
            var splitLabelVar: String = isourceBolt.label.getOrElse("")
            if (isourceBolt.splitter.isDefined) {
              val splitLabels = isourceBolt.splitter.map(f => f.splits.getOrElse(Seq[Map[String, String]]()).map(p => p.getOrElse("label",""))).getOrElse(Seq("")).mkString(",")
              if (splitLabels.length > 1) splitLabelVar = splitLabelVar + "," + splitLabels
              //
              val splitLabelVal2 = isourceBolt.splitter.map(f => {
                f.splitConversions.getOrElse(Seq[Split]()).map(s => {
                  var splitSeq = -1
                  var label = ""
                  s.conversions.foreach(m => {
                    val mSeq = m.getOrElse("seq", "-1").toInt
                    if (mSeq > splitSeq) {
                      splitSeq = mSeq
                      label = m.getOrElse("label", label)
                    }
                  })
                  label
                })
              }).getOrElse(Seq("")).mkString(",")
              if (splitLabelVal2.length > 1) splitLabelVar = splitLabelVar + "," + splitLabelVal2

            }
            val splitLabel = splitLabelVar
            //
            flowLevels += new FlowLevel(isourceBolt.name, splitLabel, false, (iflowLevel.displayName + " >> " + isourceBolt.name), true, sourceLevel + 1, sourceLevel + 1, dataFrameList)
            contWithNextLevel = true
          }
          else {
            // update level
            val iflowexist = iflowLevelList(0)
            iflowexist.maxLevel = sourceLevel + 1
            if (!iflowLevel.dataFrames.isEmpty && iflowLevel.dataFrames.isDefinedAt(0) && sourceLevel == 1) iflowexist.dataFrames = iflowexist.dataFrames ++ iflowLevel.dataFrames
            iflowexist.displayName = "(" + iflowexist.displayName + ") (" + iflowexist.displayName + " >> " + isourceBolt.name + ") "
            contWithNextLevel = true
          }

        }

      }

      // Now go ahead with next level
      if (contWithNextLevel) createBoltsLevel(sourceLevel + 1)

      "IGNORED"

    }



    /**
      * Create Level for Source and Targets
      *
      * @param inDataFrames
      */
    private def buildTopologyLevels(inDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()): Unit = {

      //
      // Create Levels for spouts and bolts
      //
      createSpoutsLevel(inDataFrames)
      createBoltsLevel()

      // display names by level
      flowLevels.foreach(println)
      flowLevels.filter(_.leafLevel).map(x => println(x.displayName + "  " + x.minLevel))


    }



    /**
      * Process all Target DataFrames
      *
      * @param returnSink store or return dataframe
      * @param sourceLevel level to process from
      * @param outDataFrames return dataframes
      * @return
      */
    private def processTopologyTargets(
                                        returnSink: Boolean = false,
                                        sourceLevel: Int = 2,
                                        outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()): Map[String, DataFrame] = {
      logger.debug("processTopologyTargets invoked.....")

      //
      var resultDataFrames: Map[String, DataFrame] = outDataFrames


      // process bolts for sourceLevel
      val iFlowLevels = flowLevels.filter(_.maxLevel == sourceLevel)
      println("Found items size: " + iFlowLevels.size)
      var contWithNextLevel = false

      //
      // Find Bolts connected to sources
      //
      iFlowLevels.map { iflowLevel =>

        // process bolts
        val processBolts = PropsUtil.getWorkflow().steps.filter(x => x.from.isDefined).filter(_.name.equals(iflowLevel.name))

        // each bolt under source
        processBolts.map { iProcessBolt =>

          // union stream or single stream
          var unioineddataFrame = None: Option[DataFrame]
          var combinedNeeded = false

          iflowLevel.dataFrames.map { instream =>
            val cnt = if (PropsUtil.showData()) instream.count() + "" else ""
            logger.info("adding source dataframe..." + cnt)
            if (combinedNeeded) unioineddataFrame = Some(unioineddataFrame.get.union(instream)) else unioineddataFrame = Some(instream)
            combinedNeeded = true
          }

          // process the incoming stream
          println("Processing....", iProcessBolt.name)

          // editor vs sink process
          if (!iProcessBolt.model.equals("sink")) {
            val klassName = iProcessBolt.command.getOrElse(EditorBuilder.DEFAULT_EDITOR_BUILDER)
            // instantiate and delegate to Schema class
            val schemaKlass = Class.forName(klassName).getConstructor(iProcessBolt.name.getClass, planCache.getClass).newInstance(iProcessBolt.name, planCache).asInstanceOf[ {def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame]}]

            // Default Schema Build
            val emitterSplitDataFrames = schemaKlass.buildEditor(iProcessBolt, unioineddataFrame.get)
            emitterSplitDataFrames.foreach(f => logger.info(" returned dataframe: " + f.label))

            // cache emitted stream when cache required
            if (iflowLevel.cacheNeeded) {
              logger.info("Cache needed for : " + iflowLevel.name)
              emitterSplitDataFrames.foreach(f => f.dataFrame.cache())
            }

            // 1 level below target bolts
            val targetChildBolts = getSourceBasedBolts(iflowLevel.label)

            // each bolt under this process bolt
            targetChildBolts.map { iChildBolt =>

              logger.info(" loading children for: " + iflowLevel.name + "(" + iflowLevel.label + ") and current child: " + iChildBolt.name + "(" + iChildBolt.from + ")" )

              val iCFlowLevels = flowLevels.filter(_.name.equals(iChildBolt.name))
              val fromLabels = iChildBolt.from.getOrElse("").split(",")

              //val emitterDataFrame = emitterSplitDataFrames.

              iCFlowLevels.foreach(icfLevel => {
                //
                emitterSplitDataFrames.foreach(s => {
                  if (fromLabels contains s.label) {
                    icfLevel.dataFrames = icfLevel.dataFrames :+ s.dataFrame
                    logger.info(iflowLevel.name + "(" + iflowLevel.label + ") " + iChildBolt.name + "(" + iChildBolt.from + ") dataframe size: " + icfLevel.dataFrames.size )
                  }
                })
              })

              contWithNextLevel = true

            }

          } else {
            // store or return the Sink dataframe
            if (returnSink) {
              // Return the Sink Dataframe
              resultDataFrames += (iProcessBolt.name -> unioineddataFrame.get)
              println("returnSink: " + returnSink + resultDataFrames.size)
            } else {
              // Writer to store results without any return
              WriterBuilder(iProcessBolt.name, planCache).writeSink(iProcessBolt, unioineddataFrame.get)
              println("returnSink: " + returnSink + resultDataFrames.size)
            }
          }

        }

      }

      // Now go ahead with next level
      if (contWithNextLevel) resultDataFrames = processTopologyTargets(returnSink, (sourceLevel + 1), resultDataFrames)


      println("resultDataFrames is null: " + resultDataFrames.isEmpty)


      //
      resultDataFrames
    }




    /**
      * Executes the topology
      *
      */
    override def buildPlanExecutor(): Unit = {
      logger.debug("Invoked buildPlanExecutor")
      println("Invoked buildPlanExecutor")

      //
      // Filesystem initialization
      //
      FSHelper.initialize(planCache)

      //
      // StatusBuilderHelper initialization
      //
      StatusBuilderHelper.initialize(planCache)
      StatusBuilderHelper.beginLogStatus()

      //
      // Handle Flow and create levels
      //
      buildTopologyLevels()

      //
      // Process Frequency Cache refrsh
      //
      StorageHelper.refreshFrequencyCache()

      //
      // Process targets based on level
      //
      processTopologyTargets()

      //
      // OffsetStore save offsets
      //
      OffsetStore.storeOffsets()

      //
      // Filesystem initialization
      //
      FSHelper.endProcess()

      //
      // StatusBuilderHelper End Process
      //
      StatusBuilderHelper.endLogStatus()

      //
      // Clear any Plan scoped cache
      //
      clearPlanCache()


      //
      // Wait for Termination of any query
      //
      if ("stream".equals(PropsUtil.getWorkflow().mode)) {
        SparkHelper.getSparkSession().streams.awaitAnyTermination()
      }

    }


    /**
      * Returns the transformed DataFrame
      *
      * @param inDataFrames
      * @return
      */
    override def buildPlanExecutor(inDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()): Map[String, DataFrame] = {
      logger.debug("Invoked buildPlanExecutor(inDataFrames: Map[String, DataFrame])")
      println("Invoked buildPlanExecutor(inDataFrames: Map[String, DataFrame])")
      //
      var outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

      //
      // Filesystem initialization
      //
      FSHelper.initialize(planCache)

      //
      // StatusBuilderHelper initialization
      //
      StatusBuilderHelper.initialize(planCache)
      StatusBuilderHelper.beginLogStatus()

      //
      // Handle Flow and create levels
      //
      buildTopologyLevels(inDataFrames)

      //
      // Process Frequency Cache refrsh
      //
      StorageHelper.refreshFrequencyCache()

      //
      // Process targets based on level
      //
      processTopologyTargets()

      //
      // Process targets based on level
      //
      outDataFrames = processTopologyTargets(true)

      //
      // OffsetStore save offsets
      //
      OffsetStore.storeOffsets()

      //
      // Filesystem initialization
      //
      FSHelper.endProcess()

      //
      // StatusBuilderHelper End Process
      //
      StatusBuilderHelper.endLogStatus()

      //
      // Clear any Plan scoped cache
      //
      clearPlanCache()

      //
      outDataFrames
    }

  }



  /**
    * preferred factory method
    *
    * @param s
    * @return
    */
  def apply(s: String = ""): PlanExecutorBuilder = {
    getPlanExecutorBuilder(s)
  }

  // an alternative factory method (use one or the other)
  def getPlanExecutorBuilder(s: String = ""): PlanExecutorBuilder = {
    new BasePlanExecutorBuilder(s)
  }

}

/**
  * A Builder interface for execution plan
  */
trait PlanExecutorBuilder extends BaseTrait {

  var name: String = _
  var planCache: PlanCache = _


  /**
    * Executes the topology
    *
    */
  def buildPlanExecutor(): Unit = {

    // TODO: Should be implemented by Child Classes

  }

  /**
    * Returns the transformed DataFrame
    *
    * @param inDataFrames
    * @return
    */
  def buildPlanExecutor(inDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()): Map[String, DataFrame] = {
    //
    val outDataFrames: Map[String, DataFrame] = Map[String, DataFrame]()

    // TODO: Should be implemented by Child Classes

    //
    outDataFrames
  }

  /**
    * Clear plan scoped PlanCache model
    */
  def clearPlanCache(): Unit = {
    StorageHelper.clearPlanCache(planCache)
  }

}
