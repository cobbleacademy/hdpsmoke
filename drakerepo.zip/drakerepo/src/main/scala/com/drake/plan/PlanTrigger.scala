package com.drake.plan

import com.drake.BaseTrait

/**
  * A trigger handler to run the Pipeline based on trigger scripts output
  */
object PlanTrigger extends BaseTrait {


  /**
    * triggers the execution plan
    */
  def triggerPlanExecutor(): Unit = {
    val TRIG_RUN = "runTrigger"
    val TRIG_PRE = "preTrigger"
    val TRIG_ONFAILURE = "onFailTrigger"
    val TRIG_POST = "postTrigger"
    val SUCCESS_KEY = "success"

    // Build Topology
    PlanExecutorBuilder().buildPlanExecutor()

    //
    // Check pre condition trigger results
    //
//    val workflow = PropsUtil.getWorkflow()
//
//    EditorBuilderHelper.executeTriggerCondition(TRIG_RUN, workflow.triggerScriptPath.get, workflow.triggerScript.get, "pre_trigger", "hps_case_name")
//    val runTrigMap: Map[String, String] = SessionDataHelper.getSessionData().getOrElse(TRIG_RUN, Map()).toMap
//    println("Run Trigger Output")
//    runTrigMap.foreach(println)
//    println("Run Trigger Output")
//
//    EditorBuilderHelper.executeTriggerCondition(TRIG_PRE, workflow.triggerScriptPath.get, workflow.preTrigger.get)
//    val trigMap: Map[String, String] = SessionDataHelper.getSessionData().getOrElse(TRIG_PRE, Map()).toMap
//
//    //
//    if ("true".equals(trigMap.getOrElse(SUCCESS_KEY, "false"))) {
//
//      //
//      try
//      {
//        //
//        PlanExecutor.executeTopology()
//
//        //
//        EditorBuilderHelper.executeTriggerCondition(TRIG_POST, workflow.triggerScriptPath.get, workflow.postTrigger.get)
//
//      } catch {
//        case e: Exception => {
//          EditorBuilderHelper.executeTriggerCondition(TRIG_ONFAILURE, workflow.triggerScriptPath.get, workflow.onFailTrigger.get)
//          e.printStackTrace
//        }
//      }
//
//    } else {
//
//      println("***************************************************************************************")
//      println("                            MBR AVAIL TRIGGER IS MISSING                               ")
//      println("***************************************************************************************")
//
//    }

  }


}
