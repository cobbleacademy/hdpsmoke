package com.drake.plan

import com.drake.model.Model.{FlowLevel, PlanCache, SplitDataFrame, Step}
import com.drake.reader.ReaderBuilder
import com.drake.writer.WriterBuilder
import com.drake.{BaseTrait, PropsUtil, SparkHelper}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable
import scala.collection.mutable.{ListBuffer, MutableList}

/**
  * A Plan executor based on WorkFlow definition of events with their inter dependencies
  */
object PlanExecutor extends BaseTrait {

  private var flowLevels = MutableList[FlowLevel]()
  private var planCache: PlanCache = new PlanCache(mutable.Map[String, mutable.Map[String, String]](), ListBuffer[DataFrame](), mutable.Map[String, DataFrame]())

  /**
    * Process Spouts to build Flow
    */
  private def createSpoutsLevel(): Unit = {

    //
    // Handle Incoming Streams
    //
    PropsUtil.getWorkflow().steps.filter(x => !x.from.isDefined).map { ispout =>

      println("Creating Stream......")

      // connect and build input stream as spark stream
      // for each spout id load corresponding stream
      val dataFrame = ReaderBuilder(ispout.name, planCache).readSource(ispout)

      // Named json stream
      var dataFrameList = List[DataFrame]()
      dataFrameList = dataFrameList ++ List(dataFrame)
      flowLevels += new FlowLevel(ispout.name, ispout.label.get, false, ispout.name, true, 1, 1, dataFrameList)

    }

  }

  /**
    * Find Targets based on the Source
    */
  private def getSourceBasedBolts(iSourceLabel: String): List[Step] = {
    // load all bolts belong to refSpout Name
    PropsUtil.getWorkflow().steps.filter(x => x.from.isDefined).filter(ibolt => {
      !ibolt.from.get.split(",").filter(grp => iSourceLabel.split(",").contains(grp)).isEmpty
    }).toList
  }

  /**
    * Create Target Levels for Sources at level
    */
  private def createBoltsLevel(sourceLevel: Int = 1): String = {

    // process bolts for sourceLevel
    val iFlowLevels = flowLevels.filter(_.maxLevel.equals(sourceLevel))
    var contWithNextLevel = false

    //
    // Find Bolts connected to sources
    //
    iFlowLevels.map { iflowLevel =>

      var sourceBolts = getSourceBasedBolts(iflowLevel.label)

      // cache needed when targets are multiple
      if (sourceLevel > 2 && sourceBolts.size > 1) iflowLevel.cacheNeeded = true

      // each bolt under source
      sourceBolts.map { isourceBolt =>

        var iflowLevelList = flowLevels.filter { flowlevel => flowlevel.name.equals(isourceBolt.name) }
        iflowLevel.leafLevel = false

        // create level
        if (iflowLevelList.isEmpty) {
          var dataFrameList = List[DataFrame]()
          // define label or concatenated splitter labels
          if (!iflowLevel.dataFrames.isEmpty && iflowLevel.dataFrames.isDefinedAt(0) && sourceLevel == 1) dataFrameList = iflowLevel.dataFrames
          var splitLabelVar: String = isourceBolt.label.getOrElse("")
          if (isourceBolt.splitter.isDefined) {
            splitLabelVar = isourceBolt.splitter.map(f => f.splits.getOrElse(Seq[Map[String, String]]()).map(p => p.getOrElse("label", ""))).getOrElse(Seq("")).mkString(",")
          }
          val splitLabel = splitLabelVar
          //
          flowLevels += new FlowLevel(isourceBolt.name, splitLabel, false, (iflowLevel.displayName + " >> " + isourceBolt.name), true, sourceLevel + 1, sourceLevel + 1, dataFrameList)
          contWithNextLevel = true
          println("new dataframelist for: ",isourceBolt.name,dataFrameList.size)
        }
        else {
          // update level
          val iflowexist = iflowLevelList(0)
          iflowexist.maxLevel = sourceLevel + 1
          if (!iflowLevel.dataFrames.isEmpty && iflowLevel.dataFrames.isDefinedAt(0) && sourceLevel == 1) iflowexist.dataFrames = iflowexist.dataFrames ++ iflowLevel.dataFrames
          iflowexist.displayName = "(" + iflowexist.displayName + ") (" + iflowexist.displayName + " >> " + isourceBolt.name + ") "
          contWithNextLevel = true
          println("new dataframelist for: ",isourceBolt.name,iflowexist.dataFrames.size)
        }

      }

    }

    // Now go ahead with next level
    if (contWithNextLevel) createBoltsLevel(sourceLevel + 1)

    "IGNORED"

  }

  /**
    * Create Level for Source and Targets
    */
  private def buildTopologyLevels(): Unit = {

    //
    // Create Levels for spouts and bolts
    //
    createSpoutsLevel()
    createBoltsLevel()

    // display names by level
    flowLevels.filter(_.leafLevel).map(x => println(x.displayName + "  " + x.minLevel))

  }

  /**
    * Process all Target DataFrames
    */
  private def processTopologyTargets(sourceLevel: Int = 2): String = {

    println("------------------------------------")

    // process bolts for sourceLevel
    val iFlowLevels = flowLevels.filter(_.maxLevel == sourceLevel)
    println("Found items size: " + iFlowLevels.size)
    var contWithNextLevel = false

    //
    // Find Bolts connected to sources
    //
    iFlowLevels.map { iflowLevel =>

      // process bolts
      val processBolts = PropsUtil.getWorkflow().steps.filter(x => x.from.isDefined).filter(_.name.equals(iflowLevel.name))
      println("number of bolts under source: ", processBolts.size, iflowLevel.dataFrames.size)

      // each bolt under source
      processBolts.map { iProcessBolt =>

        // union stream or single stream
        var unioineddataFrame = None: Option[DataFrame]
        var combinedNeeded = false

        iflowLevel.dataFrames.map { instream =>
          println("Prior to Processing....", iProcessBolt.name, combinedNeeded)
          println(instream.count())
          logger.info("adding source dataframe..." + instream.count())
          if (combinedNeeded) unioineddataFrame = Some(unioineddataFrame.get.union(instream)) else unioineddataFrame = Some(instream)
          combinedNeeded = true
        }

        println("Prior to Processing....", iProcessBolt.name, combinedNeeded)
        println(unioineddataFrame.get.count())

        // process the incoming stream
        println("Processing....", iProcessBolt.name)

        // editor vs sink process
        if (!iProcessBolt.model.equals("sink")) {
          // instantiate and delegate to Schema class
          val schemaKlass = Class.forName(iProcessBolt.command.get).getConstructor(iProcessBolt.name.getClass).newInstance(iProcessBolt.name).asInstanceOf[ {def buildEditor(step: Step, input: DataFrame): Seq[SplitDataFrame]}]

          // Default Schema Build
          val emitterSplitDataFrames = schemaKlass.buildEditor(iProcessBolt, unioineddataFrame.get)
          emitterSplitDataFrames.foreach(f => logger.info(" returned dataframe: " + f.label))

          // cache emitted stream when cache required
          if (iflowLevel.cacheNeeded) {
            logger.info("Cache needed for : " + iflowLevel.name)
            emitterSplitDataFrames.foreach(f => f.dataFrame.cache())
          }

          // 1 level below target bolts
          val targetChildBolts = getSourceBasedBolts(iflowLevel.label)

          // each bolt under this process bolt
          targetChildBolts.map { iChildBolt =>

            logger.info(" loading children for: " + iflowLevel.name + "(" + iflowLevel.label + ") and current child: " + iChildBolt.name + "(" + iChildBolt.from + ")" )

            val iCFlowLevels = flowLevels.filter(_.name.equals(iChildBolt.name))
            val fromLabels = iChildBolt.from.getOrElse("").split(",")

            //val emitterDataFrame = emitterSplitDataFrames.

            iCFlowLevels.foreach(icfLevel => {
              //
              emitterSplitDataFrames.foreach(s => {
                if (fromLabels contains s.label) {
                  icfLevel.dataFrames = icfLevel.dataFrames :+ s.dataFrame
                }
              })
              //val emitterDataFrame = emitterSplitDataFrames.filter(p => p.label.equals(iChildBolt.from.getOrElse("")))(0).dataFrame
              //icfLevel.dataFrames = icfLevel.dataFrames :+ emitterDataFrame
            })

            contWithNextLevel = true

          }

        } else {
          // Writer to store results without any return
          WriterBuilder(iProcessBolt.name, planCache).writeSink(iProcessBolt, unioineddataFrame.get)
        }

      }

    }

    // Now go ahead with next level
    if (contWithNextLevel) processTopologyTargets(sourceLevel + 1)

    "IGNORED"
  }


  /**
    * execute Topology Network
    */
  def executeTopology(): Unit = {

    //
    // Handle Flow and create levels
    //
    buildTopologyLevels()

    //
    // Process targets based on level
    //
    processTopologyTargets()

    //
    // Wait for Termination of any query
    //
    if ("stream".equals(PropsUtil.getWorkflow().mode)) {
      SparkHelper.getSparkSession().streams.awaitAnyTermination()
    }

    //
  }


}
